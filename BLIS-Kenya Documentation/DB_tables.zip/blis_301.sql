-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 31, 2014 at 11:53 AM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `blis_301`
--

-- --------------------------------------------------------

--
-- Table structure for table `bills`
--

CREATE TABLE IF NOT EXISTS `bills` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `patient_id` int(11) unsigned NOT NULL,
  `paid_in_full` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `bills_test_association`
--

CREATE TABLE IF NOT EXISTS `bills_test_association` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `bill_id` int(11) unsigned NOT NULL,
  `test_id` int(11) unsigned NOT NULL,
  `discount_type` int(4) unsigned NOT NULL DEFAULT '1000',
  `discount_amount` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE IF NOT EXISTS `comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(45) NOT NULL DEFAULT '',
  `page` varchar(45) NOT NULL DEFAULT '',
  `comment` varchar(150) NOT NULL DEFAULT '',
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `custom_field_type`
--

CREATE TABLE IF NOT EXISTS `custom_field_type` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `field_type` varchar(100) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `custom_field_type`
--

INSERT INTO `custom_field_type` (`id`, `field_type`, `ts`) VALUES
(1, 'Freetext', '2010-01-13 16:28:03'),
(2, 'Date', '2010-01-13 16:28:03'),
(3, 'Options', '2010-01-13 16:28:03');

-- --------------------------------------------------------

--
-- Table structure for table `delay_measures`
--

CREATE TABLE IF NOT EXISTS `delay_measures` (
  `User_Id` varchar(50) NOT NULL DEFAULT '',
  `IP_Address` varchar(16) NOT NULL DEFAULT '',
  `Latency` int(11) NOT NULL DEFAULT '0',
  `Recorded_At` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Page_Name` varchar(45) DEFAULT NULL,
  `Request_URI` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `import_tests`
--

CREATE TABLE IF NOT EXISTS `import_tests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `result_type` varchar(1000) NOT NULL,
  `ordered_independently` varchar(1000) NOT NULL,
  `default` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `inv_reagent`
--

CREATE TABLE IF NOT EXISTS `inv_reagent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `unit` varchar(45) COLLATE latin1_general_ci NOT NULL DEFAULT 'units',
  `remarks` varchar(245) COLLATE latin1_general_ci DEFAULT NULL,
  `created_by` varchar(10) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `assocation` varchar(10) COLLATE latin1_general_ci DEFAULT '0',
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `inv_supply`
--

CREATE TABLE IF NOT EXISTS `inv_supply` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reagent_id` int(11) NOT NULL,
  `lot` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `expiry_date` date DEFAULT NULL,
  `manufacturer` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `supplier` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `quantity_ordered` int(11) NOT NULL DEFAULT '0',
  `quantity_supplied` int(11) NOT NULL DEFAULT '0',
  `cost_per_unit` decimal(10,0) DEFAULT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `date_of_order` date DEFAULT NULL,
  `date_of_supply` date DEFAULT NULL,
  `date_of_reception` date DEFAULT NULL,
  `remarks` varchar(250) COLLATE latin1_general_ci DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `reagent_id` (`reagent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `inv_usage`
--

CREATE TABLE IF NOT EXISTS `inv_usage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reagent_id` int(11) NOT NULL,
  `lot` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `quantity_used` int(11) NOT NULL DEFAULT '0',
  `date_of_use` date NOT NULL,
  `user_id` int(11) NOT NULL,
  `remarks` varchar(250) COLLATE latin1_general_ci DEFAULT NULL,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `reagent_id` (`reagent_id`),
  KEY `reagent_id2` (`reagent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `labtitle_custom_field`
--

CREATE TABLE IF NOT EXISTS `labtitle_custom_field` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `field_name` varchar(45) NOT NULL,
  `field_options` varchar(200) NOT NULL,
  `field_type_id` int(11) unsigned NOT NULL DEFAULT '0',
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `field_type_id` (`field_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `labtitle_custom_field`
--

INSERT INTO `labtitle_custom_field` (`id`, `field_name`, `field_options`, `field_type_id`, `ts`) VALUES
(1, 'title', 'Dr./Dr. Mrs./Mr./Mrs./Prof./Councelor/Medical Assistant ', 3, '2011-05-07 19:23:39');

-- --------------------------------------------------------

--
-- Table structure for table `lab_config`
--

CREATE TABLE IF NOT EXISTS `lab_config` (
  `lab_config_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(45) NOT NULL DEFAULT '',
  `location` char(45) NOT NULL DEFAULT '',
  `admin_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `db_name` char(45) NOT NULL DEFAULT '',
  `id_mode` int(10) unsigned NOT NULL DEFAULT '2',
  `p_addl` int(10) unsigned NOT NULL DEFAULT '0',
  `s_addl` int(10) unsigned NOT NULL DEFAULT '0',
  `daily_num` int(10) unsigned NOT NULL DEFAULT '1',
  `pid` int(10) unsigned NOT NULL DEFAULT '2',
  `pname` int(10) unsigned NOT NULL DEFAULT '1',
  `sex` int(10) unsigned NOT NULL DEFAULT '2',
  `age` int(10) unsigned NOT NULL DEFAULT '1',
  `dob` int(10) unsigned NOT NULL DEFAULT '1',
  `sid` int(10) unsigned NOT NULL DEFAULT '2',
  `refout` int(10) unsigned NOT NULL DEFAULT '1',
  `rdate` int(10) unsigned NOT NULL DEFAULT '2',
  `comm` int(10) unsigned NOT NULL DEFAULT '1',
  `dformat` varchar(45) NOT NULL DEFAULT 'd-m-Y',
  `dnum_reset` int(10) unsigned NOT NULL DEFAULT '1',
  `doctor` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`lab_config_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT AUTO_INCREMENT=2 ;

--
-- Dumping data for table `lab_config`
--

INSERT INTO `lab_config` (`lab_config_id`, `name`, `location`, `admin_user_id`, `db_name`, `id_mode`, `p_addl`, `s_addl`, `daily_num`, `pid`, `pname`, `sex`, `age`, `dob`, `sid`, `refout`, `rdate`, `comm`, `dformat`, `dnum_reset`, `doctor`) VALUES
(1, 'Test Laboratory', '@iLabAfrica', 53, 'blis_1', 1, 0, 0, 1, 2, 1, 2, 1, 1, 0, 0, 2, 0, 'd-m-Y', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `lab_config_access`
--

CREATE TABLE IF NOT EXISTS `lab_config_access` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `lab_config_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`,`lab_config_id`),
  KEY `lab_config_id` (`lab_config_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `lab_config_settings`
--

CREATE TABLE IF NOT EXISTS `lab_config_settings` (
  `id` int(11) NOT NULL,
  `flag1` int(11) DEFAULT NULL,
  `flag2` int(11) DEFAULT NULL,
  `flag3` int(11) DEFAULT NULL,
  `flag4` int(11) DEFAULT NULL,
  `setting1` varchar(200) COLLATE latin1_general_ci DEFAULT NULL,
  `setting2` varchar(200) COLLATE latin1_general_ci DEFAULT NULL,
  `setting3` varchar(200) COLLATE latin1_general_ci DEFAULT NULL,
  `setting4` varchar(200) COLLATE latin1_general_ci DEFAULT NULL,
  `misc` varchar(500) COLLATE latin1_general_ci DEFAULT NULL,
  `remarks` varchar(500) COLLATE latin1_general_ci DEFAULT NULL,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `lab_config_settings`
--

INSERT INTO `lab_config_settings` (`id`, `flag1`, `flag2`, `flag3`, `flag4`, `setting1`, `setting2`, `setting3`, `setting4`, `misc`, `remarks`, `ts`) VALUES
(1, 0, 2, 30, 11, 'code128', NULL, NULL, NULL, NULL, 'Barcode Settings', '2012-10-17 07:15:35'),
(2, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Search Settings', '2012-10-17 03:27:22'),
(3, 1, NULL, NULL, NULL, 'Ksh', '/', NULL, NULL, NULL, 'Billing Settings', '2012-11-05 06:54:34');

-- --------------------------------------------------------

--
-- Table structure for table `lab_config_specimen_type`
--

CREATE TABLE IF NOT EXISTS `lab_config_specimen_type` (
  `lab_config_id` int(10) unsigned NOT NULL DEFAULT '0',
  `specimen_type_id` int(10) unsigned NOT NULL DEFAULT '0',
  KEY `lab_config_id` (`lab_config_id`),
  KEY `specimen_type_id` (`specimen_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lab_config_specimen_type`
--

INSERT INTO `lab_config_specimen_type` (`lab_config_id`, `specimen_type_id`) VALUES
(300, 13),
(300, 10),
(300, 8),
(300, 14),
(300, 23),
(300, 18),
(300, 16),
(300, 15),
(300, 7),
(300, 22),
(300, 9),
(300, 12),
(300, 17),
(300, 24),
(300, 11),
(300, 21),
(300, 6),
(300, 26),
(300, 25),
(300, 28),
(300, 30),
(300, 27),
(300, 29),
(301, 26),
(301, 13),
(301, 10),
(301, 8),
(301, 25),
(301, 14),
(301, 23),
(301, 18),
(301, 28),
(301, 30),
(301, 16),
(301, 15),
(301, 7),
(301, 22),
(301, 9),
(301, 12),
(301, 27),
(301, 17),
(301, 24),
(301, 11),
(301, 21),
(301, 29),
(301, 6);

-- --------------------------------------------------------

--
-- Table structure for table `lab_config_test_type`
--

CREATE TABLE IF NOT EXISTS `lab_config_test_type` (
  `lab_config_id` int(10) unsigned NOT NULL DEFAULT '0',
  `test_type_id` int(10) unsigned NOT NULL DEFAULT '0',
  KEY `lab_config_id` (`lab_config_id`),
  KEY `test_type_id` (`test_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lab_config_test_type`
--

INSERT INTO `lab_config_test_type` (`lab_config_id`, `test_type_id`) VALUES
(300, 85),
(300, 90),
(300, 19),
(300, 8),
(300, 32),
(300, 92),
(300, 64),
(300, 18),
(300, 98),
(300, 63),
(300, 21),
(300, 68),
(300, 12),
(300, 110),
(300, 95),
(300, 25),
(300, 54),
(300, 116),
(300, 26),
(300, 105),
(300, 15),
(300, 22),
(300, 60),
(300, 89),
(300, 101),
(300, 51),
(300, 88),
(300, 7),
(300, 9),
(300, 73),
(300, 55),
(300, 31),
(300, 96),
(300, 29),
(300, 48),
(300, 57),
(300, 40),
(300, 49),
(300, 41),
(300, 43),
(300, 37),
(300, 44),
(300, 42),
(300, 34),
(300, 33),
(300, 30),
(300, 35),
(300, 36),
(300, 99),
(300, 14),
(300, 38),
(300, 100),
(300, 13),
(300, 50),
(300, 24),
(300, 97),
(300, 61),
(300, 62),
(300, 72),
(300, 94),
(300, 84),
(300, 59),
(300, 47),
(300, 111),
(300, 115),
(300, 53),
(300, 106),
(300, 23),
(300, 65),
(300, 71),
(300, 91),
(300, 108),
(300, 109),
(300, 107),
(300, 86),
(300, 83),
(300, 112),
(300, 74),
(300, 16),
(300, 17),
(300, 20),
(300, 27),
(300, 10),
(300, 67),
(300, 66),
(300, 28),
(300, 103),
(300, 104),
(300, 11),
(300, 56),
(300, 102),
(300, 58),
(300, 46),
(300, 52),
(300, 93),
(300, 69),
(300, 70),
(300, 137),
(300, 134),
(300, 135),
(300, 127),
(300, 276),
(300, 299),
(300, 296),
(300, 161),
(300, 176),
(300, 170),
(300, 194),
(300, 171),
(300, 154),
(300, 159),
(300, 292),
(300, 302),
(300, 291),
(300, 124),
(300, 305),
(300, 260),
(300, 142),
(300, 195),
(300, 146),
(300, 155),
(300, 287),
(300, 265),
(300, 263),
(300, 138),
(300, 152),
(300, 153),
(300, 145),
(300, 156),
(300, 198),
(300, 174),
(300, 281),
(300, 117),
(300, 150),
(300, 304),
(300, 183),
(300, 168),
(300, 184),
(300, 295),
(300, 294),
(300, 271),
(300, 255),
(300, 151),
(300, 173),
(300, 267),
(300, 141),
(300, 186),
(300, 187),
(300, 185),
(300, 222),
(300, 221),
(300, 224),
(300, 191),
(300, 289),
(300, 293),
(300, 190),
(300, 192),
(300, 158),
(300, 189),
(300, 143),
(300, 300),
(300, 126),
(300, 172),
(300, 131),
(300, 196),
(300, 166),
(300, 182),
(300, 188),
(300, 162),
(300, 301),
(300, 148),
(300, 165),
(300, 288),
(300, 268),
(300, 120),
(300, 136),
(300, 197),
(300, 144),
(300, 223),
(300, 160),
(300, 285),
(300, 290),
(300, 282),
(300, 164),
(300, 113),
(300, 149),
(300, 132),
(300, 139),
(300, 147),
(300, 123),
(300, 157),
(300, 175),
(300, 167),
(300, 169),
(300, 298),
(300, 225),
(300, 226),
(300, 181),
(300, 244),
(300, 303),
(300, 297),
(300, 163),
(300, 279),
(301, 291),
(301, 137),
(301, 135),
(301, 290),
(301, 134),
(301, 127),
(301, 276),
(301, 299),
(301, 296),
(301, 161),
(301, 176),
(301, 170),
(301, 194),
(301, 171),
(301, 154),
(301, 159),
(301, 292),
(301, 302),
(301, 124),
(301, 305),
(301, 260),
(301, 142),
(301, 195),
(301, 146),
(301, 155),
(301, 287),
(301, 265),
(301, 263),
(301, 138),
(301, 152),
(301, 153),
(301, 145),
(301, 156),
(301, 198),
(301, 174),
(301, 281),
(301, 117),
(301, 150),
(301, 304),
(301, 183),
(301, 168),
(301, 184),
(301, 295),
(301, 294),
(301, 271),
(301, 255),
(301, 151),
(301, 173),
(301, 267),
(301, 141),
(301, 186),
(301, 187),
(301, 185),
(301, 222),
(301, 221),
(301, 224),
(301, 191),
(301, 289),
(301, 293),
(301, 190),
(301, 192),
(301, 158),
(301, 189),
(301, 143),
(301, 300),
(301, 126),
(301, 172),
(301, 131),
(301, 196),
(301, 166),
(301, 182),
(301, 188),
(301, 162),
(301, 301),
(301, 148),
(301, 165),
(301, 288),
(301, 268),
(301, 120),
(301, 136),
(301, 197),
(301, 144),
(301, 223),
(301, 160),
(301, 285),
(301, 282),
(301, 164),
(301, 149),
(301, 132),
(301, 139),
(301, 147),
(301, 123),
(301, 157),
(301, 175),
(301, 167),
(301, 169),
(301, 298),
(301, 225),
(301, 226),
(301, 279),
(301, 181),
(301, 244),
(301, 303),
(301, 297),
(301, 163),
(301, 307),
(301, 308),
(301, 309),
(301, 310),
(301, 311),
(301, 312),
(301, 313),
(301, 314),
(301, 315),
(301, 316),
(301, 317),
(301, 318),
(301, 319),
(301, 320),
(301, 322),
(301, 323);

-- --------------------------------------------------------

--
-- Table structure for table `measure`
--

CREATE TABLE IF NOT EXISTS `measure` (
  `measure_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL DEFAULT '',
  `unit_id` int(10) unsigned DEFAULT NULL,
  `measure_range` varchar(500) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `unit` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`measure_id`),
  KEY `unit_id` (`unit_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=416 ;

--
-- Dumping data for table `measure`
--

INSERT INTO `measure` (`measure_id`, `name`, `unit_id`, `measure_range`, `description`, `ts`, `unit`) VALUES
(197, 'Grams stain', NULL, 'Positive/Negative', NULL, '2013-10-17 16:23:06', NULL),
(200, 'SERUM AMYLASE', NULL, 'Low/Normal/High', NULL, '2013-10-17 16:23:06', NULL),
(201, 'calcium', NULL, 'Low/Normal/High', NULL, '2013-10-17 16:23:06', NULL),
(203, 'URIC ACID', NULL, ':', NULL, '2014-03-07 10:13:11', 'mg/dl'),
(210, 'CSF for biochemistry', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(211, 'PSA', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(212, 'Total', NULL, ':', NULL, '2014-03-07 10:11:39', 'mg/dl'),
(214, 'Alkaline Phosphate', NULL, ':', NULL, '2014-03-07 10:04:03', 'u/l'),
(216, 'SGOT', NULL, 'Low/Normal/High', NULL, '2014-03-04 15:13:40', ''),
(218, 'Direct ', NULL, ':', NULL, '2014-03-07 10:11:39', 'mg/dl'),
(219, 'Total Proteins ', NULL, ':', NULL, '2014-03-11 03:07:42', ''),
(221, 'LFTS', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(222, 'Chloride', NULL, ':', NULL, '2014-03-07 09:56:00', 'mmol/l'),
(223, 'Potassium', NULL, ':', NULL, '2014-03-07 09:56:00', 'mmol/l'),
(224, 'Sodium', NULL, ':', NULL, '2014-03-07 09:56:00', 'mmol/l'),
(225, 'Electrolytes', NULL, '$freetext$$', NULL, '2014-02-25 07:04:33', ''),
(226, 'Creatinine ', NULL, ':', NULL, '2014-03-07 09:43:50', 'mg/dl'),
(227, 'Urea', NULL, ':', NULL, '2014-03-07 09:47:47', 'mg/dl'),
(228, 'RFTS', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(229, 'TFT', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(230, 'GXM', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(231, 'Indirect COOMBS test', NULL, 'Positive/Negative', NULL, '2013-10-17 16:23:06', NULL),
(232, 'Direct COOMBS test', NULL, 'Positive/Negative', NULL, '2013-10-17 16:23:06', NULL),
(233, 'Du test', NULL, 'Positive/Negative', NULL, '2013-10-17 16:23:06', NULL),
(234, 'Blood Grouping', NULL, 'O-/O+/A-/A+/B-/B+/AB-/AB+', NULL, '2014-02-27 12:12:27', ''),
(235, 'Cross Match', NULL, 'Pending/Done', NULL, '2014-02-27 12:12:27', ''),
(236, 'Epithelial cells', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(238, 'ph', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(239, 'Blood sugar', NULL, 'Low/Normal/High', NULL, '2013-11-01 06:45:04', ''),
(240, 'Spermatozoa', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(241, 'Bacteria', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(242, 'Red blood cells', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(243, 'Yeast cells', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(244, 'T. vaginalis', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(245, 'S. haematobium', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(246, 'Pus cells', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(247, 'Urine microscopy', NULL, 'Positive/Negative', NULL, '2013-10-17 16:23:06', NULL),
(248, 'HCG', NULL, '$freetext$$', NULL, '2014-02-27 06:40:09', ''),
(249, 'Urobilinogen Phenlpyruvic acid', NULL, '$freetext$$', NULL, '2014-02-27 06:40:09', ''),
(251, 'Blood', NULL, '$freetext$$', NULL, '2014-02-27 06:40:09', ''),
(252, 'Proteins', NULL, '$freetext$$', NULL, '2014-02-27 06:40:09', ''),
(253, 'Ketones', NULL, '$freetext$$', NULL, '2014-02-27 06:40:09', ''),
(256, 'Baso#', NULL, ':', NULL, '2013-10-29 13:04:28', '%'),
(257, 'Eos#', NULL, ':', NULL, '2014-03-12 14:26:21', ''),
(258, 'Mon#', NULL, ':', NULL, '2014-03-12 14:27:21', ''),
(259, 'Lym#', NULL, ':', NULL, '2014-03-12 14:26:58', ''),
(260, 'Neu#', NULL, ':', NULL, '2014-03-12 14:27:44', ''),
(261, 'WBC', NULL, ':', NULL, '2013-10-29 12:53:01', 'x10Â³/ÂµL'),
(262, 'RBC', NULL, ':', NULL, '2013-10-29 13:16:03', 'x10â¶/ÂµL'),
(263, 'HB', NULL, ':', NULL, '2013-10-29 13:20:10', 'g/dL'),
(264, 'HCT', NULL, ':', NULL, '2013-10-29 13:21:10', '%'),
(265, 'MCV', NULL, ':', NULL, '2013-10-29 13:22:23', 'fL'),
(266, 'MCH', NULL, ':', NULL, '2013-10-29 13:23:23', 'pg'),
(267, 'MCHC', NULL, ':', NULL, '2013-10-29 13:24:25', 'g/dL'),
(268, 'RDW', NULL, ':', NULL, '2013-10-29 13:25:50', '%'),
(269, 'PLATELET COUNT', NULL, ':', NULL, '2013-10-29 13:28:25', 'x10Â³/ÂµL'),
(270, 'PCT', NULL, ':', NULL, '2013-10-29 13:29:30', '%'),
(272, 'PDW', NULL, ':', NULL, '2013-10-29 13:31:54', '%'),
(273, 'Full Haemogram', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(274, 'Bleeding time test', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(275, 'Clotting time test', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(276, 'PTI/INR', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(277, 'Sickling test', NULL, 'Positive/Negative', NULL, '2013-10-17 16:23:06', NULL),
(278, 'ESR', NULL, 'Low/Normal/High', NULL, '2013-10-17 16:23:06', NULL),
(282, 'Gramstain', NULL, '$freetext$$', NULL, '2014-02-20 14:29:27', ''),
(284, 'microscopy', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(298, 'Throat swab for culture', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(302, 'microscopic examination', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(303, 'sperm count', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(304, 'motility', NULL, 'Positive/Negative', NULL, '2013-10-17 16:23:06', NULL),
(305, 'viscosity', NULL, 'Positive/Negative', NULL, '2013-10-17 16:23:06', NULL),
(306, 'volume', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(322, 'wet prep', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(335, 'Indian ink', NULL, 'Positive/Negative', NULL, '2014-03-06 07:45:55', ''),
(338, 'cell count', NULL, 'Number (count/ml)', NULL, '2014-03-06 07:45:55', ''),
(343, 'culture and sensitivity', NULL, '$freetext$$', NULL, '2014-03-08 08:01:23', ''),
(345, 'CSF for microbiology', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(346, 'Pus swab for culture and sensitivity', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(347, 'KOH for fungi', NULL, 'Positive/Negative', NULL, '2013-10-17 16:23:06', NULL),
(348, 'semen analysis', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(350, 'Aspirate for microscopy ', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(351, 'HVS for microscopy ', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(352, 'Synovial fluid for culture and sensitivity', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(353, 'Synovial fluid for microscopy', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(354, 'Pleural tap for culture and sensitivity', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(355, 'Pleural tap for microscopy', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(358, 'Urine Culture and Sensitivity', NULL, '$freetext$$', NULL, '2014-02-27 07:00:04', ''),
(359, 'Water Analysis', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(361, 'Gram stain', NULL, 'Positive/Negative', NULL, '2013-10-17 16:23:06', NULL),
(362, 'Sub culture ', NULL, 'Positive/Negative', NULL, '2013-10-17 16:23:06', NULL),
(363, 'Blood Culture & sensitivity', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(364, 'HVS for culture and sensitivity', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(365, 'Sputum', NULL, 'Positive/Negative', NULL, '2013-10-17 16:23:06', NULL),
(366, 'Stool for C/S', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(367, 'CSF', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(368, 'salmonella antigen test', NULL, 'Positive/Negative', NULL, '2014-03-08 08:01:54', ''),
(369, 'OCCULT BLOOD', NULL, 'Positive/Negative', NULL, '2013-10-17 16:23:06', NULL),
(370, 'Stool for O/C', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(371, 'BS for mps', NULL, 'Positive/Negative', NULL, '2013-10-17 16:23:06', NULL),
(372, 'Borrelia', NULL, 'Positive/Negative', NULL, '2013-10-17 16:23:06', NULL),
(373, 'PBF', NULL, '$freetext$$', NULL, '2013-10-18 09:02:51', NULL),
(374, 'HEPATITIS C', NULL, 'Positive/Negative', NULL, '2013-10-17 16:23:06', NULL),
(375, 'HEPATITIS B', NULL, 'Positive/Negative', NULL, '2013-10-17 16:23:06', NULL),
(376, 'Asot Titration', NULL, 'Positive/Negative', NULL, '2013-10-17 16:23:06', NULL),
(377, 'Widal Titration', NULL, 'Number (count/ml)', NULL, '2013-10-17 16:23:06', NULL),
(378, 'VDRL', NULL, 'Positive/Negative', NULL, '2013-10-17 16:23:06', NULL),
(379, 'Asot', NULL, 'Positive/Negative', NULL, '2013-10-17 16:23:06', NULL),
(380, 'Pregnancy test', NULL, 'Positive/Negative', NULL, '2013-10-17 16:23:06', NULL),
(381, 'RF', NULL, 'Positive/Negative', NULL, '2013-10-17 16:23:06', NULL),
(382, 'Brucella', NULL, 'Positive/Negative', NULL, '2013-10-17 16:23:06', NULL),
(383, 'Widal', NULL, 'Positive/Negative', NULL, '2013-10-17 16:23:06', NULL),
(384, 'H pylori', NULL, 'Positive/Negative', NULL, '2013-10-17 16:23:06', NULL),
(385, 'CD4', NULL, 'Low/Normal/High', NULL, '2013-10-17 16:23:06', NULL),
(393, 'HGB', NULL, ':', NULL, '2013-10-29 10:48:28', 'g/dl'),
(403, 'Glucose', NULL, '$freetext$$', NULL, '2014-02-22 13:09:38', ''),
(404, 'Protein', NULL, '$freetext$$', NULL, '2014-02-22 13:09:38', ''),
(405, 'Culture', NULL, '$freetext$$', NULL, '2014-02-22 13:15:26', ''),
(406, 'Sensitivity', NULL, '$freetext$$', NULL, '2014-02-22 13:15:26', ''),
(407, 'ZN stain', NULL, '$freetext$$', NULL, '2014-02-22 13:15:26', ''),
(408, 'ALAT', NULL, ':', NULL, '2014-03-07 09:58:37', 'u/l'),
(409, 'Albumin', NULL, ':', NULL, '2014-03-07 10:01:00', 'g/dl'),
(410, 'sd', NULL, '$freetext$$', NULL, '2014-02-24 12:05:36', ''),
(411, 'Aspirate for culture and sensitivity', NULL, '$freetext$$', NULL, '2014-02-25 09:21:07', ''),
(412, 'Bilirubin', NULL, '$freetext$$', NULL, '2014-02-27 06:40:09', ''),
(413, 'Urinalysis', NULL, '$freetext$$', NULL, '2014-02-27 06:58:28', ''),
(414, 'ASAT', NULL, 'Low/Normal/High', NULL, '2014-03-04 15:13:40', ''),
(415, 'ASAT', NULL, ':', NULL, '2014-03-07 09:51:32', 'u/l');

-- --------------------------------------------------------

--
-- Table structure for table `misc`
--

CREATE TABLE IF NOT EXISTS `misc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `r_id` int(11) NOT NULL DEFAULT '0',
  `vr_id` varchar(45) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `i1` int(11) NOT NULL DEFAULT '0',
  `i2` int(11) NOT NULL DEFAULT '0',
  `i3` int(11) NOT NULL DEFAULT '0',
  `i4` int(11) NOT NULL DEFAULT '0',
  `i5` int(11) NOT NULL DEFAULT '0',
  `v1` varchar(500) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `v2` varchar(500) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `v3` varchar(500) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `v4` varchar(500) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `v5` varchar(500) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `dt1` datetime DEFAULT NULL,
  `dt2` datetime DEFAULT NULL,
  `dt3` datetime DEFAULT NULL,
  `d1` date DEFAULT NULL,
  `d2` date DEFAULT NULL,
  `d3` date DEFAULT NULL,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `mmmm`
--

CREATE TABLE IF NOT EXISTS `mmmm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `r_id` int(11) NOT NULL DEFAULT '0',
  `vr_id` varchar(45) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `i1` int(11) NOT NULL DEFAULT '0',
  `i2` int(11) NOT NULL DEFAULT '0',
  `i3` int(11) NOT NULL DEFAULT '0',
  `i4` int(11) NOT NULL DEFAULT '0',
  `i5` int(11) NOT NULL DEFAULT '0',
  `v1` varchar(500) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `v2` varchar(500) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `v3` varchar(500) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `v4` varchar(500) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `v5` varchar(500) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `dt1` datetime DEFAULT NULL,
  `dt2` datetime DEFAULT NULL,
  `dt3` datetime DEFAULT NULL,
  `d1` date DEFAULT NULL,
  `d2` date DEFAULT NULL,
  `d3` date DEFAULT NULL,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `numeric_interpretation`
--

CREATE TABLE IF NOT EXISTS `numeric_interpretation` (
  `range_u` int(10) DEFAULT NULL,
  `range_l` int(10) DEFAULT NULL,
  `age_u` int(10) DEFAULT NULL,
  `age_l` int(10) DEFAULT NULL,
  `gender` varchar(40) DEFAULT NULL,
  `description` varchar(40) DEFAULT NULL,
  `measure_id` int(10) unsigned NOT NULL,
  `id` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `measure_id` (`measure_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=55 ;

--
-- Dumping data for table `numeric_interpretation`
--

INSERT INTO `numeric_interpretation` (`range_u`, `range_l`, `age_u`, `age_l`, `gender`, `description`, `measure_id`, `id`) VALUES
(11, 11, 65, 15, 'PW', 'Normal', 34, 1),
(15, 12, 120, 15, 'F', 'Normal', 34, 2),
(18, 14, 120, 15, 'M', 'Normal', 34, 3),
(16, 10, 9, 1, 'Child', 'Normal', 34, 4),
(3, 2, 120, 0, 'B', 'Normal', 12, 5),
(2, 0, 120, 0, 'B', 'Low', 12, 6),
(25, 3, 120, 0, 'B', 'High', 12, 7),
(6, 4, 100, 0, 'B', 'Normal', 22, 8),
(3, 0, 100, 0, 'B', 'Low', 22, 9),
(25, 6, 100, 0, 'B', 'High', 22, 10),
(12, 4, 100, 0, 'B', 'Normal', 88, 11),
(4, 0, 100, 0, 'B', 'Low', 88, 12),
(50, 12, 100, 0, 'B', 'High', 88, 13),
(155, 135, 120, 0, 'B', 'Normal', 21, 14),
(134, 0, 120, 0, 'B', 'Low', 21, 15),
(250, 156, 120, 0, 'B', 'High', 21, 16),
(250, 130, 100, 0, 'B', 'Normal', 25, 17),
(129, 0, 100, 0, 'B', 'Low', 25, 18),
(500, 251, 100, 0, 'B', 'High', 25, 19),
(184, 44, 100, 0, 'M', 'Normal', 26, 20),
(43, 0, 100, 0, 'M', 'Low', 26, 21),
(250, 185, 100, 0, 'M', 'High', 26, 22),
(132, 35, 100, 0, 'F', 'Normal', 26, 23),
(34, 0, 100, 0, 'F', 'Low', 26, 24),
(250, 133, 100, 0, 'F', 'High', 26, 25),
(50, 10, 100, 0, 'B', 'Normal', 152, 26),
(9, 0, 100, 0, 'B', 'Low', 152, 27),
(150, 51, 100, 0, 'B', 'High', 152, 28),
(7, 3, 100, 0, 'B', 'Normal', 9, 29),
(3, 0, 100, 0, 'B', 'Low', 9, 30),
(25, 7, 100, 0, 'B', 'High', 9, 31),
(4, 1, 100, 0, 'B', 'Normal', 73, 32),
(50, 10, 100, 0, 'B', 'Normal', 19, 33),
(11, 8, 100, 0, 'B', 'Normal', 10, 34),
(108, 95, 100, 0, 'B', 'Normal', 23, 35),
(12, 8, 100, 0, 'B', 'Normal', 49, 36),
(1, 1, 100, 0, 'M', 'Normal', 13, 37),
(45, 5, 100, 0, 'M', 'Normal', 6, 38),
(4, 0, 100, 0, 'B', 'Low', 6, 39),
(35, 5, 100, 0, 'F', 'Normal', 6, 40),
(8, 0, 100, 0, 'B', 'Low', 10, 41),
(25, 11, 100, 0, 'B', 'High', 10, 42),
(95, 0, 100, 0, 'B', 'Low', 23, 43),
(200, 108, 100, 0, 'B', 'High', 23, 44),
(31, 0, 120, 0, 'F', 'Normal', 16, 45),
(200, 32, 120, 0, 'F', 'High', 16, 46),
(37, 0, 120, 0, 'M', 'Normal', 16, 47),
(200, 38, 120, 0, 'M', 'High', 16, 48),
(45, 0, 120, 0, 'M', 'Low', 27, 49),
(200, 46, 120, 0, 'M', 'Normal', 27, 50),
(50, 0, 120, 0, 'F', 'Low', 27, 51),
(200, 51, 120, 0, 'F', 'Normal', 27, 52),
(157, 0, 120, 0, 'B', 'Normal', 28, 53),
(300, 158, 120, 0, 'B', 'High', 28, 54);

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE IF NOT EXISTS `patient` (
  `patient_id` int(11) unsigned NOT NULL DEFAULT '0',
  `addl_id` varchar(40) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `sex` char(1) NOT NULL DEFAULT '',
  `age` decimal(10,0) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `created_by` int(11) unsigned DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `partial_dob` varchar(45) DEFAULT NULL,
  `surr_id` varchar(45) DEFAULT NULL,
  `hash_value` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`patient_id`),
  KEY `created_by` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `patient_custom_data`
--

CREATE TABLE IF NOT EXISTS `patient_custom_data` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `field_id` int(11) unsigned NOT NULL DEFAULT '0',
  `patient_id` int(11) unsigned NOT NULL DEFAULT '0',
  `field_value` varchar(45) NOT NULL DEFAULT '',
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `field_id` (`field_id`),
  KEY `patient_id` (`patient_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

-- --------------------------------------------------------

--
-- Table structure for table `patient_custom_field`
--

CREATE TABLE IF NOT EXISTS `patient_custom_field` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `field_name` varchar(45) NOT NULL DEFAULT '',
  `field_options` varchar(45) NOT NULL DEFAULT '',
  `field_type_id` int(11) unsigned NOT NULL DEFAULT '0',
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `field_type_id` (`field_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `patient_custom_field`
--

INSERT INTO `patient_custom_field` (`id`, `field_name`, `field_options`, `field_type_id`, `ts`) VALUES
(1, 'Patient type', 'New/Referral', 3, '2013-09-26 14:21:28');

-- --------------------------------------------------------

--
-- Table structure for table `patient_daily`
--

CREATE TABLE IF NOT EXISTS `patient_daily` (
  `datestring` varchar(45) NOT NULL,
  `count` int(10) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE IF NOT EXISTS `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `bill_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `reference_range`
--

CREATE TABLE IF NOT EXISTS `reference_range` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `measure_id` int(10) unsigned NOT NULL,
  `age_min` varchar(45) DEFAULT NULL,
  `age_max` varchar(45) DEFAULT NULL,
  `sex` varchar(10) DEFAULT NULL,
  `range_lower` varchar(45) NOT NULL,
  `range_upper` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `measure_id` (`measure_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `rejected_specimen`
--

CREATE TABLE IF NOT EXISTS `rejected_specimen` (
  `specimen_id` int(11) unsigned NOT NULL DEFAULT '0',
  `reason_id` int(11) unsigned NOT NULL DEFAULT '0',
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `specimen_id` (`specimen_id`),
  KEY `reason_id` (`reason_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rejection_phases`
--

CREATE TABLE IF NOT EXISTS `rejection_phases` (
  `rejection_phase_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL DEFAULT '',
  `description` varchar(100) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`rejection_phase_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `rejection_reasons`
--

CREATE TABLE IF NOT EXISTS `rejection_reasons` (
  `rejection_reason_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rejection_phase` int(11) NOT NULL,
  `description` varchar(100) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`rejection_reason_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `removal_record`
--

CREATE TABLE IF NOT EXISTS `removal_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `r_id` int(11) NOT NULL DEFAULT '0',
  `vr_id` varchar(45) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `type` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  `remarks` varchar(500) COLLATE latin1_general_ci DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `report_config`
--

CREATE TABLE IF NOT EXISTS `report_config` (
  `report_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `header` varchar(500) NOT NULL DEFAULT '',
  `footer` varchar(500) NOT NULL DEFAULT '-End-',
  `margins` varchar(45) NOT NULL DEFAULT '2,0,10,0',
  `p_fields` varchar(45) NOT NULL DEFAULT '1,1,1,1,1,1,1',
  `s_fields` varchar(45) NOT NULL DEFAULT '1,1,1,1,1,1',
  `t_fields` varchar(45) NOT NULL DEFAULT '1,0,1,1,1,0,1,1',
  `p_custom_fields` varchar(45) NOT NULL DEFAULT '',
  `s_custom_fields` varchar(45) NOT NULL DEFAULT '',
  `test_type_id` varchar(45) NOT NULL DEFAULT '0',
  `title` varchar(500) NOT NULL DEFAULT '',
  `landscape` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`report_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=267 ;

--
-- Dumping data for table `report_config`
--

INSERT INTO `report_config` (`report_id`, `header`, `footer`, `margins`, `p_fields`, `s_fields`, `t_fields`, `p_custom_fields`, `s_custom_fields`, `test_type_id`, `title`, `landscape`) VALUES
(1, 'BUNGOMA DISTRICT HOSPITAL LABORATORY<br>BUNGOMA TOWN, HOSPITAL ROAD<br>OPPOSITE POLICE LINE/DISTRICT<br>HEADQUARTERS<br>P.O. BOX 14,<br>BUNGOMA TOWN.<br>Phone: +254 055-30401 Ext 203/208??center', 'Performed by: [TEST_PERFORMER];          Verified by: [TEST_VERIFIER]#([DESIGNATION_PERFORMER]);          ([DESIGNATION_VERIFIER])', '2,0,3,3', '1,1,0,1,1,0,1,1,0', '1,0,1,1,0,1,1', '1,1,1,1,1,1,0,1,1,0', '', '', '0', 'LABORATORY REPORT<br>', 0),
(2, 'Specimen Report', '-End-', '2,0,10,0', '1,1,1,1,1,1,1', '1,1,1,1,1,1', '1,0,1,1,1,0,1,1', '', '', '0', '', 0),
(3, 'Test Records', '-End-', '2,0,10,0', '1,1,1,1,1,1,1', '1,1,1,1,1,1', '1,0,1,1,1,0,1,1', '', '', '0', '', 0),
(4, 'BUEA REGIONAL HOSPITAL LABORATORY', '-End-', '2,0,10,0', '1,1,0,1,1,0,0', '1,0,1,0,0,1,0', '1,1,1,1,1,0,1,1', '', '', '0', 'Daily Log - Specimens', 0),
(5, 'Worksheet', '', '2,0,10,0', '0,1,0,1,1,0,0', '0,0,1,1,0,1', '1,0,1,1,1,0,1,1', '', '1', '0', '', 0),
(6, 'Buea Regional Hospital Laboratory', '-End-', '2,0,10,0', '1,0,0,1,1,0,1', '1,1,1,1,1,1,0', '1,0,1,1,1,0,1,1', '', '', '0', 'Daily Log - Patients', 0),
(7, 'Worksheet - ALT/SGPT', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '8', '', 0),
(8, 'Worksheet - Hepatitis B', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '48', '', 0),
(9, 'Worksheet - Blood Urea Nitrogen', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '21', '', 0),
(10, 'Worksheet - AST/SGOT', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '18', '', 0),
(11, 'Worksheet - Chloride', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '1,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '25', '', 0),
(12, 'Worksheet - Cholesterol', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '27', '', 0),
(13, 'Worksheet - Creatinine', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '22', '', 0),
(14, 'Worksheet - CSF', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '60', '', 0),
(15, 'Worksheet - Gamma Glutamyl', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '55', '', 0),
(16, 'Worksheet - FBS', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '9', '', 0),
(17, 'Worksheet - HDL Cholesterol', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '29', '', 0),
(18, 'Worksheet - LDL Cholesterol', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '30', '', 0),
(19, 'Worksheet - Magnesium', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '14', '', 0),
(20, 'Worksheet - Potassium', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '24', '', 0),
(21, 'Worksheet - Sodium', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '23', '', 0),
(22, 'Worksheet - Total Bilirubin', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '20', '', 0),
(23, 'Worksheet - Triglycerides', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '28', '', 0),
(24, 'Worksheet - Bleeding Time (BT)', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '70', '', 0),
(25, 'Worksheet - Blood Type (ABO/Rh)', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '63', '', 0),
(26, 'Worksheet - Clotting Time (CT)', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '54', '', 0),
(27, 'Worksheet - Complete Blood Count', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '39', '', 0),
(28, 'Worksheet - ESR (Sed rate)', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '51', '', 0),
(29, 'Worksheet - HGB', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '40', '', 0),
(30, 'Worksheet - White Blood Cell Count', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '52', '', 0),
(31, 'Worksheet - C-Reactive Protein', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '68', '', 0),
(32, 'Worksheet - Rheumatoid Factor', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '59', '', 0),
(33, 'Worksheet - Toxoplasma', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '67', '', 0),
(34, 'Worksheet - TPHA', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '66', '', 0),
(35, 'Worksheet - VDRL', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '58', '', 0),
(36, 'Worksheet - Sperm Count', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '65', '', 0),
(37, 'Worksheet - Stool Analysis', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '71', '', 0),
(38, 'Worksheet - Zn Stain', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '69', '', 0),
(39, 'Worksheet - HIV DNA PCR', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '41', '', 0),
(41, 'Worksheet - Malaria', 'Signature of Technician', '5,0,5,0', '0,1,0,0,0,0,0', '1,0,1,0,0,0,0', '1,0,0,0,0,0,0,0', '', '', '38', '', 0),
(42, 'Worksheet - Culture', 'Name of Technician', '5,0,5,0', '0,1,0,1,1,0,0', '1,0,1,0,0,1,0', '1,0,1,0,0,0,0,1', '', '', '89', '', 1),
(43, 'Worksheet - Alb', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '90', '', 0),
(44, 'Worksheet - Sugar', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '91', '', 0),
(45, 'Worksheet - Calcium', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '12', '', 0),
(46, 'Worksheet - Lipid Panel', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '35', '', 0),
(47, 'Worksheet - Uric Acid', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '11', '', 0),
(48, 'Worksheet - ASLO', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '92', '', 0),
(49, 'Worksheet - Widal', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '93', '', 0),
(50, 'Worksheet - PSA', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '94', '', 0),
(51, 'Worksheet - chlamydia', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '95', '', 0),
(52, 'Worksheet - H.pylori', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '96', '', 0),
(53, 'Worksheet - Pregnancy test', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '97', '', 0),
(54, 'Worksheet - Random Blood Sugar', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '84', '', 0),
(55, 'Worksheet - Blood filaria', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '98', '', 0),
(56, 'Worksheet - Macroscopic Examination', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '99', '', 0),
(57, 'Worksheet - Microscopy', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '100', '', 0),
(58, 'Worksheet - Cytobacteriologic Examination of Urine (CBEU)', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '101', '', 0),
(59, 'Worksheet - examen bacteriologique', '-End-', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '88', '', 0),
(60, 'Worksheet - Hepatitis C', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '57', '', 0),
(61, 'Worksheet - Strip Urinalysis', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '102', '', 0),
(62, 'Worksheet - Pregnancy Test (HCG)', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '61', '', 0),
(63, 'Worksheet - UREA', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '103', '', 0),
(64, 'Worksheet - Conjugate/Direct Bilirubin', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '105', '', 0),
(65, 'Worksheet - SKIN SNIP', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '106', '', 0),
(66, 'Worksheet - FACSCount', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '7', '', 0),
(67, 'Worksheet - T-Lymphocytes CD4', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '86', '', 0),
(68, 'Worksheet - T Lymphocyte CD3', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '108', '', 0),
(69, 'Worksheet - T Lymphocyte CD4/CD8', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '109', '', 0),
(70, 'Worksheet - T Lymphocyte CD8', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '107', '', 0),
(71, 'Worksheet - CD4', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '110', '', 0),
(72, 'Worksheet - Total Protein', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '10', '', 0),
(73, 'Worksheet - Serum Albumin', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '111', '', 0),
(74, 'Grouped Test Count Report Configuration', '0:4,4:9,9:14,14:19,19:24,24:29,29:34,34:39,39:44,44:49,49:54,54:59,59:64,64:+', '0', '1', '1', '1', '1', '0', '9999009', '0', 9999009),
(75, 'Grouped Specimen Count Report Configuration', '0:4,4:9,9:14,14:19,19:24,24:29,29:34,34:39,39:44,44:49,49:54,54:59,59:64,64:+', '0', '1', '1', '1', '1', '0', '9999019', '0', 9999019),
(77, 'Daily reports - Patient Varcode Config', '-End-', '2,0,7,0', '1,1,1,1,1,1,1', '1,1,1,1,1,1', '1,0,1,1,1,0,1,1', '', '', '0', 'Patient Barcode<br>', 0),
(78, 'Worksheet - BS for mps', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '291', '', 0),
(79, 'Worksheet - ALAT', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '137', '', 0),
(80, 'Worksheet - ASAT', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '135', '', 0),
(81, 'Worksheet - Ascitic tap for microscopy', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '277', '', 0),
(82, 'Worksheet - Aspirate for culture and sensitivity', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '269', '', 0),
(83, 'Worksheet - Stool for O/C', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '290', '', 0),
(84, 'Worksheet - Albumin', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '133', '', 0),
(85, 'Worksheet - Alkaline Phosphate', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '134', '', 0),
(86, 'Worksheet - Ascitic tap for biochemistry', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '127', '', 0),
(87, 'Worksheet - Ascitic tap for culture & sensitivity', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '276', '', 0),
(88, 'Worksheet - Asot', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '299', '', 0),
(89, 'Worksheet - Asot Titration', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '296', '', 0),
(90, 'Worksheet - Aspirate for microscopy ', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '270', '', 0),
(91, 'Worksheet - Bacteria', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '161', '', 0),
(92, 'Worksheet - Baso#', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '176', '', 0),
(93, 'Worksheet - Bilirubin', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '170', '', 0),
(94, 'Worksheet - Bilirubin', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '140', '', 0),
(95, 'Worksheet - Bleeding time test', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '194', '', 0),
(96, 'Worksheet - Blood', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '171', '', 0),
(97, 'Worksheet - Blood Culture & sensitivity', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '283', '', 0),
(98, 'Worksheet - Blood Grouping', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '154', '', 0),
(99, 'Worksheet - Blood sugar', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '159', '', 0),
(100, 'Worksheet - Borrelia', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '292', '', 0),
(101, 'Worksheet - Brucella', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '302', '', 0),
(102, 'Worksheet - calcium', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '121', '', 0),
(103, 'Worksheet - CALCIUM', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '122', '', 0),
(104, 'Worksheet - calcium', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '124', '', 0),
(105, 'Worksheet - CD4', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '305', '', 0),
(106, 'Worksheet - cell count', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '260', '', 0),
(107, 'Worksheet - cell count', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '258', '', 0),
(108, 'Worksheet - Chloride', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '142', '', 0),
(109, 'Worksheet - Clotting time test', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '195', '', 0),
(110, 'Worksheet - Creatinine ', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '146', '', 0),
(111, 'Worksheet - Cross Match', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '155', '', 0),
(112, 'Worksheet - CSF', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '287', '', 0),
(113, 'Worksheet - CSF for biochemistry', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '130', '', 0),
(114, 'Worksheet - CSF for microbiology', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '265', '', 0),
(115, 'Worksheet - culture', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '248', '', 0),
(116, 'Worksheet - culture', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '200', '', 0),
(117, 'Worksheet - culture', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '246', '', 0),
(118, 'Worksheet - culture ', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '254', '', 0),
(119, 'Worksheet - CULTURE', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '215', '', 0),
(120, 'Worksheet - culture', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '203', '', 0),
(121, 'Worksheet - culture', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '220', '', 0),
(122, 'Worksheet - CULTURE', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '228', '', 0),
(123, 'Worksheet - culture', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '240', '', 0),
(124, 'Worksheet - culture', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '234', '', 0),
(125, 'Worksheet - culture and sensitivity', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '263', '', 0),
(126, 'Worksheet - Direct ', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '138', '', 0),
(127, 'Worksheet - Direct COOMBS test', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '152', '', 0),
(128, 'Worksheet - Du test', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '153', '', 0),
(129, 'Worksheet - Electrolytes', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '145', '', 0),
(130, 'Worksheet - Eos#', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '177', '', 0),
(131, 'Worksheet - Epithelial cells', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '156', '', 0),
(132, 'Worksheet - ESR', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '198', '', 0),
(133, 'Worksheet - Full Haemogram', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '193', '', 0),
(134, 'Worksheet - Glucose', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '174', '', 0),
(135, 'Worksheet - Glucose', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '128', '', 0),
(136, 'Worksheet - Glucose', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '125', '', 0),
(137, 'Worksheet - Gram stain', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '281', '', 0),
(138, 'Worksheet - Grams stain', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '117', '', 0),
(139, 'Worksheet - gRAMSTAIN', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '216', '', 0),
(140, 'Worksheet - Gramstain', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '229', '', 0),
(141, 'Worksheet - gramstain', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '207', '', 0),
(142, 'Worksheet - gramstain', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '209', '', 0),
(143, 'Worksheet - Gramstain', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '202', '', 0),
(144, 'Worksheet - gramstain', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '213', '', 0),
(145, 'Worksheet - Gramstain', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '231', '', 0),
(146, 'Worksheet - Gramstain', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '257', '', 0),
(147, 'Worksheet - Gramstain ', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '262', '', 0),
(148, 'Worksheet - Gramstain', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '251', '', 0),
(149, 'Worksheet - Gramstain', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '249', '', 0),
(150, 'Worksheet - Gramstain', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '243', '', 0),
(151, 'Worksheet - Gramstain', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '241', '', 0),
(152, 'Worksheet - Gramstain', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '238', '', 0),
(153, 'Worksheet - Gramstain', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '235', '', 0),
(154, 'Worksheet - GXM', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '150', '', 0),
(155, 'Worksheet - H pylori', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '304', '', 0),
(156, 'Worksheet - HB', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '183', '', 0),
(157, 'Worksheet - HCG', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '168', '', 0),
(158, 'Worksheet - HCT', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '184', '', 0),
(159, 'Worksheet - HEPATITIS B', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '295', '', 0),
(160, 'Worksheet - HEPATITIS C', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '294', '', 0),
(161, 'Worksheet - HVS for culture and sensitivity', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '284', '', 0),
(162, 'Worksheet - HVS for microscopy ', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '271', '', 0),
(163, 'Worksheet - Indian ink', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '255', '', 0),
(164, 'Worksheet - Indian ink', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '259', '', 0),
(165, 'Worksheet - Indirect COOMBS test', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '151', '', 0),
(166, 'Worksheet - Ketones', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '173', '', 0),
(167, 'Worksheet - KOH for fungi', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '267', '', 0),
(168, 'Worksheet - LFTS', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '141', '', 0),
(169, 'Worksheet - Lym#', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '179', '', 0),
(170, 'Worksheet - MCH', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '186', '', 0),
(171, 'Worksheet - MCHC', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '187', '', 0),
(172, 'Worksheet - MCV', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '185', '', 0),
(173, 'Worksheet - microscopic examination', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '222', '', 0),
(174, 'Worksheet - microscopy', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '221', '', 0),
(175, 'Worksheet - microscopy', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '264', '', 0),
(176, 'Worksheet - microscopy', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '204', '', 0),
(177, 'Worksheet - microscopy', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '211', '', 0),
(178, 'Worksheet - Mon#', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '178', '', 0),
(179, 'Worksheet - motility', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '224', '', 0),
(180, 'Worksheet - MPV', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '191', '', 0),
(181, 'Worksheet - Neu#', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '180', '', 0),
(182, 'Worksheet - OCCULT BLOOD', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '289', '', 0),
(183, 'Worksheet - PBF', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '293', '', 0),
(184, 'Worksheet - PCT', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '190', '', 0),
(185, 'Worksheet - PDW', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '192', '', 0),
(186, 'Worksheet - ph', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '158', '', 0),
(187, 'Worksheet - PLATELET COUNT', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '189', '', 0),
(188, 'Worksheet - Pleural tap for culture and sensitivity', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '274', '', 0),
(189, 'Worksheet - Pleural tap for microscopy', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '275', '', 0),
(190, 'Worksheet - Potassium', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '143', '', 0),
(191, 'Worksheet - Pregnancy test', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '300', '', 0),
(192, 'Worksheet - Protein', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '126', '', 0),
(193, 'Worksheet - Protein', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '129', '', 0),
(194, 'Worksheet - Proteins', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '172', '', 0),
(195, 'Worksheet - PSA', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '131', '', 0),
(196, 'Worksheet - PTI/INR', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '196', '', 0),
(197, 'Worksheet - Pus cells', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '166', '', 0),
(198, 'Worksheet - Pus swab for culture and sensitivity', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '266', '', 0),
(199, 'Worksheet - RBC', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '182', '', 0),
(200, 'Worksheet - RDW', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '188', '', 0),
(201, 'Worksheet - Red blood cells', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '162', '', 0),
(202, 'Worksheet - RF', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '301', '', 0),
(203, 'Worksheet - RFTS', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '148', '', 0),
(204, 'Worksheet - S. haematobium', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '165', '', 0),
(205, 'Worksheet - salmonella antigen test', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '288', '', 0),
(206, 'Worksheet - semen analysis', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '268', '', 0),
(207, 'Worksheet - sensitivity', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '227', '', 0),
(208, 'Worksheet - sensitivity', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '253', '', 0),
(209, 'Worksheet - sensitivity', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '247', '', 0),
(210, 'Worksheet - sensitivity', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '233', '', 0),
(211, 'Worksheet - SENSITIVITY', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '214', '', 0),
(212, 'Worksheet - sensitivity', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '219', '', 0),
(213, 'Worksheet - sensitivity', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '239', '', 0),
(214, 'Worksheet - sensitivity', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '208', '', 0),
(215, 'Worksheet - sensitivity', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '199', '', 0),
(216, 'Worksheet - sensitivity', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '205', '', 0),
(217, 'Worksheet - sensitivity', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '245', '', 0),
(218, 'Worksheet - SERUM AMYLASE', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '120', '', 0),
(219, 'Worksheet - SGOT', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '136', '', 0),
(220, 'Worksheet - Sickling test', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '197', '', 0),
(221, 'Worksheet - Sodium', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '144', '', 0),
(222, 'Worksheet - sperm count', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '223', '', 0),
(223, 'Worksheet - Spermatozoa', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '160', '', 0),
(224, 'Worksheet - Sputum', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '285', '', 0),
(225, 'Worksheet - Stool for C/S', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '286', '', 0),
(226, 'Worksheet - Sub culture ', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '282', '', 0),
(227, 'Worksheet - Synovial fluid for culture and sensitivity', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '272', '', 0),
(228, 'Worksheet - Synovial fluid for microscopy', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '273', '', 0),
(229, 'Worksheet - T. vaginalis', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '164', '', 0),
(230, 'Worksheet - TFT', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '149', '', 0),
(231, 'Worksheet - Throat swab for culture', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '218', '', 0),
(232, 'Worksheet - Total', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '132', '', 0),
(233, 'Worksheet - Total Proteins ', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '139', '', 0),
(234, 'Worksheet - Urea', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '147', '', 0),
(235, 'Worksheet - URIC ACID', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '123', '', 0),
(236, 'Worksheet - Urinalysis', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '157', '', 0),
(237, 'Worksheet - urine chemistry', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '212', '', 0),
(238, 'Worksheet - urine chemistry', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '210', '', 0),
(239, 'Worksheet - Urine chemistry', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '175', '', 0),
(240, 'Worksheet - urine chemistry', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '119', '', 0),
(241, 'Worksheet - Urine Culture & Sensitivity', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '278', '', 0),
(242, 'Worksheet - Urine microscopy', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '167', '', 0),
(243, 'Worksheet - Urobilinogen Phenlpyruvic acid', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '169', '', 0),
(244, 'Worksheet - VDRL', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '298', '', 0),
(245, 'Worksheet - viscosity', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '225', '', 0),
(246, 'Worksheet - volume', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '226', '', 0),
(247, 'Worksheet - Water Analysis', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '279', '', 0),
(248, 'Worksheet - WBC', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '181', '', 0),
(249, 'Worksheet - wet prep', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '242', '', 0),
(250, 'Worksheet - Wet prep', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '280', '', 0),
(251, 'Worksheet - wet prep', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '244', '', 0),
(252, 'Worksheet - Widal', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '303', '', 0),
(253, 'Worksheet - Widal Titration', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '297', '', 0),
(254, 'Worksheet - Yeast cells', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '163', '', 0),
(255, 'Worksheet - zn stain', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '206', '', 0),
(256, 'Worksheet - ZN stain', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '201', '', 0),
(257, 'Worksheet - ZN stain', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '118', '', 0),
(258, 'Worksheet - ZN stain', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '250', '', 0),
(259, 'Worksheet - ZN STAIN', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '230', '', 0),
(260, 'Worksheet - ZN stain', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '252', '', 0),
(261, 'Worksheet - ZN stain', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '256', '', 0),
(262, 'Worksheet - ZN stain', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '237', '', 0),
(263, 'Worksheet - zn STAIN ', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '217', '', 0),
(264, 'Worksheet - ZN stain', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '236', '', 0),
(265, 'Worksheet - ZN stain', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '261', '', 0),
(266, 'Worksheet - ZN stain', '', '5,0,5,0', '0,1,0,1,1,0,0', '0,0,1,1,0,0', '1,0,1,0,0,0,0,1', '', '', '232', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `report_disease`
--

CREATE TABLE IF NOT EXISTS `report_disease` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_by_age` int(10) unsigned NOT NULL,
  `group_by_gender` int(10) unsigned NOT NULL,
  `age_groups` varchar(500) DEFAULT NULL,
  `measure_groups` varchar(500) DEFAULT NULL,
  `measure_id` int(10) unsigned NOT NULL,
  `lab_config_id` int(10) unsigned NOT NULL,
  `test_type_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `measure_id` (`measure_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `sanitas_tests_live`
--

CREATE TABLE IF NOT EXISTS `sanitas_tests_live` (
  `result_type` varchar(17) DEFAULT NULL,
  `order_in` varchar(22) DEFAULT NULL,
  `default` varchar(8) DEFAULT NULL,
  `description` varchar(11) DEFAULT NULL,
  `category` varchar(18) DEFAULT NULL,
  `name` varchar(42) DEFAULT NULL,
  `parent_test` varchar(42) DEFAULT NULL,
  `specimen` varchar(17) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sanitas_tests_live`
--

INSERT INTO `sanitas_tests_live` (`result_type`, `order_in`, `default`, `description`, `category`, `name`, `parent_test`, `specimen`) VALUES
('Positive/Negative', 'false', 'false', '', 'BACTERIOLOGY', 'Grams stain', 'Aspirate for microscopy ', 'Aspirate'),
('$freetext$$', 'false', 'false', '', 'BACTERIOLOGY', 'ZN stain', 'Aspirate for microscopy ', 'Aspirate'),
('$freetext$$', 'false', 'false', '', 'BACTERIOLOGY', 'urine chemistry', 'Urine Culture & Sensitivity', 'Urine'),
('Low/Normal/High', 'true', 'false', '', 'BIOCHEMISTRY', 'SERUM AMYLASE', 'N/A', 'Serum'),
('Low/Normal/High', 'true', 'false', '', 'BIOCHEMISTRY', 'calcium', 'N/A', 'Serum'),
('Low/Normal/High', 'true', 'false', '', 'BIOCHEMISTRY', 'CALCIUM', 'urine chemistry', 'Serum'),
('Low/Normal/High', 'true', 'false', '', 'BIOCHEMISTRY', 'URIC ACID', 'N/A', 'Serum'),
('Low/Normal/High', 'true', 'false', '', 'BIOCHEMISTRY', 'calcium', 'N/A', 'Serum'),
('$freetext$$', 'false', 'true', '', 'BIOCHEMISTRY', 'Glucose', 'Ascitic tap for biochemistry', 'Ascitic Tap'),
('$freetext$$', 'false', 'true', '', 'BIOCHEMISTRY', 'Protein', 'Ascitic tap for biochemistry', 'Ascitic Tap'),
('$freetext$$', 'true', 'true', '', 'BIOCHEMISTRY', 'Ascitic tap for biochemistry', 'N/A', 'Ascitic Tap'),
('Low/Normal/High', 'false', 'true', '', 'BIOCHEMISTRY', 'Glucose', 'CSF for biochemistry', 'CSF'),
('$freetext$$', 'false', 'true', '', 'BIOCHEMISTRY', 'Protein', 'CSF for biochemistry', 'CSF'),
('$freetext$$', 'true', 'true', '', 'BIOCHEMISTRY', 'CSF for biochemistry', 'CSF', 'CSF'),
('$freetext$$', 'false', 'false', '', 'BIOCHEMISTRY', 'PSA', 'N/A', 'Serum'),
('Low/Normal/High', 'false', 'true', '', 'BIOCHEMISTRY', 'Total', 'Bilirubin', 'Serum'),
('Low/Normal/High', 'false', 'true', '', 'BIOCHEMISTRY', 'Albumin', 'LFTS', 'Serum'),
('Low/Normal/High', 'false', 'true', '', 'BIOCHEMISTRY', 'Alkaline Phosphate', 'LFTS', 'Serum'),
('Low/Normal/High', 'false', 'true', '', 'BIOCHEMISTRY', 'ASAT', 'LFTS', 'Serum'),
('Low/Normal/High', 'false', 'true', '', 'BIOCHEMISTRY', 'SGOT', 'LFTS', 'Serum'),
('Low/Normal/High', 'false', 'true', '', 'BIOCHEMISTRY', 'ALAT', 'LFTS', 'Serum'),
('Low/Normal/High', 'false', 'true', '', 'BIOCHEMISTRY', 'Direct ', 'Bilirubin', 'Serum'),
('Low/Normal/High', 'true', 'true', '', 'BIOCHEMISTRY', 'Total Proteins ', 'LFTS', 'Serum'),
('Low/Normal/High', 'true', 'true', '', 'BIOCHEMISTRY', 'Bilirubin', 'LFTS', 'Serum'),
('$freetext$$', 'true', 'true', '', 'BIOCHEMISTRY', 'LFTS', 'N/A', 'Serum'),
('Low/Normal/High', 'false', 'true', '', 'BIOCHEMISTRY', 'Chloride', 'Electrolytes', 'Serum'),
('Low/Normal/High', 'false', 'true', '', 'BIOCHEMISTRY', 'Potassium', 'Electrolytes', 'Serum'),
('Low/Normal/High', 'false', 'true', '', 'BIOCHEMISTRY', 'Sodium', 'Electrolytes', 'Serum'),
('$freetext$$', 'true', 'true', '', 'BIOCHEMISTRY', 'Electrolytes', 'RFTS', 'Serum'),
('Low/Normal/High', 'true', 'true', '', 'BIOCHEMISTRY', 'Creatinine ', 'RFTS', 'Serum'),
('Low/Normal/High', 'true', 'true', '', 'BIOCHEMISTRY', 'Urea', 'RFTS', 'Serum'),
('$freetext$$', 'true', 'true', '', 'BIOCHEMISTRY', 'RFTS', 'N/A', 'Serum'),
('$freetext$$', 'false', 'false', '', 'BIOCHEMISTRY', 'TFT', 'N/A', 'Serum'),
('$freetext$$', 'false', 'true', '', 'BLOOD TRANSFUSION', 'GXM', 'N/A', 'Whole Blood'),
('Positive/Negative', 'false', 'false', '', 'BLOOD TRANSFUSION', 'Indirect COOMBS test', 'N/A', 'Whole Blood'),
('Positive/Negative', 'false', 'false', '', 'BLOOD TRANSFUSION', 'Direct COOMBS test', 'N/A', 'Whole Blood'),
('Positive/Negative', 'false', 'false', '', 'BLOOD TRANSFUSION', 'Du test', 'N/A', 'Whole Blood'),
('$freetext$$', 'true', 'true', '', 'BLOOD TRANSFUSION', 'Blood Grouping', 'GXM', 'Whole Blood'),
('$freetext$$', 'false', 'true', '', 'BLOOD TRANSFUSION', 'Cross Match', 'GXM', 'Whole Blood'),
('$freetext$$', 'false', 'true', '', 'CLINICAL CHEMISTRY', 'Epithelial cells', 'Urine microscopy', 'Urine'),
('$freetext$$', 'false', 'false', '', 'CLINICAL CHEMISTRY', 'Urinalysis', 'N/A', 'Urine'),
('$freetext$$', 'false', 'true', '', 'CLINICAL CHEMISTRY', 'ph', 'Urine chemistry', 'Urine'),
('Low/Normal/High', 'false', 'false', '', 'CLINICAL CHEMISTRY', 'Blood sugar', 'N/A', 'Urine'),
('$freetext$$', 'false', 'true', '', 'CLINICAL CHEMISTRY', 'Spermatozoa', 'Urine microscopy', 'Urine'),
('$freetext$$', 'false', 'true', '', 'CLINICAL CHEMISTRY', 'Bacteria', 'Urine microscopy', 'Urine'),
('$freetext$$', 'false', 'true', '', 'CLINICAL CHEMISTRY', 'Red blood cells', 'Urine microscopy', 'Urine'),
('$freetext$$', 'false', 'true', '', 'CLINICAL CHEMISTRY', 'Yeast cells', 'Urine microscopy', 'Urine'),
('$freetext$$', 'false', 'true', '', 'CLINICAL CHEMISTRY', 'T. vaginalis', 'Urine microscopy', 'Urine'),
('$freetext$$', 'false', 'true', '', 'CLINICAL CHEMISTRY', 'S. haematobium', 'Urine microscopy', 'Urine'),
('$freetext$$', 'false', 'true', '', 'CLINICAL CHEMISTRY', 'Pus cells', 'Urine microscopy', 'Urine'),
('Positive/Negative', 'true', 'false', '', 'CLINICAL CHEMISTRY', 'Urine microscopy', 'Urinalysis', 'Urine'),
('$freetext$$', 'false', 'false', '', 'CLINICAL CHEMISTRY', 'HCG', 'Urine chemistry', 'Urine'),
('$freetext$$', 'false', 'true', '', 'CLINICAL CHEMISTRY', 'Urobilinogen Phenlpyruvic acid', 'Urine chemistry', 'Urine'),
('$freetext$$', 'false', 'true', '', 'CLINICAL CHEMISTRY', 'Bilirubin', 'Urine chemistry', 'Urine'),
('$freetext$$', 'false', 'true', '', 'CLINICAL CHEMISTRY', 'Blood', 'Urine chemistry', 'Urine'),
('$freetext$$', 'false', 'true', '', 'CLINICAL CHEMISTRY', 'Proteins', 'Urine chemistry', 'Urine'),
('$freetext$$', 'false', 'true', '', 'CLINICAL CHEMISTRY', 'Ketones', 'Urine chemistry', 'Urine'),
('$freetext$$', 'false', 'true', '', 'CLINICAL CHEMISTRY', 'Glucose', 'Urine chemistry', 'Urine'),
('$freetext$$', 'true', 'false', '', 'CLINICAL CHEMISTRY', 'Urine chemistry', 'Urinalysis', 'Urine'),
('$freetext$$', 'false', 'true', '', 'HEMATOLOGY', 'Baso#', 'WBC', 'Whole Blood'),
('$freetext$$', 'false', 'true', '', 'HEMATOLOGY', 'Eos#', 'WBC', 'Whole Blood'),
('$freetext$$', 'false', 'true', '', 'HEMATOLOGY', 'Mon#', 'WBC', 'Whole Blood'),
('$freetext$$', 'false', 'true', '', 'HEMATOLOGY', 'Lym#', 'WBC', 'Whole Blood'),
('$freetext$$', 'false', 'true', '', 'HEMATOLOGY', 'Neu#', 'WBC', 'Whole Blood'),
('$freetext$$', 'false', 'true', '', 'HEMATOLOGY', 'WBC', 'Full Haemogram', 'Whole Blood'),
('$freetext$$', 'false', 'true', '', 'HEMATOLOGY', 'RBC', 'Full Haemogram', 'Whole Blood'),
('$freetext$$', 'true', 'true', '', 'HEMATOLOGY', 'HB', 'Full Haemogram', 'Whole Blood'),
('$freetext$$', 'false', 'true', '', 'HEMATOLOGY', 'HCT', 'Full Haemogram', 'Whole Blood'),
('$freetext$$', 'false', 'true', '', 'HEMATOLOGY', 'MCV', 'Full Haemogram', 'Whole Blood'),
('$freetext$$', 'false', 'true', '', 'HEMATOLOGY', 'MCH', 'Full Haemogram', 'Whole Blood'),
('$freetext$$', 'false', 'true', '', 'HEMATOLOGY', 'MCHC', 'Full Haemogram', 'Whole Blood'),
('$freetext$$', 'false', 'false', '', 'HEMATOLOGY', 'RDW', 'Full Haemogram', 'Whole Blood'),
('$freetext$$', 'true', 'true', '', 'HEMATOLOGY', 'PLATELET COUNT', 'Full Haemogram', 'Whole Blood'),
('$freetext$$', 'false', 'false', '', 'HEMATOLOGY', 'PCT', 'Full Haemogram', 'Whole Blood'),
('$freetext$$', 'false', 'false', '', 'HEMATOLOGY', 'MPV', 'Full Haemogram', 'Whole Blood'),
('$freetext$$', 'false', 'false', '', 'HEMATOLOGY', 'PDW', 'Full Haemogram', 'Whole Blood'),
('$freetext$$', 'false', 'false', '', 'HEMATOLOGY', 'Full Haemogram', 'N/A', 'Whole Blood'),
('$freetext$$', 'false', 'false', '', 'HEMATOLOGY', 'Bleeding time test', 'N/A', 'Whole Blood'),
('$freetext$$', 'false', 'false', '', 'HEMATOLOGY', 'Clotting time test', 'N/A', 'Whole Blood'),
('$freetext$$', 'false', 'false', '', 'HEMATOLOGY', 'PTI/INR', 'N/A', 'Whole Blood'),
('Positive/Negative', 'true', 'true', '', 'HEMATOLOGY', 'Sickling test', 'N/A', 'Whole Blood'),
('Low/Normal/High', 'false', 'false', '', 'HEMATOLOGY', 'ESR', 'N/A', 'Whole Blood'),
('$freetext$$', 'false', 'false', '', 'MICROBIOLOGY', 'sensitivity', 'Pus swab for culture and sensitivity', 'Pus Swab'),
('$freetext$$', 'false', 'false', '', 'MICROBIOLOGY', 'culture', 'Pus swab for culture and sensitivity', 'Pus Swab'),
('Positive/Negative', 'false', 'false', '', 'MICROBIOLOGY', 'ZN stain', 'Pus swab for culture and sensitivity', 'Pus Swab'),
('$freetext$$', 'false', 'true', '', 'MICROBIOLOGY', 'Gramstain', 'Pus swab for culture and sensitivity', 'Pus Swab'),
('$freetext$$', 'false', 'false', '', 'MICROBIOLOGY', 'culture', 'Urine Culture & Sensitivity', 'Urine'),
('$freetext$$', 'false', 'false', '', 'MICROBIOLOGY', 'microscopy', 'Urine Culture & Sensitivity', 'Urine'),
('$freetext$$', 'false', 'false', '', 'MICROBIOLOGY', 'sensitivity', 'Aspirate for culture and sensitivity', 'Aspirate'),
('Positive/Negative', 'false', 'false', '', 'MICROBIOLOGY', 'zn stain', 'Aspirate for culture and sensitivity', 'Aspirate'),
('Positive/Negative', 'false', 'false', '', 'MICROBIOLOGY', 'gramstain', 'Aspirate for culture and sensitivity', 'Aspirate'),
('$freetext$$', 'false', 'false', '', 'MICROBIOLOGY', 'sensitivity', 'Urine Culture & Sensitivity', 'Urine'),
('$freetext$$', 'false', 'false', '', 'MICROBIOLOGY', 'gramstain', 'Urine Culture & Sensitivity', 'Urine'),
('$freetext$$', 'false', 'false', '', 'MICROBIOLOGY', 'urine chemistry', 'Urine Culture & Sensitivity', 'Urine'),
('$freetext$$', 'false', 'false', '', 'MICROBIOLOGY', 'microscopy', 'Urine Culture & Sensitivity', 'Urine'),
('$freetext$$', 'false', 'false', '', 'MICROBIOLOGY', 'urine chemistry', 'Urine Culture & Sensitivity', 'Urine'),
('$freetext$$', 'false', 'true', '', 'MICROBIOLOGY', 'gramstain', 'Throat swab for culture', 'Throat Swab'),
('$freetext$$', 'false', 'true', '', 'MICROBIOLOGY', 'SENSITIVITY', 'Throat swab for culture', 'Throat Swab'),
('Positive/Negative', 'false', 'true', '', 'MICROBIOLOGY', 'CULTURE', 'Throat swab for culture', 'Throat Swab'),
('Positive/Negative', 'false', 'true', '', 'MICROBIOLOGY', 'gRAMSTAIN', 'Throat swab for culture', 'Throat Swab'),
('Positive/Negative', 'false', 'true', '', 'MICROBIOLOGY', 'zn STAIN ', 'Throat swab for culture', 'Throat Swab'),
('$freetext$$', 'true', 'true', '', 'MICROBIOLOGY', 'Throat swab for culture', 'N/A', 'Throat Swab'),
('$freetext$$', 'false', 'true', '', 'MICROBIOLOGY', 'sensitivity', 'Stool for C/S', 'Stool'),
('$freetext$$', 'false', 'true', '', 'MICROBIOLOGY', 'culture', 'Stool for C/S', 'Stool'),
('$freetext$$', 'false', 'true', '', 'MICROBIOLOGY', 'microscopy', 'Stool for C/S', 'Stool'),
('$freetext$$', 'false', 'true', '', 'MICROBIOLOGY', 'microscopic examination', 'semen analysis', 'Semen'),
('$freetext$$', 'false', 'true', '', 'MICROBIOLOGY', 'sperm count', 'semen analysis', 'Semen'),
('Positive/Negative', 'false', 'true', '', 'MICROBIOLOGY', 'motility', 'semen analysis', 'Semen'),
('Positive/Negative', 'false', 'true', '', 'MICROBIOLOGY', 'viscosity', 'semen analysis', 'Semen'),
('$freetext$$', 'false', 'true', '', 'MICROBIOLOGY', 'volume', 'semen analysis', 'Semen'),
('$freetext$$', 'false', 'true', '', 'MICROBIOLOGY', 'sensitivity', 'Synovial fluid for culture and sensitivity', 'Synovial Fluid'),
('$freetext$$', 'false', 'true', '', 'MICROBIOLOGY', 'CULTURE', 'Synovial fluid for culture and sensitivity', 'Synovial Fluid'),
('$freetext$$', 'false', 'true', '', 'MICROBIOLOGY', 'Gramstain', 'Synovial fluid for culture and sensitivity', 'Synovial Fluid'),
('$freetext$$', 'false', 'true', '', 'MICROBIOLOGY', 'ZN STAIN', 'Synovial fluid for culture and sensitivity', 'Synovial Fluid'),
('Positive/Negative', 'false', 'true', '', 'MICROBIOLOGY', 'Gramstain', 'Synovial fluid for microscopy', 'Synovial Fluid'),
('Positive/Negative', 'false', 'true', '', 'MICROBIOLOGY', 'ZN stain', 'Synovial fluid for microscopy', 'Synovial Fluid'),
('$freetext$$', 'false', 'true', '', 'MICROBIOLOGY', 'sensitivity', 'Pleural tap for culture and sensitivity', 'Pleural Tap'),
('$freetext$$', 'false', 'true', '', 'MICROBIOLOGY', 'culture', 'Pleural tap for culture and sensitivity', 'Pleural Tap'),
('$freetext$$', 'false', 'true', '', 'MICROBIOLOGY', 'Gramstain', 'Pleural tap for culture and sensitivity', 'Pleural Tap'),
('Positive/Negative', 'false', 'true', '', 'MICROBIOLOGY', 'ZN stain', 'Pleural tap for culture and sensitivity', 'Pleural Tap'),
('Positive/Negative', 'false', 'true', '', 'MICROBIOLOGY', 'ZN stain', 'Pleural tap for microscopy', 'Pleural Tap'),
('$freetext$$', 'false', 'true', '', 'MICROBIOLOGY', 'Gramstain', 'Pleural tap for microscopy', 'Pleural Tap'),
('$freetext$$', 'false', 'true', '', 'MICROBIOLOGY', 'sensitivity', 'HVS for culture and sensitivity', 'High Vaginal Swab'),
('$freetext$$', 'false', 'true', '', 'MICROBIOLOGY', 'culture', 'HVS for culture and sensitivity', 'High Vaginal Swab'),
('$freetext$$', 'false', 'true', '', 'MICROBIOLOGY', 'Gramstain', 'HVS for culture and sensitivity', 'High Vaginal Swab'),
('$freetext$$', 'false', 'true', '', 'MICROBIOLOGY', 'wet prep', 'HVS for culture and sensitivity', 'High Vaginal Swab'),
('$freetext$$', 'false', 'true', '', 'MICROBIOLOGY', 'Gramstain', 'HVS for microscopy ', 'High Vaginal Swab'),
('$freetext$$', 'false', 'true', '', 'MICROBIOLOGY', 'wet prep', 'HVS for microscopy ', 'High Vaginal Swab'),
('$freetext$$', 'false', 'true', '', 'MICROBIOLOGY', 'sensitivity', 'Blood Culture & sensitivity', 'Whole Blood'),
('Positive/Negative', 'false', 'true', '', 'MICROBIOLOGY', 'culture', 'Blood Culture & sensitivity', 'Whole Blood'),
('$freetext$$', 'false', 'true', '', 'MICROBIOLOGY', 'sensitivity', 'Ascitic tap for culture & sensitivity', 'Ascitic Tap'),
('$freetext$$', 'false', 'true', '', 'MICROBIOLOGY', 'culture', 'Ascitic tap for culture & sensitivity', 'Ascitic Tap'),
('$freetext$$', 'false', 'true', '', 'MICROBIOLOGY', 'Gramstain', 'ZN stain', 'Ascitic Tap'),
('Positive/Negative', 'false', 'true', '', 'MICROBIOLOGY', 'ZN stain', 'Ascitic tap for culture & sensitivity', 'Ascitic Tap'),
('Positive/Negative', 'false', 'true', '', 'MICROBIOLOGY', 'Gramstain', 'Ascitic tap for microscopy', 'Ascitic Tap'),
('Positive/Negative', 'false', 'true', '', 'MICROBIOLOGY', 'ZN stain', 'Ascitic tap for microscopy', 'Ascitic Tap'),
('$freetext$$', 'false', 'true', '', 'MICROBIOLOGY', 'sensitivity', 'culture and sensitivity', 'CSF'),
('$freetext$$', 'false', 'true', '', 'MICROBIOLOGY', 'culture ', 'culture and sensitivity', 'CSF'),
('Positive/Negative', 'false', 'true', '', 'MICROBIOLOGY', 'Indian ink', 'culture and sensitivity', 'CSF'),
('Positive/Negative', 'false', 'true', '', 'MICROBIOLOGY', 'ZN stain', 'culture and sensitivity', 'CSF'),
('Positive/Negative', 'false', 'true', '', 'MICROBIOLOGY', 'Gramstain', 'culture and sensitivity', 'CSF'),
('Number (count/ml)', 'false', 'true', '', 'MICROBIOLOGY', 'cell count', 'culture and sensitivity', 'CSF'),
('$freetext$$', 'false', 'true', '', 'MICROBIOLOGY', 'Indian ink', 'microscopy', 'CSF'),
('$freetext$$', 'false', 'true', '', 'MICROBIOLOGY', 'cell count', 'microscopy', 'CSF'),
('Positive/Negative', 'false', 'true', '', 'MICROBIOLOGY', 'ZN stain', 'microscopy', 'CSF'),
('$freetext$$', 'false', 'true', '', 'MICROBIOLOGY', 'Gramstain ', 'microscopy', 'CSF'),
('$freetext$$', 'false', 'true', '', 'MICROBIOLOGY', 'culture and sensitivity', 'CSF for microbiology', 'CSF'),
('$freetext$$', 'true', 'true', '', 'MICROBIOLOGY', 'microscopy', 'CSF for microbiology', 'CSF'),
('$freetext$$', 'true', 'true', '', 'MICROBIOLOGY', 'CSF for microbiology', 'CSF', 'CSF'),
('$freetext$$', 'false', 'false', '', 'MICROBIOLOGY', 'Pus swab for culture and sensitivity', 'N/A', 'Pus Swab'),
('Positive/Negative', 'false', 'false', '', 'MICROBIOLOGY', 'KOH for fungi', 'N/A', 'Skin'),
('$freetext$$', 'false', 'false', '', 'MICROBIOLOGY', 'semen analysis', 'N/A', 'Semen'),
('$freetext$$', 'false', 'false', '', 'MICROBIOLOGY', 'Aspirate for culture and sensitivity', 'N/A', 'Aspirate'),
('$freetext$$', 'false', 'false', '', 'MICROBIOLOGY', 'Aspirate for microscopy ', 'N/A', 'Aspirate'),
('$freetext$$', 'false', 'false', '', 'MICROBIOLOGY', 'HVS for microscopy ', 'N/A', 'High Vaginal Swab'),
('$freetext$$', 'false', 'false', '', 'MICROBIOLOGY', 'Synovial fluid for culture and sensitivity', 'N/A', 'Synovial Fluid'),
('$freetext$$', 'false', 'false', '', 'MICROBIOLOGY', 'Synovial fluid for microscopy', 'N/A', 'Synovial Fluid'),
('$freetext$$', 'false', 'false', '', 'MICROBIOLOGY', 'Pleural tap for culture and sensitivity', 'N/A', 'Pleural Tap'),
('$freetext$$', 'false', 'false', '', 'MICROBIOLOGY', 'Pleural tap for microscopy', 'N/A', 'Pleural Tap'),
('$freetext$$', 'false', 'false', '', 'MICROBIOLOGY', 'Ascitic tap for culture & sensitivity', 'N/A', 'Ascitic Tap'),
('$freetext$$', 'false', 'false', '', 'MICROBIOLOGY', 'Ascitic tap for microscopy', 'N/A', 'Ascitic Tap'),
('$freetext$$', 'false', 'false', '', 'MICROBIOLOGY', 'Urine Culture & Sensitivity', 'N/A', 'Urine'),
('$freetext$$', 'false', 'false', '', 'MICROBIOLOGY', 'Water Analysis', 'N/A', 'Water'),
('Positive/Negative', 'false', 'true', '', 'MICROBIOLOGY', 'Wet prep', 'Blood Culture & sensitivity', 'Whole Blood'),
('Positive/Negative', 'false', 'true', '', 'MICROBIOLOGY', 'Gram stain', 'Blood Culture & sensitivity', 'Whole Blood'),
('Positive/Negative', 'false', 'true', '', 'MICROBIOLOGY', 'Sub culture ', 'Blood Culture & sensitivity', 'Whole Blood'),
('$freetext$$', 'true', 'true', '', 'MICROBIOLOGY', 'Blood Culture & sensitivity', 'N/A', 'Whole Blood'),
('$freetext$$', 'false', 'false', '', 'MICROBIOLOGY', 'HVS for culture and sensitivity', 'N/A', 'High Vaginal Swab'),
('Positive/Negative', 'false', 'false', '', 'MICROBIOLOGY', 'Sputum', 'N/A', 'Sputum'),
('$freetext$$', 'false', 'false', '', 'MICROBIOLOGY', 'Stool for C/S', 'N/A', 'Stool'),
('$freetext$$', 'false', 'false', '', 'other', 'CSF', 'N/A', 'CSF'),
('Positive/Negative', 'false', 'false', '', 'PARASITOLOGY', 'salmonella antigen test', 'N/A', 'Serum'),
('Positive/Negative', 'false', 'false', '', 'PARASITOLOGY', 'OCCULT BLOOD', 'N/A', 'Stool'),
('$freetext$$', 'false', 'false', '', 'PARASITOLOGY', 'Stool for O/C', 'N/A', 'Stool'),
('Positive/Negative', 'false', 'false', '', 'PARASITOLOGY', 'BS for mps', 'N/A', 'Whole Blood'),
('Positive/Negative', 'false', 'false', '', 'PARASITOLOGY', 'Borrelia', 'N/A', 'Whole Blood'),
('$freetext$$', 'false', 'true', '', 'SEROLOGY', 'PBF', 'N/A', 'Whole Blood'),
('Positive/Negative', 'false', 'false', '', 'SEROLOGY', 'HEPATITIS C', 'N/A', 'Serum'),
('Positive/Negative', 'false', 'false', '', 'SEROLOGY', 'HEPATITIS B', 'N/A', 'Serum'),
('Positive/Negative', 'false', 'true', '', 'SEROLOGY', 'Asot Titration', 'N/A', 'Serum'),
('Number (count/ml)', 'false', 'false', '', 'SEROLOGY', 'Widal Titration', 'N/A', 'Serum'),
('Positive/Negative', 'false', 'false', '', 'SEROLOGY', 'VDRL', 'N/A', 'Serum'),
('Positive/Negative', 'false', 'false', '', 'SEROLOGY', 'Asot', 'N/A', 'Serum'),
('Positive/Negative', 'false', 'false', '', 'SEROLOGY', 'Pregnancy test', 'N/A', 'Urine'),
('Positive/Negative', 'false', 'false', '', 'SEROLOGY', 'RF', 'N/A', 'Serum'),
('Positive/Negative', 'false', 'false', '', 'SEROLOGY', 'Brucella', 'N/A', 'Serum'),
('Positive/Negative', 'false', 'false', '', 'SEROLOGY', 'Widal', 'N/A', 'Serum'),
('Positive/Negative', 'false', 'false', '', 'SEROLOGY', 'H pylori', 'N/A', 'Serum'),
('Low/Normal/High', 'false', 'false', '', 'VIROLOGY', 'CD4', 'N/A', 'Whole Blood');

-- --------------------------------------------------------

--
-- Table structure for table `specimen`
--

CREATE TABLE IF NOT EXISTS `specimen` (
  `specimen_id` int(10) unsigned NOT NULL DEFAULT '0',
  `patient_id` int(11) unsigned NOT NULL DEFAULT '0',
  `specimen_type_id` int(11) unsigned NOT NULL DEFAULT '0',
  `user_id` int(11) unsigned DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status_code_id` int(11) unsigned DEFAULT NULL,
  `referred_to` int(11) unsigned DEFAULT NULL,
  `comments` text,
  `aux_id` varchar(45) DEFAULT NULL,
  `date_collected` date NOT NULL DEFAULT '0000-00-00',
  `date_recvd` date DEFAULT NULL,
  `session_num` varchar(45) DEFAULT NULL,
  `time_collected` varchar(45) DEFAULT NULL,
  `report_to` int(10) unsigned DEFAULT NULL,
  `doctor` varchar(45) DEFAULT NULL,
  `date_reported` datetime DEFAULT NULL,
  `referred_to_name` varchar(70) DEFAULT NULL,
  `daily_num` varchar(45) NOT NULL DEFAULT '',
  `external_lab_no` varchar(45) DEFAULT NULL,
  `ts_collected` datetime DEFAULT NULL,
  PRIMARY KEY (`specimen_id`),
  KEY `patient_id` (`patient_id`),
  KEY `specimen_type_id` (`specimen_type_id`),
  KEY `user_id` (`user_id`),
  KEY `status_code_id` (`status_code_id`),
  KEY `referred_to` (`referred_to`),
  KEY `IDX_DATE` (`date_collected`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `specimen_custom_data`
--

CREATE TABLE IF NOT EXISTS `specimen_custom_data` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `field_id` int(11) unsigned NOT NULL DEFAULT '0',
  `specimen_id` int(10) unsigned NOT NULL DEFAULT '0',
  `field_value` varchar(45) NOT NULL DEFAULT '',
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `field_id` (`field_id`),
  KEY `specimen_id` (`specimen_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `specimen_custom_field`
--

CREATE TABLE IF NOT EXISTS `specimen_custom_field` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `field_name` varchar(45) NOT NULL DEFAULT '',
  `field_options` varchar(45) NOT NULL DEFAULT '',
  `field_type_id` int(11) unsigned NOT NULL DEFAULT '0',
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `field_type_id` (`field_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `specimen_session`
--

CREATE TABLE IF NOT EXISTS `specimen_session` (
  `session_num` varchar(45) NOT NULL DEFAULT '',
  `count` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`session_num`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `specimen_session`
--

INSERT INTO `specimen_session` (`session_num`, `count`) VALUES
('20131017', 10),
('20131018', 49),
('20131019', 7),
('20131030', 19),
('20131031', 14),
('20131101', 72),
('20131113', 1),
('20131118', 1),
('20131119', 7),
('20131120', 39),
('20131121', 71),
('20131122', 71),
('20131123', 3),
('20131125', 7),
('20131126', 1),
('20131127', 1),
('20131128', 53),
('20131129', 69),
('20131130', 14),
('20131202', 9),
('20131203', 1),
('20131204', 1),
('20131207', 1),
('20131209', 11),
('20131210', 5),
('20131223', 2),
('20131224', 5),
('20131227', 15),
('20131228', 1),
('20131230', 58),
('20140328', 4),
('20140331', 8);

-- --------------------------------------------------------

--
-- Table structure for table `specimen_test`
--

CREATE TABLE IF NOT EXISTS `specimen_test` (
  `test_type_id` int(11) unsigned NOT NULL DEFAULT '0',
  `specimen_type_id` int(11) unsigned NOT NULL DEFAULT '0',
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `test_type_id` (`test_type_id`),
  KEY `specimen_type_id` (`specimen_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Relates tests to the specimens that are compatible with thos';

--
-- Dumping data for table `specimen_test`
--

INSERT INTO `specimen_test` (`test_type_id`, `specimen_type_id`, `ts`) VALUES
(7, 6, '2009-12-17 01:22:44'),
(8, 7, '2009-12-17 01:30:27'),
(9, 6, '2009-12-17 01:33:36'),
(70, 8, '2010-01-17 13:05:47'),
(11, 6, '2009-12-17 01:35:12'),
(92, 7, '2010-05-11 09:12:52'),
(13, 7, '2009-12-17 01:36:51'),
(14, 7, '2009-12-17 01:37:35'),
(15, 7, '2009-12-17 01:38:09'),
(16, 7, '2009-12-17 01:39:02'),
(17, 10, '2009-12-17 01:39:40'),
(107, 6, '2011-08-12 06:18:03'),
(18, 7, '2010-01-16 19:55:07'),
(19, 7, '2010-01-16 19:56:12'),
(20, 7, '2010-01-16 19:57:12'),
(21, 7, '2010-01-16 19:58:41'),
(22, 7, '2010-01-16 19:59:40'),
(23, 7, '2010-01-16 20:00:18'),
(24, 7, '2010-01-16 20:00:41'),
(25, 7, '2010-01-16 20:01:04'),
(26, 7, '2010-01-16 20:01:36'),
(27, 7, '2010-01-16 20:02:17'),
(28, 7, '2010-01-16 20:02:38'),
(29, 7, '2010-01-16 20:03:13'),
(30, 7, '2010-01-16 20:03:35'),
(31, 7, '2010-01-16 20:04:33'),
(32, 7, '2010-01-16 20:04:51'),
(33, 7, '2010-01-16 20:05:10'),
(34, 7, '2010-01-16 20:05:58'),
(35, 7, '2010-01-16 20:06:42'),
(36, 7, '2010-01-16 20:07:51'),
(37, 7, '2010-01-16 20:09:13'),
(38, 6, '2010-01-16 20:10:17'),
(104, 7, '2010-06-10 09:45:25'),
(39, 6, '2010-01-16 20:12:18'),
(40, 6, '2010-01-16 20:12:43'),
(41, 18, '2010-01-16 20:14:08'),
(42, 18, '2010-01-16 20:15:12'),
(43, 6, '2010-01-16 20:15:49'),
(44, 6, '2010-01-16 20:17:57'),
(12, 7, '2010-05-11 07:35:30'),
(46, 6, '2010-01-16 20:19:58'),
(47, 7, '2010-01-16 20:20:39'),
(48, 7, '2010-01-16 20:21:34'),
(49, 6, '2010-01-16 20:22:32'),
(50, 6, '2010-01-16 20:23:21'),
(51, 6, '2010-01-16 20:24:00'),
(52, 6, '2010-01-16 20:25:26'),
(53, 6, '2010-01-16 20:26:01'),
(54, 6, '2010-01-16 20:26:50'),
(55, 7, '2010-01-16 20:27:50'),
(103, 7, '2010-06-10 09:44:21'),
(57, 7, '2010-06-01 06:55:33'),
(58, 7, '2010-01-16 20:32:22'),
(59, 7, '2010-01-16 20:33:23'),
(60, 10, '2010-01-16 20:34:13'),
(62, 7, '2010-01-16 20:37:16'),
(63, 6, '2010-01-16 20:38:21'),
(64, 7, '2010-01-16 20:38:58'),
(65, 15, '2010-01-16 20:40:08'),
(66, 7, '2010-01-16 20:41:09'),
(67, 7, '2010-01-16 20:41:36'),
(68, 7, '2010-01-16 20:42:09'),
(69, 9, '2010-01-16 20:43:01'),
(70, 6, '2010-01-16 20:44:02'),
(71, 12, '2010-01-16 20:44:58'),
(72, 7, '2010-01-16 20:51:46'),
(73, 7, '2010-01-16 20:52:13'),
(74, 7, '2010-01-16 20:52:35'),
(84, 6, '2010-04-07 03:57:00'),
(83, 9, '2010-04-05 15:22:50'),
(41, 8, '2010-04-29 18:43:55'),
(86, 6, '2010-04-09 15:19:42'),
(88, 14, '2010-05-01 08:18:02'),
(44, 7, '2010-04-29 18:47:55'),
(85, 13, '2010-04-08 06:09:49'),
(89, 21, '2010-05-08 00:13:22'),
(108, 6, '2011-08-12 06:18:43'),
(11, 7, '2010-05-11 07:35:30'),
(93, 7, '2010-05-12 05:54:46'),
(94, 7, '2010-05-12 07:25:41'),
(95, 7, '2010-05-17 06:13:36'),
(96, 7, '2010-05-17 06:30:46'),
(9, 23, '2010-06-11 10:03:20'),
(84, 23, '2010-06-24 07:33:25'),
(98, 6, '2010-05-18 07:17:46'),
(99, 21, '2010-05-28 13:44:53'),
(100, 21, '2010-05-28 13:49:00'),
(105, 7, '2010-06-10 10:07:13'),
(106, 22, '2010-06-17 06:20:46'),
(89, 24, '2010-10-04 12:08:35'),
(100, 24, '2010-10-04 12:13:50'),
(99, 24, '2010-10-04 12:13:31'),
(109, 6, '2011-08-12 06:19:38'),
(110, 6, '2011-08-17 04:21:53'),
(10, 7, '2011-10-25 08:03:58'),
(111, 7, '2011-10-25 08:07:33'),
(112, 13, '2012-11-11 03:20:31'),
(112, 14, '2012-11-11 03:20:31'),
(85, 16, '2012-11-11 03:21:14'),
(85, 25, '2013-09-17 11:35:40'),
(7, 0, '2013-10-17 12:12:19'),
(8, 0, '2013-10-17 12:12:19'),
(9, 0, '2013-10-17 12:12:19'),
(10, 0, '2013-10-17 12:12:19'),
(11, 0, '2013-10-17 12:12:19'),
(12, 0, '2013-10-17 12:12:19'),
(13, 0, '2013-10-17 12:12:19'),
(14, 0, '2013-10-17 12:12:19'),
(15, 0, '2013-10-17 12:12:19'),
(16, 0, '2013-10-17 12:12:19'),
(17, 0, '2013-10-17 12:12:20'),
(18, 0, '2013-10-17 12:12:20'),
(19, 0, '2013-10-17 12:12:20'),
(20, 0, '2013-10-17 12:12:20'),
(21, 0, '2013-10-17 12:12:20'),
(22, 0, '2013-10-17 12:12:20'),
(23, 0, '2013-10-17 12:12:20'),
(24, 0, '2013-10-17 12:12:20'),
(25, 0, '2013-10-17 12:12:20'),
(26, 0, '2013-10-17 12:12:20'),
(27, 0, '2013-10-17 12:12:20'),
(28, 0, '2013-10-17 12:12:20'),
(29, 0, '2013-10-17 12:12:20'),
(30, 0, '2013-10-17 12:12:20'),
(31, 0, '2013-10-17 12:12:20'),
(32, 0, '2013-10-17 12:12:20'),
(33, 0, '2013-10-17 12:12:20'),
(34, 0, '2013-10-17 12:12:20'),
(35, 0, '2013-10-17 12:12:20'),
(36, 0, '2013-10-17 12:12:20'),
(37, 0, '2013-10-17 12:12:20'),
(38, 0, '2013-10-17 12:12:20'),
(39, 0, '2013-10-17 12:12:20'),
(40, 0, '2013-10-17 12:12:21'),
(41, 0, '2013-10-17 12:12:21'),
(42, 0, '2013-10-17 12:12:21'),
(43, 0, '2013-10-17 12:12:21'),
(44, 0, '2013-10-17 12:12:21'),
(46, 0, '2013-10-17 12:12:21'),
(47, 0, '2013-10-17 12:12:21'),
(48, 0, '2013-10-17 12:12:21'),
(49, 0, '2013-10-17 12:12:21'),
(50, 0, '2013-10-17 12:12:21'),
(51, 0, '2013-10-17 12:12:21'),
(52, 0, '2013-10-17 12:12:21'),
(53, 0, '2013-10-17 12:12:21'),
(54, 0, '2013-10-17 12:12:21'),
(55, 0, '2013-10-17 12:12:21'),
(56, 0, '2013-10-17 12:12:21'),
(57, 0, '2013-10-17 12:12:21'),
(58, 0, '2013-10-17 12:12:21'),
(59, 0, '2013-10-17 12:12:21'),
(60, 0, '2013-10-17 12:12:21'),
(61, 0, '2013-10-17 12:12:21'),
(62, 0, '2013-10-17 12:12:22'),
(63, 0, '2013-10-17 12:12:22'),
(64, 0, '2013-10-17 12:12:22'),
(65, 0, '2013-10-17 12:12:22'),
(66, 0, '2013-10-17 12:12:22'),
(67, 0, '2013-10-17 12:12:22'),
(68, 0, '2013-10-17 12:12:22'),
(69, 0, '2013-10-17 12:12:22'),
(70, 0, '2013-10-17 12:12:22'),
(71, 0, '2013-10-17 12:12:22'),
(72, 0, '2013-10-17 12:12:22'),
(73, 0, '2013-10-17 12:12:22'),
(74, 0, '2013-10-17 12:12:22'),
(83, 0, '2013-10-17 12:12:22'),
(84, 0, '2013-10-17 12:12:22'),
(85, 0, '2013-10-17 12:12:22'),
(86, 0, '2013-10-17 12:12:22'),
(88, 0, '2013-10-17 12:12:22'),
(89, 0, '2013-10-17 12:12:23'),
(90, 0, '2013-10-17 12:12:23'),
(91, 0, '2013-10-17 12:12:23'),
(92, 0, '2013-10-17 12:12:23'),
(93, 0, '2013-10-17 12:12:23'),
(94, 0, '2013-10-17 12:12:23'),
(95, 0, '2013-10-17 12:12:23'),
(96, 0, '2013-10-17 12:12:23'),
(97, 0, '2013-10-17 12:12:23'),
(98, 0, '2013-10-17 12:12:23'),
(99, 0, '2013-10-17 12:12:23'),
(100, 0, '2013-10-17 12:12:23'),
(101, 0, '2013-10-17 12:12:23'),
(102, 0, '2013-10-17 12:12:23'),
(103, 0, '2013-10-17 12:12:23'),
(104, 0, '2013-10-17 12:12:23'),
(105, 0, '2013-10-17 12:12:23'),
(106, 0, '2013-10-17 12:12:23'),
(107, 0, '2013-10-17 12:12:23'),
(108, 0, '2013-10-17 12:12:23'),
(109, 0, '2013-10-17 12:12:23'),
(110, 0, '2013-10-17 12:12:23'),
(111, 0, '2013-10-17 12:12:24'),
(112, 0, '2013-10-17 12:12:24'),
(113, 0, '2013-10-17 12:12:24'),
(114, 0, '2013-10-17 12:12:24'),
(115, 0, '2013-10-17 12:12:24'),
(116, 0, '2013-10-17 12:12:24'),
(117, 13, '2013-10-17 12:12:24'),
(120, 7, '2013-10-17 12:12:24'),
(123, 7, '2013-10-17 12:12:24'),
(124, 7, '2013-10-17 12:12:25'),
(126, 26, '2013-10-17 12:12:25'),
(127, 26, '2013-10-17 12:12:25'),
(131, 7, '2013-10-17 12:12:25'),
(132, 7, '2013-10-17 12:12:25'),
(134, 7, '2013-10-17 12:12:25'),
(135, 7, '2013-10-17 12:12:25'),
(136, 7, '2013-10-17 12:12:25'),
(137, 7, '2013-10-17 12:12:25'),
(138, 7, '2013-10-17 12:12:25'),
(139, 7, '2013-10-17 12:12:25'),
(141, 7, '2013-10-17 12:12:25'),
(142, 7, '2013-10-17 12:12:26'),
(143, 7, '2013-10-17 12:12:26'),
(144, 7, '2013-10-17 12:12:26'),
(145, 7, '2013-10-17 12:12:26'),
(146, 7, '2013-10-17 12:12:26'),
(147, 7, '2013-10-17 12:12:26'),
(148, 7, '2013-10-17 12:12:26'),
(149, 7, '2013-10-17 12:12:26'),
(150, 6, '2013-10-17 12:12:26'),
(151, 6, '2013-10-17 12:12:26'),
(152, 6, '2013-10-17 12:12:26'),
(153, 6, '2013-10-17 12:12:26'),
(154, 6, '2013-10-17 12:12:26'),
(155, 6, '2013-10-17 12:12:26'),
(156, 11, '2013-10-17 12:12:26'),
(157, 11, '2013-10-17 12:12:26'),
(158, 11, '2013-10-17 12:12:26'),
(160, 11, '2013-10-17 12:12:26'),
(161, 11, '2013-10-17 12:12:26'),
(162, 11, '2013-10-17 12:12:27'),
(163, 11, '2013-10-17 12:12:27'),
(164, 11, '2013-10-17 12:12:27'),
(165, 11, '2013-10-17 12:12:27'),
(166, 11, '2013-10-17 12:12:27'),
(167, 11, '2013-10-17 12:12:27'),
(168, 11, '2013-10-17 12:12:27'),
(169, 11, '2013-10-17 12:12:27'),
(170, 11, '2013-10-17 12:12:27'),
(172, 11, '2013-10-17 12:12:27'),
(173, 11, '2013-10-17 12:12:27'),
(174, 11, '2013-10-17 12:12:27'),
(175, 11, '2013-10-17 12:12:27'),
(176, 6, '2013-10-17 12:12:27'),
(181, 6, '2013-10-17 12:12:27'),
(182, 6, '2013-10-17 12:12:27'),
(183, 6, '2013-10-17 12:12:27'),
(184, 6, '2013-10-17 12:12:28'),
(185, 6, '2013-10-17 12:12:28'),
(186, 6, '2013-10-17 12:12:28'),
(187, 6, '2013-10-17 12:12:28'),
(188, 6, '2013-10-17 12:12:28'),
(189, 6, '2013-10-17 12:12:28'),
(190, 6, '2013-10-17 12:12:28'),
(191, 6, '2013-10-17 12:12:28'),
(192, 6, '2013-10-17 12:12:28'),
(194, 6, '2013-10-17 12:12:28'),
(195, 6, '2013-10-17 12:12:28'),
(196, 6, '2013-10-17 12:12:28'),
(197, 6, '2013-10-17 12:12:28'),
(198, 6, '2013-10-17 12:12:28'),
(221, 12, '2013-10-17 12:12:30'),
(222, 15, '2013-10-17 12:12:30'),
(223, 15, '2013-10-17 12:12:30'),
(224, 15, '2013-10-17 12:12:30'),
(225, 15, '2013-10-17 12:12:30'),
(226, 15, '2013-10-17 12:12:30'),
(244, 25, '2013-10-17 12:12:31'),
(255, 10, '2013-10-17 12:12:32'),
(260, 10, '2013-10-17 12:12:32'),
(263, 10, '2013-10-17 12:12:32'),
(265, 10, '2013-10-17 12:12:32'),
(267, 22, '2013-10-17 12:12:32'),
(268, 15, '2013-10-17 12:12:32'),
(271, 25, '2013-10-17 12:12:32'),
(276, 26, '2013-10-17 12:12:33'),
(279, 29, '2013-10-17 12:12:33'),
(281, 6, '2013-10-17 12:12:33'),
(282, 6, '2013-10-17 12:12:33'),
(285, 9, '2013-10-17 12:12:33'),
(287, 10, '2013-10-17 12:12:33'),
(288, 7, '2013-10-17 12:12:33'),
(289, 12, '2013-10-17 12:12:33'),
(290, 12, '2013-10-17 12:12:33'),
(291, 6, '2013-10-17 12:12:33'),
(292, 6, '2013-10-17 12:12:33'),
(293, 6, '2013-10-17 12:12:33'),
(294, 7, '2013-10-17 12:12:33'),
(295, 7, '2013-10-17 12:12:33'),
(296, 7, '2013-10-17 12:12:33'),
(297, 7, '2013-10-17 12:12:33'),
(298, 7, '2013-10-17 12:12:33'),
(299, 7, '2013-10-17 12:12:33'),
(300, 11, '2013-10-17 12:12:34'),
(301, 7, '2013-10-17 12:12:34'),
(302, 7, '2013-10-17 12:12:34'),
(303, 7, '2013-10-17 12:12:34'),
(304, 7, '2013-10-17 12:12:34'),
(305, 6, '2013-10-17 12:12:34'),
(159, 6, '2013-11-01 03:45:04'),
(307, 7, '2014-02-24 09:05:36'),
(308, 10, '2014-02-25 03:10:49'),
(309, 17, '2014-02-25 03:20:48'),
(310, 26, '2014-02-25 03:23:58'),
(311, 25, '2014-02-25 03:41:26'),
(312, 27, '2014-02-25 03:51:54'),
(313, 28, '2014-02-25 03:57:01'),
(314, 28, '2014-02-25 03:59:10'),
(315, 27, '2014-02-25 03:59:17'),
(316, 27, '2014-02-25 04:11:31'),
(317, 13, '2014-02-25 04:53:33'),
(318, 11, '2014-02-25 04:56:16'),
(319, 30, '2014-02-25 05:36:57'),
(320, 6, '2014-02-25 06:32:55'),
(322, 13, '2014-02-25 10:08:22'),
(288, 12, '2014-03-08 05:01:54'),
(323, 12, '2014-03-08 05:17:52');

-- --------------------------------------------------------

--
-- Table structure for table `specimen_type`
--

CREATE TABLE IF NOT EXISTS `specimen_type` (
  `specimen_type_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL DEFAULT '',
  `description` varchar(100) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `disabled` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`specimen_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `specimen_type`
--

INSERT INTO `specimen_type` (`specimen_type_id`, `name`, `description`, `ts`, `disabled`) VALUES
(6, 'Whole Blood', '', '2010-04-09 18:16:51', 0),
(7, 'Serum', '', '2009-12-09 00:41:07', 0),
(8, 'Dried Blood Spot', '', '2009-12-09 00:41:27', 0),
(9, 'Sputum', '', '2009-12-09 00:41:47', 0),
(10, 'CSF', '', '2009-12-09 00:41:56', 0),
(11, 'Urine', '', '2009-12-09 00:42:07', 0),
(12, 'Stool', '', '2009-12-09 00:42:15', 0),
(13, 'Aspirate', '', '2013-10-15 16:42:39', 0),
(14, 'Nasal Swab', '', '2009-12-09 00:42:41', 0),
(15, 'Semen', '', '2009-12-09 00:42:49', 0),
(16, 'Rectal Swab', '', '2009-12-09 00:43:08', 0),
(17, 'Throat Swab', '', '2009-12-09 00:43:20', 0),
(18, 'Plasma EDTA', '', '2009-12-09 00:43:33', 0),
(21, 'Vaginal Smear', '', '2013-10-15 16:42:06', 0),
(22, 'Skin', '', '2013-10-15 16:42:23', 0),
(23, 'Plasma', '', '2010-06-11 13:03:20', 0),
(24, 'Urethral Smear', '', '2013-10-15 16:42:06', 0),
(25, 'High Vaginal Swab', NULL, '2013-10-17 14:47:16', 0),
(26, 'Ascitic Tap', NULL, '2013-10-17 10:19:07', 0),
(27, 'Synovial Fluid', NULL, '2013-10-17 10:20:33', 0),
(28, 'Pleural Tap', NULL, '2013-10-17 10:20:33', 0),
(29, 'Water', NULL, '2013-10-17 14:48:15', 0),
(30, 'Pus Swab', NULL, '2013-10-17 15:05:47', 0);

-- --------------------------------------------------------

--
-- Table structure for table `stock_content`
--

CREATE TABLE IF NOT EXISTS `stock_content` (
  `name` varchar(40) DEFAULT NULL,
  `current_quantity` int(11) DEFAULT NULL,
  `date_of_use` date NOT NULL,
  `receiver` varchar(40) DEFAULT NULL,
  `remarks` text,
  `lot_number` varchar(40) DEFAULT NULL,
  `new_balance` int(11) DEFAULT NULL,
  `user_name` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `stock_details`
--

CREATE TABLE IF NOT EXISTS `stock_details` (
  `name` varchar(40) DEFAULT NULL,
  `lot_number` varchar(40) DEFAULT NULL,
  `expiry_date` varchar(40) DEFAULT NULL,
  `manufacturer` varchar(40) DEFAULT NULL,
  `quantity_ordered` int(11) DEFAULT NULL,
  `supplier` varchar(40) DEFAULT NULL,
  `date_of_reception` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `current_quantity` int(11) DEFAULT NULL,
  `date_of_supply` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `quantity_supplied` int(11) DEFAULT NULL,
  `unit` varchar(10) DEFAULT NULL,
  `entry_id` int(11) DEFAULT NULL,
  `cost_per_unit` decimal(10,0) DEFAULT '0',
  `quantity_used` int(10) DEFAULT '0',
  `used` varchar(1000) DEFAULT '',
  `user` varchar(1000) DEFAULT '',
  `receiver` varchar(1000) DEFAULT '',
  `remarks` varchar(1000) DEFAULT '',
  UNIQUE KEY `entry_id` (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE IF NOT EXISTS `test` (
  `test_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `test_type_id` int(11) unsigned NOT NULL DEFAULT '0',
  `result` varchar(201) DEFAULT NULL,
  `ts_started` datetime DEFAULT NULL,
  `ts_result_entered` datetime DEFAULT NULL,
  `comments` varchar(200) DEFAULT NULL,
  `user_id` int(11) unsigned DEFAULT NULL,
  `verified_by` int(11) unsigned DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `specimen_id` int(11) unsigned DEFAULT NULL,
  `date_verified` datetime DEFAULT NULL,
  `status_code_id` int(10) unsigned DEFAULT '0',
  `external_lab_no` varchar(100) DEFAULT NULL,
  `external_parent_lab_no` varchar(100) DEFAULT '0',
  `patientVisitNumber` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`test_id`),
  KEY `test_type_id` (`test_type_id`),
  KEY `user_id` (`user_id`),
  KEY `specimen_id` (`specimen_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- Table structure for table `test_category`
--

CREATE TABLE IF NOT EXISTS `test_category` (
  `test_category_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL DEFAULT '',
  `description` varchar(100) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`test_category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `test_category`
--

INSERT INTO `test_category` (`test_category_id`, `name`, `description`, `ts`) VALUES
(1, 'SEROLOGY', NULL, '2013-10-16 12:43:02'),
(2, 'HAEMATOLOGY', '', '2014-03-10 23:14:28'),
(3, 'MCH', 'Maternal Child Health', '2013-10-15 15:50:32'),
(4, 'VIROLOGY', '', '2013-10-16 12:35:26'),
(5, 'HISTOLOGY AND CYTOLOGY', '', '2013-10-16 12:44:55'),
(6, 'BIOCHEMISTRY', '', '2013-10-16 12:34:39'),
(7, 'MICROBIOLOGY', '', '2013-10-16 12:44:55'),
(8, 'OTHER', '', '2014-03-10 23:14:48'),
(9, 'CLINICAL CHEMISTRY', '', '2013-10-16 12:44:55'),
(10, 'BACTERIOLOGY', '', '2013-10-16 12:44:55'),
(12, 'PARASITOLOGY', '', '2013-10-16 12:44:55'),
(13, 'BLOOD TRANSFUSION', '', '2013-10-16 12:35:26'),
(14, 'Test Section', '', '2013-10-15 13:45:00');

-- --------------------------------------------------------

--
-- Table structure for table `test_measure`
--

CREATE TABLE IF NOT EXISTS `test_measure` (
  `tm_id` int(11) NOT NULL AUTO_INCREMENT,
  `test_id` int(11) NOT NULL,
  `lab_no` int(11) NOT NULL,
  `measure_id` int(11) NOT NULL,
  `result` text NOT NULL,
  PRIMARY KEY (`tm_id`),
  UNIQUE KEY `uniq_ttid_labno_mid` (`test_id`,`lab_no`,`measure_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `test_type`
--

CREATE TABLE IF NOT EXISTS `test_type` (
  `test_type_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parent_test_type_id` int(10) DEFAULT '0',
  `specimen` varchar(100) NOT NULL,
  `name` varchar(45) NOT NULL DEFAULT '',
  `description` varchar(100) DEFAULT NULL,
  `test_category_id` int(11) unsigned NOT NULL DEFAULT '0',
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_panel` int(10) unsigned DEFAULT NULL,
  `disabled` int(10) unsigned NOT NULL DEFAULT '0',
  `clinical_data` longtext,
  `hide_patient_name` int(1) DEFAULT NULL,
  `prevalence_threshold` int(3) DEFAULT NULL,
  `target_tat` int(3) unsigned DEFAULT NULL,
  PRIMARY KEY (`test_type_id`),
  KEY `test_category_id` (`test_category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=324 ;

--
-- Dumping data for table `test_type`
--

INSERT INTO `test_type` (`test_type_id`, `parent_test_type_id`, `specimen`, `name`, `description`, `test_category_id`, `ts`, `is_panel`, `disabled`, `clinical_data`, `hide_patient_name`, `prevalence_threshold`, `target_tat`) VALUES
(117, 270, 'Aspirate', 'Grams stain', NULL, 10, '2013-10-17 13:22:13', NULL, 0, NULL, NULL, NULL, NULL),
(118, 270, 'Aspirate', 'ZN stain', NULL, 10, '2014-02-28 11:02:50', NULL, 1, NULL, NULL, NULL, NULL),
(119, 278, 'Urine', 'urine chemistry', NULL, 10, '2014-01-24 12:33:08', NULL, 1, NULL, NULL, NULL, NULL),
(120, 0, 'Serum', 'SERUM AMYLASE', NULL, 6, '2013-10-17 12:40:17', NULL, 0, NULL, NULL, NULL, NULL),
(121, 0, 'Serum', 'calcium', NULL, 6, '2014-02-25 09:15:40', NULL, 1, NULL, NULL, NULL, NULL),
(122, 119, 'Serum', 'CALCIUM', NULL, 6, '2014-02-25 09:15:26', NULL, 1, NULL, NULL, NULL, NULL),
(123, 0, 'Serum', 'URIC ACID', '', 6, '2014-03-07 10:13:11', NULL, 0, '', 0, 0, 0),
(124, 0, 'Serum', 'calcium', NULL, 6, '2013-10-17 12:40:17', NULL, 0, NULL, NULL, NULL, NULL),
(125, 127, 'Ascitic Tap', 'Glucose', NULL, 6, '2014-01-28 07:17:49', NULL, 1, NULL, NULL, NULL, NULL),
(126, 127, 'Ascitic Tap', 'Protein', NULL, 6, '2013-10-17 13:22:13', NULL, 0, NULL, NULL, NULL, NULL),
(127, 0, 'Ascitic Tap', 'Ascitic tap for biochemistry', '', 6, '2014-02-20 13:37:26', NULL, 0, '%%%###', 0, 0, 0),
(128, 130, 'CSF', 'Glucose', NULL, 6, '2014-01-28 07:17:58', NULL, 1, NULL, NULL, NULL, NULL),
(129, 130, 'CSF', 'Protein', NULL, 6, '2014-02-28 11:05:01', NULL, 1, NULL, NULL, NULL, NULL),
(130, 60, 'CSF', 'CSF for biochemistry', NULL, 6, '2014-02-25 06:09:18', NULL, 1, NULL, NULL, NULL, NULL),
(131, 0, 'Serum', 'PSA', NULL, 6, '2013-10-17 12:40:17', NULL, 0, NULL, NULL, NULL, NULL),
(132, 140, 'Serum', 'Total', NULL, 6, '2013-10-17 13:22:13', NULL, 0, NULL, NULL, NULL, NULL),
(133, 141, 'Serum', 'Albumin', NULL, 6, '2014-02-24 12:04:30', NULL, 1, NULL, NULL, NULL, NULL),
(134, 141, 'Serum', 'Alkaline Phosphate', '', 6, '2014-03-07 10:04:03', NULL, 0, '', 0, 0, 0),
(135, 141, 'Serum', 'ASAT', '', 6, '2014-03-07 09:51:32', NULL, 0, '', 0, 0, 0),
(136, 141, 'Serum', 'SGOT', NULL, 6, '2013-10-17 13:22:14', NULL, 0, NULL, NULL, NULL, NULL),
(137, 141, 'Serum', 'ALAT', '', 6, '2014-03-07 09:58:37', NULL, 0, '', 0, 0, 0),
(138, 140, 'Serum', 'Direct ', NULL, 6, '2013-10-17 13:22:14', NULL, 0, NULL, NULL, NULL, NULL),
(139, 141, 'Serum', 'Total Proteins ', '', 6, '2014-03-11 03:07:42', NULL, 0, '', 0, 0, 0),
(140, 141, 'Serum', 'Bilirubin', NULL, 6, '2014-01-28 07:17:15', NULL, 1, NULL, NULL, NULL, NULL),
(141, 0, 'Serum', 'LFTS', '', 6, '2014-03-04 15:10:36', NULL, 0, '', 0, 0, 0),
(142, 145, 'Serum', 'Chloride', NULL, 6, '2013-10-17 13:22:14', NULL, 0, NULL, NULL, NULL, NULL),
(143, 145, 'Serum', 'Potassium', NULL, 6, '2013-10-17 13:22:14', NULL, 0, NULL, NULL, NULL, NULL),
(144, 145, 'Serum', 'Sodium', NULL, 6, '2013-10-17 13:22:14', NULL, 0, NULL, NULL, NULL, NULL),
(145, 148, 'Serum', 'Electrolytes', '', 6, '2014-02-27 06:34:45', NULL, 0, '', 0, 0, 0),
(146, 148, 'Serum', 'Creatinine ', '', 6, '2014-03-07 09:43:50', NULL, 0, '', 0, 0, 0),
(147, 148, 'Serum', 'Urea', '', 6, '2014-03-07 09:47:47', NULL, 0, '', 0, 0, 0),
(148, 0, 'Serum', 'RFTS', '', 6, '2014-02-24 08:07:56', NULL, 0, '', 0, 0, 0),
(149, 0, 'Serum', 'TFT', NULL, 6, '2013-10-17 12:40:17', NULL, 0, NULL, NULL, NULL, NULL),
(150, 0, 'Whole Blood', 'GXM', '', 13, '2014-02-25 06:29:59', NULL, 0, '', 0, 0, 0),
(151, 0, 'Whole Blood', 'Indirect COOMBS test', NULL, 13, '2013-10-17 12:40:17', NULL, 0, NULL, NULL, NULL, NULL),
(152, 0, 'Whole Blood', 'Direct COOMBS test', NULL, 13, '2013-10-17 12:40:17', NULL, 0, NULL, NULL, NULL, NULL),
(153, 0, 'Whole Blood', 'Du test', NULL, 13, '2013-10-17 12:40:17', NULL, 0, NULL, NULL, NULL, NULL),
(154, 150, 'Whole Blood', 'Blood Grouping', NULL, 13, '2013-10-17 13:22:14', NULL, 0, NULL, NULL, NULL, NULL),
(155, 150, 'Whole Blood', 'Cross Match', NULL, 13, '2013-10-17 13:22:14', NULL, 0, NULL, NULL, NULL, NULL),
(156, 167, 'Urine', 'Epithelial cells', NULL, 9, '2013-10-17 13:22:14', NULL, 0, NULL, NULL, NULL, NULL),
(157, 0, 'Urine', 'Urinalysis', '', 9, '2014-02-27 06:57:50', NULL, 0, '', 0, 0, 0),
(158, 175, 'Urine', 'ph', NULL, 9, '2014-01-25 14:25:12', NULL, 0, NULL, NULL, NULL, NULL),
(159, 0, 'Urine', 'Blood sugar', '', 9, '2013-11-01 06:45:04', NULL, 0, '%%%###', 0, 0, 0),
(160, 167, 'Urine', 'Spermatozoa', NULL, 9, '2013-10-17 13:22:14', NULL, 0, NULL, NULL, NULL, NULL),
(161, 167, 'Urine', 'Bacteria', NULL, 9, '2013-10-17 13:22:14', NULL, 0, NULL, NULL, NULL, NULL),
(162, 167, 'Urine', 'Red blood cells', NULL, 9, '2013-10-17 13:22:14', NULL, 0, NULL, NULL, NULL, NULL),
(163, 167, 'Urine', 'Yeast cells', NULL, 9, '2013-10-17 13:22:15', NULL, 0, NULL, NULL, NULL, NULL),
(164, 167, 'Urine', 'T. vaginalis', NULL, 9, '2013-10-17 13:22:15', NULL, 0, NULL, NULL, NULL, NULL),
(165, 167, 'Urine', 'S. haematobium', NULL, 9, '2013-10-17 13:22:15', NULL, 0, NULL, NULL, NULL, NULL),
(166, 167, 'Urine', 'Pus cells', NULL, 9, '2013-10-17 13:22:15', NULL, 0, NULL, NULL, NULL, NULL),
(167, 157, 'Urine', 'Urine microscopy', '', 9, '2014-02-27 06:41:58', NULL, 0, '', 0, 0, 0),
(168, 119, 'Urine', 'HCG', NULL, 9, '2013-10-17 13:22:15', NULL, 0, NULL, NULL, NULL, NULL),
(169, 175, 'Urine', 'Urobilinogen Phenlpyruvic acid', NULL, 9, '2014-01-25 14:25:12', NULL, 0, NULL, NULL, NULL, NULL),
(170, 175, 'Urine', 'Bilirubin', '', 9, '2014-03-07 10:11:39', NULL, 0, '', 0, 0, 0),
(171, 175, 'Urine', 'Blood', NULL, 9, '2014-01-25 14:25:12', NULL, 0, NULL, NULL, NULL, NULL),
(172, 175, 'Urine', 'Proteins', NULL, 9, '2014-01-25 14:25:12', NULL, 0, NULL, NULL, NULL, NULL),
(173, 175, 'Urine', 'Ketones', NULL, 9, '2014-01-25 14:25:12', NULL, 0, NULL, NULL, NULL, NULL),
(174, 175, 'Urine', 'Glucose', '', 9, '2014-01-25 14:27:52', NULL, 0, '%%%###', 0, 0, 0),
(175, 157, 'Urine', 'Urine chemistry', '', 9, '2014-02-27 06:37:27', NULL, 0, '', 0, 0, 0),
(176, 0, 'Whole Blood', 'Full Haemogram', '', 2, '2014-03-10 10:18:24', NULL, 0, '', 0, 0, 0),
(177, 181, 'Whole Blood', 'Eos#', NULL, 2, '2014-02-28 10:58:28', NULL, 1, NULL, NULL, NULL, NULL),
(178, 181, 'Whole Blood', 'Mon#', NULL, 2, '2014-02-28 11:02:09', NULL, 1, NULL, NULL, NULL, NULL),
(179, 181, 'Whole Blood', 'Lym#', NULL, 2, '2014-02-28 10:58:19', NULL, 1, NULL, NULL, NULL, NULL),
(180, 181, 'Whole Blood', 'Neu#', NULL, 2, '2014-02-28 10:58:44', NULL, 1, NULL, NULL, NULL, NULL),
(181, 193, 'Whole Blood', 'WBC', NULL, 2, '2013-10-17 13:22:15', NULL, 0, NULL, NULL, NULL, NULL),
(182, 193, 'Whole Blood', 'RBC', NULL, 2, '2013-10-17 13:22:15', NULL, 0, NULL, NULL, NULL, NULL),
(183, 193, 'Whole Blood', 'HB', NULL, 2, '2013-10-17 13:22:16', NULL, 0, NULL, NULL, NULL, NULL),
(184, 193, 'Whole Blood', 'HCT', NULL, 2, '2013-10-17 13:22:16', NULL, 0, NULL, NULL, NULL, NULL),
(185, 193, 'Whole Blood', 'MCV', NULL, 2, '2013-10-17 13:22:16', NULL, 0, NULL, NULL, NULL, NULL),
(186, 193, 'Whole Blood', 'MCH', NULL, 2, '2013-10-17 13:22:16', NULL, 0, NULL, NULL, NULL, NULL),
(187, 193, 'Whole Blood', 'MCHC', NULL, 2, '2013-10-17 13:22:16', NULL, 0, NULL, NULL, NULL, NULL),
(188, 193, 'Whole Blood', 'RDW', NULL, 2, '2013-10-17 13:22:16', NULL, 0, NULL, NULL, NULL, NULL),
(189, 193, 'Whole Blood', 'PLATELET COUNT', NULL, 2, '2013-10-17 13:22:16', NULL, 0, NULL, NULL, NULL, NULL),
(190, 193, 'Whole Blood', 'PCT', NULL, 2, '2013-10-17 13:22:16', NULL, 0, NULL, NULL, NULL, NULL),
(191, 193, 'Whole Blood', 'MPV', NULL, 2, '2013-10-17 13:22:16', NULL, 0, NULL, NULL, NULL, NULL),
(192, 193, 'Whole Blood', 'PDW', NULL, 2, '2013-10-17 13:22:16', NULL, 0, NULL, NULL, NULL, NULL),
(193, 0, 'Whole Blood', 'Full Haemogram', '', 2, '2014-02-21 08:28:48', NULL, 1, '%%%###', 0, 0, 0),
(194, 0, 'Whole Blood', 'Bleeding time test', NULL, 2, '2013-10-17 12:40:17', NULL, 0, NULL, NULL, NULL, NULL),
(195, 0, 'Whole Blood', 'Clotting time test', NULL, 2, '2013-10-17 12:40:17', NULL, 0, NULL, NULL, NULL, NULL),
(196, 0, 'Whole Blood', 'PTI/INR', NULL, 2, '2013-10-17 12:40:17', NULL, 0, NULL, NULL, NULL, NULL),
(197, 0, 'Whole Blood', 'Sickling test', NULL, 2, '2013-10-17 12:40:17', NULL, 0, NULL, NULL, NULL, NULL),
(198, 0, 'Whole Blood', 'ESR', NULL, 2, '2013-10-17 12:40:17', NULL, 0, NULL, NULL, NULL, NULL),
(199, 266, 'Pus Swab', 'sensitivity', NULL, 7, '2014-02-28 10:59:14', NULL, 1, NULL, NULL, NULL, NULL),
(200, 266, 'Pus Swab', 'culture', NULL, 7, '2014-02-28 10:50:21', NULL, 1, NULL, NULL, NULL, NULL),
(201, 266, 'Pus Swab', 'ZN stain', NULL, 7, '2014-02-28 11:03:06', NULL, 1, NULL, NULL, NULL, NULL),
(202, 266, 'Pus Swab', 'Gramstain', NULL, 7, '2014-02-28 10:55:39', NULL, 1, NULL, NULL, NULL, NULL),
(203, 278, 'Urine', 'culture', NULL, 7, '2014-02-28 10:50:28', NULL, 1, NULL, NULL, NULL, NULL),
(204, 278, 'Urine', 'microscopy', NULL, 7, '2014-02-25 06:35:16', NULL, 1, NULL, NULL, NULL, NULL),
(205, 269, 'Aspirate', 'sensitivity', NULL, 7, '2014-02-28 11:00:13', NULL, 1, NULL, NULL, NULL, NULL),
(206, 269, 'Aspirate', 'zn stain', NULL, 7, '2014-02-28 11:03:11', NULL, 1, NULL, NULL, NULL, NULL),
(207, 269, 'Aspirate', 'gramstain', NULL, 7, '2014-02-28 10:55:47', NULL, 1, NULL, NULL, NULL, NULL),
(208, 278, 'Urine', 'sensitivity', NULL, 7, '2014-02-28 10:59:34', NULL, 1, NULL, NULL, NULL, NULL),
(209, 278, 'Urine', 'gramstain', NULL, 7, '2014-02-28 10:55:56', NULL, 1, NULL, NULL, NULL, NULL),
(210, 278, 'Urine', 'urine chemistry', NULL, 7, '2014-01-24 12:33:20', NULL, 1, NULL, NULL, NULL, NULL),
(211, 278, 'Urine', 'microscopy', NULL, 7, '2014-02-25 06:34:56', NULL, 1, NULL, NULL, NULL, NULL),
(212, 278, 'Urine', 'urine chemistry', NULL, 7, '2014-01-24 10:43:59', NULL, 1, NULL, NULL, NULL, NULL),
(213, 218, 'Throat Swab', 'gramstain', NULL, 7, '2014-02-28 10:56:28', NULL, 1, NULL, NULL, NULL, NULL),
(214, 218, 'Throat Swab', 'SENSITIVITY', NULL, 7, '2014-02-28 11:00:42', NULL, 1, NULL, NULL, NULL, NULL),
(215, 218, 'Throat Swab', 'CULTURE', NULL, 7, '2014-02-28 10:49:47', NULL, 1, NULL, NULL, NULL, NULL),
(216, 218, 'Throat Swab', 'gRAMSTAIN', NULL, 7, '2014-02-28 10:56:09', NULL, 1, NULL, NULL, NULL, NULL),
(217, 218, 'Throat Swab', 'zn STAIN ', NULL, 7, '2014-02-28 11:03:32', NULL, 1, NULL, NULL, NULL, NULL),
(218, 0, 'Throat Swab', 'Throat swab for culture', NULL, 7, '2014-02-25 06:17:11', NULL, 1, NULL, NULL, NULL, NULL),
(219, 286, 'Stool', 'sensitivity', NULL, 7, '2014-02-28 10:59:56', NULL, 1, NULL, NULL, NULL, NULL),
(220, 286, 'Stool', 'culture', NULL, 7, '2014-02-28 10:49:33', NULL, 1, NULL, NULL, NULL, NULL),
(221, 286, 'Stool', 'microscopy', NULL, 7, '2013-10-17 13:22:17', NULL, 0, NULL, NULL, NULL, NULL),
(222, 268, 'Semen', 'microscopic examination', NULL, 7, '2013-10-17 13:22:17', NULL, 0, NULL, NULL, NULL, NULL),
(223, 268, 'Semen', 'sperm count', NULL, 7, '2013-10-17 13:22:17', NULL, 0, NULL, NULL, NULL, NULL),
(224, 268, 'Semen', 'motility', NULL, 7, '2013-10-17 13:22:17', NULL, 0, NULL, NULL, NULL, NULL),
(225, 268, 'Semen', 'viscosity', NULL, 7, '2013-10-17 13:22:17', NULL, 0, NULL, NULL, NULL, NULL),
(226, 268, 'Semen', 'volume', NULL, 7, '2013-10-17 13:22:17', NULL, 0, NULL, NULL, NULL, NULL),
(227, 272, 'Synovial Fluid', 'sensitivity', NULL, 7, '2014-02-28 11:00:08', NULL, 1, NULL, NULL, NULL, NULL),
(228, 272, 'Synovial Fluid', 'CULTURE', NULL, 7, '2014-02-28 10:49:56', NULL, 1, NULL, NULL, NULL, NULL),
(229, 272, 'Synovial Fluid', 'Gramstain', NULL, 7, '2014-02-28 10:56:02', NULL, 1, NULL, NULL, NULL, NULL),
(230, 272, 'Synovial Fluid', 'ZN STAIN', NULL, 7, '2014-02-28 11:03:41', NULL, 1, NULL, NULL, NULL, NULL),
(231, 273, 'Synovial Fluid', 'Gramstain', NULL, 7, '2014-02-28 10:56:34', NULL, 1, NULL, NULL, NULL, NULL),
(232, 273, 'Synovial Fluid', 'ZN stain', NULL, 7, '2014-02-28 11:03:22', NULL, 1, NULL, NULL, NULL, NULL),
(233, 274, 'Pleural Tap', 'sensitivity', NULL, 7, '2014-02-28 10:59:51', NULL, 1, NULL, NULL, NULL, NULL),
(234, 274, 'Pleural Tap', 'culture', NULL, 7, '2014-02-28 10:50:12', NULL, 1, NULL, NULL, NULL, NULL),
(235, 274, 'Pleural Tap', 'Gramstain', NULL, 7, '2014-02-28 10:56:58', NULL, 1, NULL, NULL, NULL, NULL),
(236, 274, 'Pleural Tap', 'ZN stain', NULL, 7, '2014-02-28 11:03:37', NULL, 1, NULL, NULL, NULL, NULL),
(237, 275, 'Pleural Tap', 'ZN stain', NULL, 7, '2014-02-28 11:03:01', NULL, 1, NULL, NULL, NULL, NULL),
(238, 275, 'Pleural Tap', 'Gramstain', NULL, 7, '2014-02-28 10:56:48', NULL, 1, NULL, NULL, NULL, NULL),
(239, 284, 'High Vaginal Swab', 'sensitivity', NULL, 7, '2014-02-28 11:00:02', NULL, 1, NULL, NULL, NULL, NULL),
(240, 284, 'High Vaginal Swab', 'culture', NULL, 7, '2014-02-28 10:50:03', NULL, 1, NULL, NULL, NULL, NULL),
(241, 284, 'High Vaginal Swab', 'Gramstain', NULL, 7, '2014-02-28 10:56:53', NULL, 1, NULL, NULL, NULL, NULL),
(242, 284, 'High Vaginal Swab', 'wet prep', NULL, 7, '2014-02-28 11:04:02', NULL, 1, NULL, NULL, NULL, NULL),
(243, 271, 'High Vaginal Swab', 'Gramstain', NULL, 7, '2014-02-28 10:57:04', NULL, 1, NULL, NULL, NULL, NULL),
(244, 271, 'High Vaginal Swab', 'wet prep', NULL, 7, '2013-10-17 13:22:18', NULL, 0, NULL, NULL, NULL, NULL),
(245, 283, 'Whole Blood', 'sensitivity', NULL, 7, '2014-02-28 10:59:45', NULL, 1, NULL, NULL, NULL, NULL),
(246, 283, 'Whole Blood', 'culture', NULL, 7, '2014-02-28 10:50:58', NULL, 1, NULL, NULL, NULL, NULL),
(247, 276, 'Ascitic Tap', 'sensitivity', NULL, 7, '2014-02-28 10:59:40', NULL, 1, NULL, NULL, NULL, NULL),
(248, 276, 'Ascitic Tap', 'culture', NULL, 7, '2014-02-28 10:50:37', NULL, 1, NULL, NULL, NULL, NULL),
(249, 69, 'Ascitic Tap', 'Gramstain', NULL, 7, '2014-02-28 10:56:20', NULL, 1, NULL, NULL, NULL, NULL),
(250, 276, 'Ascitic Tap', 'ZN stain', NULL, 7, '2014-02-28 11:03:45', NULL, 1, NULL, NULL, NULL, NULL),
(251, 277, 'Ascitic Tap', 'Gramstain', NULL, 7, '2014-02-28 10:56:15', NULL, 1, NULL, NULL, NULL, NULL),
(252, 277, 'Ascitic Tap', 'ZN stain', NULL, 7, '2014-02-28 11:03:27', NULL, 1, NULL, NULL, NULL, NULL),
(253, 263, 'CSF', 'sensitivity', NULL, 7, '2014-02-28 10:59:22', NULL, 1, NULL, NULL, NULL, NULL),
(254, 263, 'CSF', 'culture ', NULL, 7, '2014-02-28 10:53:47', NULL, 1, NULL, NULL, NULL, NULL),
(255, 263, 'CSF', 'Indian ink', NULL, 7, '2013-10-17 13:22:19', NULL, 0, NULL, NULL, NULL, NULL),
(256, 263, 'CSF', 'ZN stain', NULL, 7, '2014-02-28 11:03:16', NULL, 1, NULL, NULL, NULL, NULL),
(257, 263, 'CSF', 'Gramstain', NULL, 7, '2014-02-28 10:56:42', NULL, 1, NULL, NULL, NULL, NULL),
(258, 263, 'CSF', 'cell count', NULL, 7, '2014-02-28 10:48:27', NULL, 1, NULL, NULL, NULL, NULL),
(259, 204, 'CSF', 'Indian ink', NULL, 7, '2014-02-28 11:01:56', NULL, 1, NULL, NULL, NULL, NULL),
(260, 204, 'CSF', 'cell count', NULL, 7, '2013-10-17 13:22:19', NULL, 0, NULL, NULL, NULL, NULL),
(261, 204, 'CSF', 'ZN stain', NULL, 7, '2014-02-28 11:02:55', NULL, 1, NULL, NULL, NULL, NULL),
(262, 204, 'CSF', 'Gramstain ', NULL, 7, '2014-02-28 10:57:08', NULL, 1, NULL, NULL, NULL, NULL),
(263, 265, 'CSF', 'culture and sensitivity', '', 7, '2014-03-08 08:01:23', NULL, 0, '', 0, 0, 0),
(264, 265, 'CSF', 'microscopy', NULL, 7, '2014-02-25 06:35:53', NULL, 1, NULL, NULL, NULL, NULL),
(265, 60, 'CSF', 'CSF for microbiology', '', 7, '2014-02-24 15:41:22', NULL, 0, '', 0, 0, 0),
(266, 0, 'Pus Swab', 'Pus swab for culture and sensitivity', NULL, 7, '2014-02-25 08:33:33', NULL, 1, NULL, NULL, NULL, NULL),
(267, 0, 'Skin', 'KOH for fungi', NULL, 7, '2013-10-17 12:40:17', NULL, 0, NULL, NULL, NULL, NULL),
(268, 0, 'Semen', 'semen analysis', '', 7, '2014-02-25 07:14:06', NULL, 0, '', 0, 0, 0),
(269, 0, 'Aspirate', 'Aspirate for culture and sensitivity', '', 7, '2014-02-25 07:44:14', NULL, 1, '%%%###', 0, 0, 0),
(270, 0, 'Aspirate', 'Aspirate for microscopy ', NULL, 7, '2014-02-25 09:54:16', NULL, 1, NULL, NULL, NULL, NULL),
(271, 0, 'High Vaginal Swab', 'HVS for microscopy ', '', 7, '2014-02-25 06:44:55', NULL, 0, '', 0, 0, 0),
(272, 0, 'Synovial Fluid', 'Synovial fluid for culture and sensitivity', NULL, 7, '2014-02-25 06:56:23', NULL, 1, NULL, NULL, NULL, NULL),
(273, 0, 'Synovial Fluid', 'Synovial fluid for microscopy', NULL, 7, '2014-02-25 06:46:27', NULL, 1, NULL, NULL, NULL, NULL),
(274, 0, 'Pleural Tap', 'Pleural tap for culture and sensitivity', NULL, 7, '2014-02-25 06:55:15', NULL, 1, NULL, NULL, NULL, NULL),
(275, 0, 'Pleural Tap', 'Pleural tap for microscopy', NULL, 7, '2014-02-25 06:58:31', NULL, 1, NULL, NULL, NULL, NULL),
(276, 0, 'Ascitic Tap', 'Ascitic tap for culture and sensitivity', '', 7, '2014-02-25 09:54:29', NULL, 0, '', 0, 0, 0),
(277, 0, 'Ascitic Tap', 'Ascitic tap for microscopy', '', 7, '2014-02-25 06:22:12', NULL, 1, '%%%###', 0, 0, 0),
(278, 0, 'Urine', 'Urine Culture & Sensitivity', NULL, 7, '2014-02-25 07:51:26', NULL, 1, NULL, NULL, NULL, NULL),
(279, 0, 'Water', 'Water Analysis', NULL, 7, '2013-10-17 12:40:17', NULL, 0, NULL, NULL, NULL, NULL),
(280, 283, 'Whole Blood', 'Wet prep', NULL, 7, '2014-02-28 11:04:14', NULL, 1, NULL, NULL, NULL, NULL),
(281, 283, 'Whole Blood', 'Gram stain', NULL, 7, '2013-10-17 13:22:19', NULL, 0, NULL, NULL, NULL, NULL),
(282, 283, 'Whole Blood', 'Sub culture ', NULL, 7, '2013-10-17 13:22:19', NULL, 0, NULL, NULL, NULL, NULL),
(283, 0, 'Whole Blood', 'Blood Culture & sensitivity', NULL, 7, '2014-02-25 09:24:33', NULL, 1, NULL, NULL, NULL, NULL),
(284, 0, 'High Vaginal Swab', 'HVS for culture and sensitivity', NULL, 7, '2014-02-25 06:39:49', NULL, 1, NULL, NULL, NULL, NULL),
(285, 0, 'Sputum', 'Sputum', NULL, 7, '2013-10-17 12:40:17', NULL, 0, NULL, NULL, NULL, NULL),
(286, 0, 'Stool', 'Stool for C/S', NULL, 7, '2014-02-25 07:07:06', NULL, 1, NULL, NULL, NULL, NULL),
(287, 0, 'CSF', 'CSF', '', 8, '2014-03-06 07:45:35', NULL, 0, '', 0, 0, 0),
(288, 0, 'Serum', 'salmonella antigen test', '', 12, '2014-03-08 08:01:54', NULL, 0, '', 0, 0, 0),
(289, 0, 'Stool', 'OCCULT BLOOD', NULL, 12, '2013-10-17 12:40:17', NULL, 0, NULL, NULL, NULL, NULL),
(290, 0, 'Stool', 'Stool for O/C', NULL, 12, '2013-10-17 12:40:17', NULL, 0, NULL, NULL, NULL, NULL),
(291, 0, 'Whole Blood', 'BS for mps', NULL, 12, '2013-10-17 12:40:17', NULL, 0, NULL, NULL, NULL, NULL),
(292, 0, 'Whole Blood', 'Borrelia', NULL, 12, '2013-10-17 12:40:17', NULL, 0, NULL, NULL, NULL, NULL),
(293, 0, 'Whole Blood', 'PBF', NULL, 1, '2013-10-17 12:40:17', NULL, 0, NULL, NULL, NULL, NULL),
(294, 0, 'Serum', 'HEPATITIS C', NULL, 1, '2013-10-17 12:40:17', NULL, 0, NULL, NULL, NULL, NULL),
(295, 0, 'Serum', 'HEPATITIS B', NULL, 1, '2013-10-17 12:40:17', NULL, 0, NULL, NULL, NULL, NULL),
(296, 0, 'Serum', 'Asot Titration', NULL, 1, '2013-10-17 12:40:17', NULL, 0, NULL, NULL, NULL, NULL),
(297, 0, 'Serum', 'Widal Titration', NULL, 1, '2013-10-17 12:40:17', NULL, 0, NULL, NULL, NULL, NULL),
(298, 0, 'Serum', 'VDRL', NULL, 1, '2013-10-17 12:40:17', NULL, 0, NULL, NULL, NULL, NULL),
(299, 0, 'Serum', 'Asot', NULL, 1, '2013-10-17 12:40:17', NULL, 0, NULL, NULL, NULL, NULL),
(300, 0, 'Urine', 'Pregnancy test', NULL, 1, '2013-10-17 12:40:17', NULL, 0, NULL, NULL, NULL, NULL),
(301, 0, 'Serum', 'RF', NULL, 1, '2013-10-17 12:40:17', NULL, 0, NULL, NULL, NULL, NULL),
(302, 0, 'Serum', 'Brucella', NULL, 1, '2013-10-17 12:40:17', NULL, 0, NULL, NULL, NULL, NULL),
(303, 0, 'Serum', 'Widal', NULL, 1, '2013-10-17 12:40:17', NULL, 0, NULL, NULL, NULL, NULL),
(304, 0, 'Serum', 'H pylori', NULL, 1, '2013-10-17 12:40:17', NULL, 0, NULL, NULL, NULL, NULL),
(305, 0, 'Whole Blood', 'CD4', NULL, 4, '2013-10-17 12:40:17', NULL, 0, NULL, NULL, NULL, NULL),
(306, 0, '', 'Full Haemogram', 'Celltac', 6, '2014-02-23 17:41:47', 0, 1, '!#!-%%%###', 0, 70, 24),
(307, 0, '', 'Albumin', '', 1, '2014-02-24 12:06:17', 0, 0, '', 0, 70, 24),
(308, 0, '', 'CSF for biochemistry', '', 6, '2014-02-25 06:10:49', 1, 0, NULL, 0, 0, 0),
(309, 0, '', 'Throat swab for culture', '', 7, '2014-02-25 06:22:31', 1, 0, '', 0, 0, 0),
(310, 0, '', 'Ascitic tap for microscopy', '', 7, '2014-02-25 06:23:58', 1, 0, NULL, 0, 0, 0),
(311, 0, '', 'HVS for culture and sensitivity', '', 7, '2014-02-25 06:41:26', 1, 0, NULL, 0, 0, 0),
(312, 0, '', 'Synovial fluid for microscopy', '', 7, '2014-02-25 06:51:54', 1, 0, NULL, 0, 0, 0),
(313, 0, '', 'Pleural tap for culture and sensitivity', '', 7, '2014-02-25 06:57:01', 1, 0, NULL, 0, 0, 0),
(314, 0, '', 'Pleural tap for microscopy', '', 7, '2014-02-25 06:59:10', 1, 0, NULL, 0, 0, 0),
(315, 0, '', 'Synovial fluid for culture and sensitivity', '', 7, '2014-02-25 06:59:17', 1, 0, NULL, 0, 0, 0),
(316, 0, '', 'Stool for C/S ', '', 7, '2014-02-25 07:11:31', 1, 0, NULL, 0, 0, 0),
(317, 0, '', 'Aspirate for culture and sensitivity', '', 7, '2014-02-25 07:57:22', 0, 0, '', 0, 0, 0),
(318, 0, '', 'Urine Culture and Sensitivity ', '', 7, '2014-02-27 06:58:58', 1, 0, '', 0, 0, 0),
(319, 0, '', 'Pus swab for culture and sensitivity', '', 7, '2014-02-25 08:36:57', 1, 0, NULL, 0, 0, 0),
(320, 0, '', 'Blood Culture and sensitivity ', '', 7, '2014-02-25 09:47:39', 1, 0, '', 0, 0, 0),
(321, 0, '', ' Aspirate for microscopy ', '', 7, '2014-02-25 13:07:33', 1, 1, NULL, 0, 0, 0),
(322, 0, '', 'Aspirate for microscopy', '', 7, '2014-02-25 13:08:22', 1, 0, NULL, 0, 0, 0),
(323, 0, '', 'culture', '', 7, '2014-03-08 08:17:52', 1, 0, NULL, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `test_type_costs`
--

CREATE TABLE IF NOT EXISTS `test_type_costs` (
  `earliest_date_valid` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `test_type_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `test_type_costs`
--

INSERT INTO `test_type_costs` (`earliest_date_valid`, `test_type_id`, `amount`) VALUES
('2012-11-07 10:54:24', 90, 10.00),
('2012-11-07 10:59:51', 19, 11.30),
('2012-11-09 18:39:13', 85, 0.00),
('2012-11-11 06:20:12', 112, 0.00),
('2012-11-11 06:20:51', 113, 0.00),
('2012-12-03 22:37:56', 63, 0.00),
('2012-12-07 17:56:40', 70, 0.00),
('2013-08-26 12:05:46', 39, 0.00),
('2013-08-26 13:05:35', 8, 0.00),
('2013-08-27 07:00:10', 64, 0.00),
('2013-09-17 09:32:07', 89, 0.00),
('2013-09-18 11:06:00', 114, 0.00),
('2013-10-15 09:18:15', 115, 0.00),
('2013-10-15 09:19:53', 116, 0.00),
('2013-10-17 09:36:21', 203, 0.00),
('2013-10-17 14:00:56', 127, 0.00),
('2013-10-17 15:28:17', 268, 0.00),
('2013-10-18 15:54:23', 193, 0.00),
('2013-10-19 08:07:30', 195, 0.00),
('2013-11-01 06:44:53', 159, 0.00),
('2013-11-01 07:51:03', 291, 0.00),
('2014-01-23 08:32:39', 175, 0.00),
('2014-01-23 08:32:39', 119, 0.00),
('2014-01-23 16:09:44', 212, 0.00),
('2014-01-23 16:10:02', 210, 0.00),
('2014-01-23 16:22:24', 278, 0.00),
('2014-01-24 12:36:53', 167, 0.00),
('2014-01-24 12:38:02', 157, 0.00),
('2014-01-25 14:26:53', 170, 0.00),
('2014-01-25 14:26:53', 140, 0.00),
('2014-01-25 14:27:39', 174, 0.00),
('2014-01-25 14:27:39', 125, 0.00),
('2014-02-14 14:41:40', 137, 0.00),
('2014-02-20 14:29:09', 276, 0.00),
('2014-02-20 14:29:17', 277, 0.00),
('2014-02-20 14:30:08', 296, 0.00),
('2014-02-20 14:30:24', 269, 0.00),
('2014-02-21 08:39:10', 306, 0.00),
('2014-02-23 14:20:10', 133, 0.00),
('2014-02-23 17:44:15', 176, 0.00),
('2014-02-24 08:05:55', 148, 0.00),
('2014-02-24 12:05:37', 307, 0.00),
('2014-02-24 12:07:33', 130, 0.00),
('2014-02-24 15:41:05', 265, 0.00),
('2014-02-25 06:10:29', 218, 0.00),
('2014-02-25 06:10:49', 308, 0.00),
('2014-02-25 06:20:49', 309, 0.00),
('2014-02-25 06:23:59', 310, 0.00),
('2014-02-25 06:29:34', 150, 0.00),
('2014-02-25 06:35:37', 221, 0.00),
('2014-02-25 06:36:01', 304, 0.00),
('2014-02-25 06:39:32', 284, 0.00),
('2014-02-25 06:41:26', 311, 0.00),
('2014-02-25 06:44:42', 271, 0.00),
('2014-02-25 06:45:52', 273, 0.00),
('2014-02-25 06:51:54', 312, 0.00),
('2014-02-25 06:54:36', 274, 0.00),
('2014-02-25 06:56:04', 272, 0.00),
('2014-02-25 06:57:01', 313, 0.00),
('2014-02-25 06:58:16', 275, 0.00),
('2014-02-25 06:59:10', 314, 0.00),
('2014-02-25 06:59:17', 315, 0.00),
('2014-02-25 07:06:40', 286, 0.00),
('2014-02-25 07:11:31', 316, 0.00),
('2014-02-25 07:53:33', 317, 0.00),
('2014-02-25 07:56:17', 318, 0.00),
('2014-02-25 08:33:13', 266, 0.00),
('2014-02-25 08:36:57', 319, 0.00),
('2014-02-25 08:52:32', 287, 0.00),
('2014-02-25 09:04:29', 121, 0.00),
('2014-02-25 09:14:28', 124, 0.00),
('2014-02-25 09:24:12', 283, 0.00),
('2014-02-25 09:32:55', 320, 0.00),
('2014-02-25 09:53:53', 270, 0.00),
('2014-02-25 09:57:26', 321, 0.00),
('2014-02-25 13:08:22', 322, 0.00),
('2014-02-26 06:11:42', 141, 0.00),
('2014-02-27 06:34:26', 145, 0.00),
('2014-02-28 10:48:36', 260, 0.00),
('2014-02-28 10:49:03', 200, 0.00),
('2014-02-28 10:49:18', 220, 0.00),
('2014-02-28 10:51:05', 254, 0.00),
('2014-02-28 10:57:14', 117, 0.00),
('2014-02-28 11:01:47', 259, 0.00),
('2014-02-28 11:01:47', 255, 0.00),
('2014-03-07 09:40:58', 146, 0.00),
('2014-03-07 09:46:44', 147, 0.00),
('2014-03-07 09:50:14', 135, 0.00),
('2014-03-07 09:59:09', 120, 0.00),
('2014-03-07 10:01:30', 134, 0.00),
('2014-03-07 10:12:29', 123, 0.00),
('2014-03-08 08:01:02', 263, 0.00),
('2014-03-08 08:01:36', 288, 0.00),
('2014-03-08 08:17:52', 323, 0.00),
('2014-03-11 03:05:23', 139, 0.00),
('2014-03-11 07:25:19', 144, 0.00),
('2014-03-11 07:25:47', 142, 0.00),
('2014-03-11 07:26:12', 143, 0.00),
('2014-03-13 19:53:29', 183, 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `test_type_measure`
--

CREATE TABLE IF NOT EXISTS `test_type_measure` (
  `ttm_id` int(11) NOT NULL AUTO_INCREMENT,
  `test_type_id` int(11) unsigned NOT NULL DEFAULT '0',
  `measure_id` int(11) unsigned NOT NULL DEFAULT '0',
  `ordering` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `nesting` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ttm_id`),
  UNIQUE KEY `uniq_ttid_mid` (`test_type_id`,`measure_id`),
  KEY `test_type_id` (`test_type_id`),
  KEY `measure_id` (`measure_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=221 ;

--
-- Dumping data for table `test_type_measure`
--

INSERT INTO `test_type_measure` (`ttm_id`, `test_type_id`, `measure_id`, `ordering`, `nesting`, `ts`) VALUES
(1, 117, 197, 0, 0, '2013-10-18 08:59:36'),
(2, 120, 200, 0, 0, '2013-10-18 08:59:36'),
(3, 123, 203, 0, 0, '2013-10-18 08:59:36'),
(4, 124, 201, 0, 0, '2013-10-18 08:59:36'),
(5, 127, 403, 0, 0, '2014-02-22 13:09:38'),
(6, 127, 404, 0, 0, '2014-02-22 13:09:38'),
(7, 131, 211, 0, 0, '2013-10-18 08:59:36'),
(8, 132, 212, 0, 0, '2013-10-18 08:59:36'),
(9, 134, 214, 0, 0, '2013-10-18 08:59:36'),
(10, 135, 415, 0, 0, '2014-03-07 09:51:32'),
(11, 136, 216, 0, 0, '2013-10-18 08:59:36'),
(12, 137, 408, 0, 0, '2014-02-23 14:19:58'),
(13, 138, 218, 0, 0, '2013-10-18 08:59:36'),
(14, 139, 219, 0, 0, '2013-10-18 08:59:36'),
(15, 141, 212, 0, 0, '2014-03-04 15:12:00'),
(16, 141, 214, 0, 0, '2014-03-04 15:12:00'),
(17, 141, 216, 0, 0, '2014-03-04 15:12:00'),
(18, 141, 218, 0, 0, '2014-03-04 15:12:00'),
(19, 141, 219, 0, 0, '2014-03-04 15:12:00'),
(20, 141, 408, 0, 0, '2014-03-04 15:12:00'),
(21, 141, 409, 0, 0, '2014-03-04 15:12:00'),
(22, 141, 412, 0, 0, '2014-03-04 15:12:00'),
(23, 141, 414, 0, 0, '2014-03-04 15:13:40'),
(24, 142, 222, 0, 0, '2013-10-18 08:59:36'),
(25, 143, 223, 0, 0, '2013-10-18 08:59:36'),
(26, 144, 224, 0, 0, '2013-10-18 08:59:36'),
(27, 145, 222, 0, 0, '2014-02-27 06:35:24'),
(28, 145, 223, 0, 0, '2014-02-27 06:35:24'),
(29, 145, 224, 0, 0, '2014-02-27 06:35:24'),
(30, 146, 226, 0, 0, '2013-10-18 08:59:36'),
(31, 147, 227, 0, 0, '2013-10-18 08:59:36'),
(32, 148, 222, 0, 0, '2014-02-24 11:29:37'),
(33, 148, 223, 0, 0, '2014-02-24 11:29:37'),
(34, 148, 224, 0, 0, '2014-02-24 11:29:37'),
(35, 148, 225, 0, 0, '2014-02-24 11:23:43'),
(36, 148, 226, 0, 0, '2014-02-24 11:23:43'),
(37, 148, 227, 0, 0, '2014-02-24 11:23:43'),
(38, 149, 229, 0, 0, '2013-10-18 08:59:36'),
(39, 150, 234, 0, 0, '2014-02-25 06:30:44'),
(40, 150, 235, 0, 0, '2014-02-25 06:30:44'),
(41, 151, 231, 0, 0, '2013-10-18 08:59:36'),
(42, 152, 232, 0, 0, '2013-10-18 08:59:36'),
(43, 153, 233, 0, 0, '2013-10-18 08:59:36'),
(44, 154, 234, 0, 0, '2013-10-18 08:59:36'),
(45, 155, 235, 0, 0, '2013-10-18 08:59:36'),
(46, 156, 236, 0, 0, '2013-10-18 08:59:36'),
(47, 157, 413, 0, 0, '2014-02-27 06:58:28'),
(48, 158, 238, 0, 0, '2013-10-18 08:59:36'),
(49, 159, 239, 0, 0, '2013-10-18 08:59:36'),
(50, 160, 240, 0, 0, '2013-10-18 08:59:36'),
(51, 161, 241, 0, 0, '2013-10-18 08:59:36'),
(52, 162, 242, 0, 0, '2013-10-18 08:59:36'),
(53, 163, 243, 0, 0, '2013-10-18 08:59:36'),
(54, 164, 244, 0, 0, '2013-10-18 08:59:36'),
(55, 165, 245, 0, 0, '2013-10-18 08:59:36'),
(56, 166, 246, 0, 0, '2013-10-18 08:59:36'),
(57, 167, 240, 0, 0, '2014-02-27 06:45:28'),
(58, 167, 241, 0, 0, '2014-02-27 06:45:28'),
(59, 167, 242, 0, 0, '2014-02-27 06:45:28'),
(60, 167, 243, 0, 0, '2014-02-27 06:45:28'),
(61, 167, 244, 0, 0, '2014-02-27 06:45:28'),
(62, 167, 245, 0, 0, '2014-02-27 06:45:28'),
(63, 167, 246, 0, 0, '2014-02-27 06:45:28'),
(64, 168, 248, 0, 0, '2013-10-18 08:59:36'),
(65, 169, 249, 0, 0, '2013-10-18 08:59:36'),
(66, 170, 212, 0, 0, '2014-02-22 15:06:56'),
(67, 170, 218, 0, 0, '2014-02-22 15:06:56'),
(68, 171, 251, 0, 0, '2013-10-18 08:59:36'),
(69, 172, 252, 0, 0, '2013-10-18 08:59:36'),
(70, 173, 253, 0, 0, '2013-10-18 08:59:36'),
(71, 175, 248, 0, 0, '2014-02-27 06:39:37'),
(72, 175, 249, 0, 0, '2014-02-27 06:39:37'),
(73, 175, 251, 0, 0, '2014-02-27 06:39:37'),
(74, 175, 252, 0, 0, '2014-02-27 06:39:37'),
(75, 175, 253, 0, 0, '2014-02-27 06:39:37'),
(76, 175, 403, 0, 0, '2014-02-27 06:39:37'),
(77, 175, 412, 0, 0, '2014-02-27 06:40:09'),
(78, 176, 256, 5, 1, '2014-03-12 07:01:53'),
(79, 176, 257, 4, 1, '2014-03-12 07:01:30'),
(80, 176, 258, 3, 1, '2014-03-12 07:01:13'),
(81, 176, 259, 2, 1, '2014-03-12 07:00:57'),
(82, 176, 260, 1, 1, '2014-03-12 07:00:38'),
(83, 176, 261, 0, 0, '2014-02-23 17:45:21'),
(84, 176, 262, 6, 0, '2014-03-12 07:03:30'),
(85, 176, 263, 7, 0, '2014-03-12 07:03:41'),
(86, 176, 264, 8, 0, '2014-03-12 07:03:53'),
(87, 176, 265, 9, 0, '2014-03-12 07:04:01'),
(88, 176, 266, 10, 0, '2014-03-12 07:04:10'),
(89, 176, 267, 11, 0, '2014-03-12 07:04:16'),
(90, 176, 268, 12, 0, '2014-03-12 07:04:25'),
(91, 176, 269, 13, 0, '2014-03-12 07:04:32'),
(92, 176, 270, 14, 0, '2014-03-12 07:04:42'),
(93, 176, 272, 15, 0, '2014-03-12 07:04:50'),
(94, 181, 256, 0, 0, '2014-02-21 06:43:03'),
(95, 181, 257, 0, 0, '2014-02-21 06:43:03'),
(96, 181, 258, 0, 0, '2014-02-21 06:43:04'),
(97, 181, 259, 0, 0, '2014-02-21 06:43:04'),
(98, 181, 260, 0, 0, '2014-02-21 06:43:04'),
(99, 181, 261, 0, 0, '2013-10-18 08:59:36'),
(100, 182, 262, 0, 0, '2013-10-18 08:59:36'),
(101, 183, 263, 0, 0, '2013-10-18 08:59:36'),
(102, 184, 264, 0, 0, '2013-10-18 08:59:36'),
(103, 185, 265, 0, 0, '2013-10-18 08:59:36'),
(104, 186, 266, 0, 0, '2013-10-18 08:59:36'),
(105, 187, 267, 0, 0, '2013-10-18 08:59:36'),
(106, 188, 268, 0, 0, '2013-10-18 08:59:36'),
(107, 189, 269, 0, 0, '2013-10-18 08:59:36'),
(108, 190, 270, 0, 0, '2013-10-18 08:59:36'),
(109, 192, 272, 0, 0, '2013-10-18 08:59:36'),
(110, 194, 274, 0, 0, '2013-10-18 08:59:36'),
(111, 195, 275, 0, 0, '2013-10-18 08:59:36'),
(112, 196, 276, 0, 0, '2013-10-18 08:59:36'),
(113, 197, 277, 0, 0, '2013-10-18 08:59:36'),
(114, 198, 278, 0, 0, '2013-10-18 08:59:36'),
(115, 221, 284, 0, 0, '2013-10-18 08:59:36'),
(116, 222, 302, 0, 0, '2013-10-18 08:59:36'),
(117, 223, 303, 0, 0, '2013-10-18 08:59:36'),
(118, 224, 304, 0, 0, '2013-10-18 08:59:36'),
(119, 225, 305, 0, 0, '2013-10-18 08:59:36'),
(120, 226, 306, 0, 0, '2013-10-18 08:59:36'),
(121, 244, 322, 0, 0, '2013-10-18 08:59:36'),
(122, 255, 335, 0, 0, '2013-10-18 08:59:36'),
(123, 260, 338, 0, 0, '2013-10-18 08:59:36'),
(124, 263, 282, 0, 0, '2014-03-08 08:10:21'),
(125, 263, 335, 0, 0, '2014-03-08 08:10:21'),
(126, 263, 338, 0, 0, '2014-03-08 08:10:21'),
(127, 263, 343, 0, 0, '2013-10-18 08:59:36'),
(128, 263, 407, 0, 0, '2014-03-08 08:10:21'),
(129, 265, 282, 0, 0, '2014-02-24 15:46:56'),
(130, 265, 335, 0, 0, '2014-02-24 15:46:56'),
(131, 265, 338, 0, 0, '2014-02-24 15:46:56'),
(132, 265, 405, 0, 0, '2014-02-24 15:46:56'),
(133, 265, 406, 0, 0, '2014-03-05 07:51:31'),
(134, 265, 407, 0, 0, '2014-03-05 07:51:31'),
(135, 267, 347, 0, 0, '2013-10-18 08:59:36'),
(136, 268, 302, 0, 0, '2014-02-25 07:18:26'),
(137, 268, 303, 0, 0, '2014-02-25 07:18:26'),
(138, 268, 304, 0, 0, '2014-02-25 07:18:26'),
(139, 268, 305, 0, 0, '2014-02-25 07:18:26'),
(140, 268, 306, 0, 0, '2014-02-25 07:18:26'),
(141, 271, 282, 0, 0, '2014-02-25 06:45:34'),
(142, 271, 322, 0, 0, '2014-02-25 06:45:34'),
(143, 276, 405, 0, 0, '2014-02-22 13:15:26'),
(144, 276, 406, 0, 0, '2014-02-22 13:15:26'),
(145, 276, 407, 0, 0, '2014-02-22 13:15:26'),
(146, 279, 359, 0, 0, '2013-10-18 08:59:36'),
(147, 281, 361, 0, 0, '2013-10-18 08:59:36'),
(148, 282, 362, 0, 0, '2013-10-18 08:59:36'),
(149, 285, 365, 0, 0, '2013-10-18 08:59:36'),
(150, 287, 252, 0, 0, '2014-03-06 07:45:35'),
(151, 287, 282, 0, 0, '2014-03-06 07:45:35'),
(152, 287, 335, 0, 0, '2014-03-06 07:45:35'),
(153, 287, 338, 0, 0, '2014-03-06 07:45:35'),
(154, 287, 403, 0, 0, '2014-03-06 07:45:35'),
(155, 287, 405, 0, 0, '2014-03-06 07:45:35'),
(156, 287, 406, 0, 0, '2014-03-06 07:45:35'),
(157, 287, 407, 0, 0, '2014-03-06 07:45:35'),
(158, 288, 368, 0, 0, '2013-10-18 08:59:36'),
(159, 289, 369, 0, 0, '2013-10-18 08:59:36'),
(160, 290, 370, 0, 0, '2013-10-18 08:59:36'),
(161, 291, 371, 0, 0, '2013-10-18 08:59:36'),
(162, 292, 372, 0, 0, '2013-10-18 08:59:36'),
(163, 293, 373, 0, 0, '2013-10-18 08:59:36'),
(164, 294, 374, 0, 0, '2013-10-18 08:59:36'),
(165, 295, 375, 0, 0, '2013-10-18 08:59:36'),
(166, 296, 376, 0, 0, '2013-10-18 08:59:36'),
(167, 297, 377, 0, 0, '2013-10-18 08:59:36'),
(168, 298, 378, 0, 0, '2013-10-18 08:59:36'),
(169, 299, 379, 0, 0, '2013-10-18 08:59:36'),
(170, 300, 380, 0, 0, '2013-10-18 08:59:36'),
(171, 301, 381, 0, 0, '2013-10-18 08:59:36'),
(172, 302, 382, 0, 0, '2013-10-18 08:59:36'),
(173, 303, 383, 0, 0, '2013-10-18 08:59:36'),
(174, 304, 384, 0, 0, '2013-10-18 08:59:36'),
(175, 305, 385, 0, 0, '2013-10-18 08:59:36'),
(176, 307, 409, 0, 0, '2014-02-24 12:06:17'),
(177, 308, 403, 0, 0, '2014-02-25 06:10:49'),
(178, 308, 404, 0, 0, '2014-02-25 06:10:49'),
(179, 309, 282, 0, 0, '2014-02-25 06:20:48'),
(180, 309, 405, 0, 0, '2014-02-25 06:20:48'),
(181, 309, 406, 0, 0, '2014-02-25 06:20:48'),
(182, 309, 407, 0, 0, '2014-02-25 06:20:48'),
(183, 310, 282, 0, 0, '2014-02-25 06:23:58'),
(184, 310, 407, 0, 0, '2014-02-25 06:23:58'),
(185, 311, 282, 0, 0, '2014-02-25 06:41:26'),
(186, 311, 322, 0, 0, '2014-02-25 06:41:26'),
(187, 311, 405, 0, 0, '2014-02-25 06:41:26'),
(188, 311, 406, 0, 0, '2014-02-25 06:41:26'),
(189, 312, 282, 0, 0, '2014-02-25 06:51:54'),
(190, 312, 407, 0, 0, '2014-02-25 06:51:54'),
(191, 313, 282, 0, 0, '2014-02-25 06:57:01'),
(192, 313, 405, 0, 0, '2014-02-25 06:57:01'),
(193, 313, 406, 0, 0, '2014-02-25 06:57:01'),
(194, 313, 407, 0, 0, '2014-02-25 06:57:01'),
(195, 314, 282, 0, 0, '2014-02-25 06:59:10'),
(196, 314, 407, 0, 0, '2014-02-25 06:59:10'),
(197, 315, 282, 0, 0, '2014-02-25 06:59:17'),
(198, 315, 405, 0, 0, '2014-02-25 06:59:17'),
(199, 315, 406, 0, 0, '2014-02-25 06:59:17'),
(200, 315, 407, 0, 0, '2014-02-25 06:59:17'),
(201, 316, 284, 0, 0, '2014-02-25 07:11:31'),
(202, 316, 405, 0, 0, '2014-02-25 07:11:31'),
(203, 316, 406, 0, 0, '2014-02-25 07:11:31'),
(204, 317, 411, 0, 0, '2014-02-25 09:21:07'),
(205, 318, 405, 0, 0, '2014-03-11 07:49:32'),
(206, 318, 406, 0, 0, '2014-03-11 07:49:32'),
(207, 319, 282, 0, 0, '2014-02-25 08:36:57'),
(208, 319, 405, 0, 0, '2014-02-25 08:36:57'),
(209, 319, 406, 0, 0, '2014-02-25 08:36:57'),
(210, 319, 407, 0, 0, '2014-02-25 08:36:57'),
(211, 320, 282, 0, 0, '2014-02-25 09:32:55'),
(212, 320, 322, 0, 0, '2014-02-25 09:32:55'),
(213, 320, 361, 0, 0, '2014-02-25 09:47:39'),
(214, 320, 362, 0, 0, '2014-02-25 09:32:55'),
(215, 320, 405, 0, 0, '2014-02-25 09:47:39'),
(216, 320, 406, 0, 0, '2014-02-25 09:32:55'),
(217, 322, 350, 0, 0, '2014-02-25 13:08:22'),
(218, 323, 284, 0, 0, '2014-03-08 08:17:52'),
(219, 323, 405, 0, 0, '2014-03-08 08:17:52'),
(220, 323, 406, 0, 0, '2014-03-08 08:17:52');

-- --------------------------------------------------------

--
-- Table structure for table `tmp_test_measure`
--

CREATE TABLE IF NOT EXISTS `tmp_test_measure` (
  `tm_id` int(11) NOT NULL DEFAULT '0',
  `test_id` int(11) NOT NULL,
  `lab_no` int(11) NOT NULL,
  `measure_id` int(11) NOT NULL,
  `result` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tmp_test_type_measure`
--

CREATE TABLE IF NOT EXISTS `tmp_test_type_measure` (
  `test_type_id` int(11) unsigned NOT NULL DEFAULT '0',
  `measure_id` int(11) unsigned NOT NULL DEFAULT '0',
  `ts` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tmp_test_type_measure`
--

INSERT INTO `tmp_test_type_measure` (`test_type_id`, `measure_id`, `ts`) VALUES
(117, 197, '2013-10-18 08:59:36'),
(118, 198, '2013-10-18 08:59:36'),
(201, 198, '2013-10-18 08:59:36'),
(206, 198, '2013-10-18 08:59:36'),
(217, 198, '2013-10-18 08:59:36'),
(230, 198, '2013-10-18 08:59:36'),
(232, 198, '2013-10-18 08:59:36'),
(236, 198, '2013-10-18 08:59:36'),
(237, 198, '2013-10-18 08:59:36'),
(250, 198, '2013-10-18 08:59:36'),
(252, 198, '2013-10-18 08:59:36'),
(256, 198, '2013-10-18 08:59:36'),
(261, 198, '2013-10-18 08:59:36'),
(120, 200, '2013-10-18 08:59:36'),
(121, 201, '2013-10-18 08:59:36'),
(122, 201, '2013-10-18 08:59:36'),
(124, 201, '2013-10-18 08:59:36'),
(123, 203, '2013-10-18 08:59:36'),
(125, 205, '2013-10-18 08:59:36'),
(128, 205, '2013-10-18 08:59:36'),
(174, 205, '2013-10-18 08:59:36'),
(126, 206, '2013-10-18 08:59:36'),
(129, 206, '2013-10-18 08:59:36'),
(130, 210, '2013-10-18 08:59:36'),
(131, 211, '2013-10-18 08:59:36'),
(132, 212, '2013-10-18 08:59:36'),
(133, 213, '2013-10-18 08:59:36'),
(134, 214, '2013-10-18 08:59:36'),
(135, 215, '2013-10-18 08:59:36'),
(136, 216, '2013-10-18 08:59:36'),
(138, 218, '2013-10-18 08:59:36'),
(139, 219, '2013-10-18 08:59:36'),
(142, 222, '2013-10-18 08:59:36'),
(143, 223, '2013-10-18 08:59:36'),
(144, 224, '2013-10-18 08:59:36'),
(146, 226, '2013-10-18 08:59:36'),
(147, 227, '2013-10-18 08:59:36'),
(149, 229, '2013-10-18 08:59:36'),
(151, 231, '2013-10-18 08:59:36'),
(152, 232, '2013-10-18 08:59:36'),
(153, 233, '2013-10-18 08:59:36'),
(154, 234, '2013-10-18 08:59:36'),
(155, 235, '2013-10-18 08:59:36'),
(156, 236, '2013-10-18 08:59:36'),
(158, 238, '2013-10-18 08:59:36'),
(159, 239, '2013-10-18 08:59:36'),
(160, 240, '2013-10-18 08:59:36'),
(161, 241, '2013-10-18 08:59:36'),
(162, 242, '2013-10-18 08:59:36'),
(163, 243, '2013-10-18 08:59:36'),
(164, 244, '2013-10-18 08:59:36'),
(165, 245, '2013-10-18 08:59:36'),
(166, 246, '2013-10-18 08:59:36'),
(168, 248, '2013-10-18 08:59:36'),
(169, 249, '2013-10-18 08:59:36'),
(140, 250, '2013-10-18 08:59:36'),
(171, 251, '2013-10-18 08:59:36'),
(172, 252, '2013-10-18 08:59:36'),
(173, 253, '2013-10-18 08:59:36'),
(176, 256, '2013-10-18 08:59:36'),
(177, 257, '2013-10-18 08:59:36'),
(178, 258, '2013-10-18 08:59:36'),
(179, 259, '2013-10-18 08:59:36'),
(180, 260, '2013-10-18 08:59:36'),
(181, 261, '2013-10-18 08:59:36'),
(182, 262, '2013-10-18 08:59:36'),
(183, 263, '2013-10-18 08:59:36'),
(184, 264, '2013-10-18 08:59:36'),
(185, 265, '2013-10-18 08:59:36'),
(186, 266, '2013-10-18 08:59:36'),
(187, 267, '2013-10-18 08:59:36'),
(188, 268, '2013-10-18 08:59:36'),
(189, 269, '2013-10-18 08:59:36'),
(190, 270, '2013-10-18 08:59:36'),
(191, 271, '2013-10-18 08:59:36'),
(192, 272, '2013-10-18 08:59:36'),
(193, 273, '2013-10-18 08:59:36'),
(194, 274, '2013-10-18 08:59:36'),
(195, 275, '2013-10-18 08:59:36'),
(196, 276, '2013-10-18 08:59:36'),
(197, 277, '2013-10-18 08:59:36'),
(198, 278, '2013-10-18 08:59:36'),
(199, 279, '2013-10-18 08:59:36'),
(205, 279, '2013-10-18 08:59:36'),
(208, 279, '2013-10-18 08:59:36'),
(214, 279, '2013-10-18 08:59:36'),
(219, 279, '2013-10-18 08:59:36'),
(227, 279, '2013-10-18 08:59:36'),
(233, 279, '2013-10-18 08:59:36'),
(239, 279, '2013-10-18 08:59:36'),
(245, 279, '2013-10-18 08:59:36'),
(247, 279, '2013-10-18 08:59:36'),
(253, 279, '2013-10-18 08:59:36'),
(200, 280, '2013-10-18 08:59:36'),
(203, 280, '2013-10-18 08:59:36'),
(215, 280, '2013-10-18 08:59:36'),
(220, 280, '2013-10-18 08:59:36'),
(228, 280, '2013-10-18 08:59:36'),
(234, 280, '2013-10-18 08:59:36'),
(240, 280, '2013-10-18 08:59:36'),
(246, 280, '2013-10-18 08:59:36'),
(248, 280, '2013-10-18 08:59:36'),
(254, 280, '2013-10-18 08:59:36'),
(202, 282, '2013-10-18 08:59:36'),
(207, 282, '2013-10-18 08:59:36'),
(209, 282, '2013-10-18 08:59:36'),
(213, 282, '2013-10-18 08:59:36'),
(216, 282, '2013-10-18 08:59:36'),
(229, 282, '2013-10-18 08:59:36'),
(231, 282, '2013-10-18 08:59:36'),
(235, 282, '2013-10-18 08:59:36'),
(238, 282, '2013-10-18 08:59:36'),
(241, 282, '2013-10-18 08:59:36'),
(243, 282, '2013-10-18 08:59:36'),
(249, 282, '2013-10-18 08:59:36'),
(251, 282, '2013-10-18 08:59:36'),
(257, 282, '2013-10-18 08:59:36'),
(262, 282, '2013-10-18 08:59:36'),
(204, 284, '2013-10-18 08:59:36'),
(211, 284, '2013-10-18 08:59:36'),
(221, 284, '2013-10-18 08:59:36'),
(264, 284, '2013-10-18 08:59:36'),
(218, 298, '2013-10-18 08:59:36'),
(222, 302, '2013-10-18 08:59:36'),
(223, 303, '2013-10-18 08:59:36'),
(224, 304, '2013-10-18 08:59:36'),
(225, 305, '2013-10-18 08:59:36'),
(226, 306, '2013-10-18 08:59:36'),
(242, 322, '2013-10-18 08:59:36'),
(244, 322, '2013-10-18 08:59:36'),
(280, 322, '2013-10-18 08:59:36'),
(255, 335, '2013-10-18 08:59:36'),
(259, 335, '2013-10-18 08:59:36'),
(258, 338, '2013-10-18 08:59:36'),
(260, 338, '2013-10-18 08:59:36'),
(263, 343, '2013-10-18 08:59:36'),
(266, 346, '2013-10-18 08:59:36'),
(267, 347, '2013-10-18 08:59:36'),
(270, 350, '2013-10-18 08:59:36'),
(272, 352, '2013-10-18 08:59:36'),
(273, 353, '2013-10-18 08:59:36'),
(274, 354, '2013-10-18 08:59:36'),
(275, 355, '2013-10-18 08:59:36'),
(278, 358, '2013-10-18 08:59:36'),
(279, 359, '2013-10-18 08:59:36'),
(281, 361, '2013-10-18 08:59:36'),
(282, 362, '2013-10-18 08:59:36'),
(283, 363, '2013-10-18 08:59:36'),
(284, 364, '2013-10-18 08:59:36'),
(285, 365, '2013-10-18 08:59:36'),
(286, 366, '2013-10-18 08:59:36'),
(288, 368, '2013-10-18 08:59:36'),
(289, 369, '2013-10-18 08:59:36'),
(290, 370, '2013-10-18 08:59:36'),
(291, 371, '2013-10-18 08:59:36'),
(292, 372, '2013-10-18 08:59:36'),
(293, 373, '2013-10-18 08:59:36'),
(294, 374, '2013-10-18 08:59:36'),
(295, 375, '2013-10-18 08:59:36'),
(296, 376, '2013-10-18 08:59:36'),
(297, 377, '2013-10-18 08:59:36'),
(298, 378, '2013-10-18 08:59:36'),
(299, 379, '2013-10-18 08:59:36'),
(300, 380, '2013-10-18 08:59:36'),
(301, 381, '2013-10-18 08:59:36'),
(302, 382, '2013-10-18 08:59:36'),
(303, 383, '2013-10-18 08:59:36'),
(304, 384, '2013-10-18 08:59:36'),
(305, 385, '2013-10-18 08:59:36'),
(270, 197, '2014-02-20 14:12:53'),
(270, 198, '2014-02-20 14:12:53'),
(119, 201, '2014-02-20 14:12:53'),
(130, 205, '2014-02-20 14:12:53'),
(130, 206, '2014-02-20 14:12:53'),
(60, 210, '2014-02-20 14:12:53'),
(140, 212, '2014-02-20 14:12:53'),
(141, 213, '2014-02-20 14:12:53'),
(141, 215, '2014-02-20 14:12:53'),
(141, 217, '2014-02-20 14:12:53'),
(140, 218, '2014-02-20 14:12:53'),
(141, 250, '2014-02-20 14:12:54'),
(119, 248, '2014-02-20 14:12:55'),
(175, 250, '2014-02-20 14:12:55'),
(175, 205, '2014-02-20 14:12:55'),
(181, 256, '2014-02-20 14:12:55'),
(181, 257, '2014-02-20 14:12:55'),
(181, 258, '2014-02-20 14:12:55'),
(181, 259, '2014-02-20 14:12:55'),
(181, 260, '2014-02-20 14:12:55'),
(193, 261, '2014-02-20 14:12:55'),
(193, 262, '2014-02-20 14:12:55'),
(193, 263, '2014-02-20 14:12:55'),
(193, 264, '2014-02-20 14:12:55'),
(193, 265, '2014-02-20 14:12:56'),
(193, 266, '2014-02-20 14:12:56'),
(193, 267, '2014-02-20 14:12:56'),
(193, 268, '2014-02-20 14:12:56'),
(193, 269, '2014-02-20 14:12:56'),
(193, 270, '2014-02-20 14:12:56'),
(193, 271, '2014-02-20 14:12:56'),
(193, 272, '2014-02-20 14:12:56'),
(266, 279, '2014-02-20 14:12:56'),
(266, 280, '2014-02-20 14:12:56'),
(266, 198, '2014-02-20 14:12:56'),
(266, 282, '2014-02-20 14:12:56'),
(278, 280, '2014-02-20 14:12:56'),
(278, 284, '2014-02-20 14:12:56'),
(269, 279, '2014-02-20 14:12:56'),
(269, 198, '2014-02-20 14:12:56'),
(269, 282, '2014-02-20 14:12:56'),
(278, 279, '2014-02-20 14:12:56'),
(278, 282, '2014-02-20 14:12:56'),
(278, 284, '2014-02-20 14:12:56'),
(218, 282, '2014-02-20 14:12:56'),
(218, 279, '2014-02-20 14:12:57'),
(218, 280, '2014-02-20 14:12:57'),
(218, 282, '2014-02-20 14:12:57'),
(218, 198, '2014-02-20 14:12:57'),
(286, 279, '2014-02-20 14:12:57'),
(286, 280, '2014-02-20 14:12:57'),
(286, 284, '2014-02-20 14:12:57'),
(272, 279, '2014-02-20 14:12:57'),
(272, 280, '2014-02-20 14:12:57'),
(272, 282, '2014-02-20 14:12:57'),
(272, 198, '2014-02-20 14:12:57'),
(273, 282, '2014-02-20 14:12:57'),
(273, 198, '2014-02-20 14:12:57'),
(274, 279, '2014-02-20 14:12:57'),
(274, 280, '2014-02-20 14:12:57'),
(274, 282, '2014-02-20 14:12:57'),
(274, 198, '2014-02-20 14:12:57'),
(275, 198, '2014-02-20 14:12:57'),
(275, 282, '2014-02-20 14:12:57'),
(284, 279, '2014-02-20 14:12:58'),
(284, 280, '2014-02-20 14:12:58'),
(284, 282, '2014-02-20 14:12:58'),
(284, 322, '2014-02-20 14:12:58'),
(283, 279, '2014-02-20 14:12:58'),
(283, 280, '2014-02-20 14:12:58'),
(69, 282, '2014-02-20 14:12:58'),
(277, 282, '2014-02-20 14:12:58'),
(277, 198, '2014-02-20 14:12:58'),
(263, 279, '2014-02-20 14:12:58'),
(263, 280, '2014-02-20 14:12:58'),
(263, 198, '2014-02-20 14:12:58'),
(204, 335, '2014-02-20 14:12:58'),
(204, 338, '2014-02-20 14:12:59'),
(204, 198, '2014-02-20 14:12:59'),
(204, 282, '2014-02-20 14:12:59'),
(60, 345, '2014-02-20 14:12:59'),
(283, 322, '2014-02-20 14:12:59'),
(283, 361, '2014-02-20 14:12:59'),
(283, 362, '2014-02-20 14:12:59'),
(270, 197, '2014-02-21 06:42:56'),
(270, 198, '2014-02-21 06:42:57'),
(119, 201, '2014-02-21 06:42:57'),
(130, 205, '2014-02-21 06:42:58'),
(130, 206, '2014-02-21 06:42:58'),
(60, 210, '2014-02-21 06:42:59'),
(140, 212, '2014-02-21 06:42:59'),
(141, 213, '2014-02-21 06:42:59'),
(141, 215, '2014-02-21 06:42:59'),
(141, 217, '2014-02-21 06:43:00'),
(140, 218, '2014-02-21 06:43:00'),
(141, 250, '2014-02-21 06:43:00'),
(119, 248, '2014-02-21 06:43:02'),
(175, 250, '2014-02-21 06:43:03'),
(175, 205, '2014-02-21 06:43:03'),
(181, 256, '2014-02-21 06:43:03'),
(181, 257, '2014-02-21 06:43:03'),
(181, 258, '2014-02-21 06:43:04'),
(181, 259, '2014-02-21 06:43:04'),
(181, 260, '2014-02-21 06:43:04'),
(193, 261, '2014-02-21 06:43:04'),
(193, 262, '2014-02-21 06:43:04'),
(193, 263, '2014-02-21 06:43:04'),
(193, 264, '2014-02-21 06:43:04'),
(193, 265, '2014-02-21 06:43:04'),
(193, 266, '2014-02-21 06:43:05'),
(193, 267, '2014-02-21 06:43:05'),
(193, 268, '2014-02-21 06:43:05'),
(193, 269, '2014-02-21 06:43:05'),
(193, 270, '2014-02-21 06:43:05'),
(193, 271, '2014-02-21 06:43:05'),
(193, 272, '2014-02-21 06:43:05'),
(266, 279, '2014-02-21 06:43:05'),
(266, 280, '2014-02-21 06:43:05'),
(266, 198, '2014-02-21 06:43:05'),
(266, 282, '2014-02-21 06:43:05'),
(278, 280, '2014-02-21 06:43:05'),
(278, 284, '2014-02-21 06:43:05'),
(269, 279, '2014-02-21 06:43:05'),
(269, 198, '2014-02-21 06:43:05'),
(269, 282, '2014-02-21 06:43:05'),
(278, 279, '2014-02-21 06:43:05'),
(278, 282, '2014-02-21 06:43:06'),
(278, 284, '2014-02-21 06:43:06'),
(218, 282, '2014-02-21 06:43:06'),
(218, 279, '2014-02-21 06:43:06'),
(218, 280, '2014-02-21 06:43:06'),
(218, 282, '2014-02-21 06:43:06'),
(218, 198, '2014-02-21 06:43:06'),
(286, 279, '2014-02-21 06:43:06'),
(286, 280, '2014-02-21 06:43:06'),
(286, 284, '2014-02-21 06:43:06'),
(272, 279, '2014-02-21 06:43:07'),
(272, 280, '2014-02-21 06:43:07'),
(272, 282, '2014-02-21 06:43:07'),
(272, 198, '2014-02-21 06:43:07'),
(273, 282, '2014-02-21 06:43:07'),
(273, 198, '2014-02-21 06:43:07'),
(274, 279, '2014-02-21 06:43:07'),
(274, 280, '2014-02-21 06:43:07'),
(274, 282, '2014-02-21 06:43:07'),
(274, 198, '2014-02-21 06:43:07'),
(275, 198, '2014-02-21 06:43:07'),
(275, 282, '2014-02-21 06:43:07'),
(284, 279, '2014-02-21 06:43:07'),
(284, 280, '2014-02-21 06:43:08'),
(284, 282, '2014-02-21 06:43:08'),
(284, 322, '2014-02-21 06:43:08'),
(283, 279, '2014-02-21 06:43:08'),
(283, 280, '2014-02-21 06:43:08'),
(69, 282, '2014-02-21 06:43:09'),
(277, 282, '2014-02-21 06:43:09'),
(277, 198, '2014-02-21 06:43:09'),
(263, 279, '2014-02-21 06:43:09'),
(263, 280, '2014-02-21 06:43:09'),
(263, 198, '2014-02-21 06:43:09'),
(204, 335, '2014-02-21 06:43:09'),
(204, 338, '2014-02-21 06:43:09'),
(204, 198, '2014-02-21 06:43:09'),
(204, 282, '2014-02-21 06:43:09'),
(60, 345, '2014-02-21 06:43:10'),
(283, 322, '2014-02-21 06:43:10'),
(283, 361, '2014-02-21 06:43:10'),
(283, 362, '2014-02-21 06:43:10'),
(127, 403, '2014-02-22 13:09:38'),
(127, 404, '2014-02-22 13:09:38'),
(276, 405, '2014-02-22 13:15:26'),
(276, 406, '2014-02-22 13:15:26'),
(276, 407, '2014-02-22 13:15:26'),
(170, 218, '2014-02-22 15:06:56'),
(170, 212, '2014-02-22 15:06:56'),
(137, 408, '2014-02-23 14:19:58'),
(176, 261, '2014-02-23 17:45:21'),
(176, 257, '2014-02-23 17:53:03'),
(176, 263, '2014-02-23 17:53:03'),
(176, 264, '2014-02-23 17:53:03'),
(176, 259, '2014-02-23 17:53:03'),
(176, 266, '2014-02-23 17:53:03'),
(176, 267, '2014-02-23 17:53:03'),
(176, 265, '2014-02-23 17:53:03'),
(176, 258, '2014-02-23 17:53:03'),
(176, 260, '2014-02-23 17:53:03'),
(176, 270, '2014-02-23 17:53:03'),
(176, 272, '2014-02-23 17:53:03'),
(176, 269, '2014-02-23 17:53:03'),
(176, 262, '2014-02-23 17:53:03'),
(176, 268, '2014-02-23 17:53:03'),
(148, 226, '2014-02-24 11:23:43'),
(148, 225, '2014-02-24 11:23:43'),
(148, 227, '2014-02-24 11:23:43'),
(148, 222, '2014-02-24 11:29:37'),
(148, 223, '2014-02-24 11:29:37'),
(148, 224, '2014-02-24 11:29:37'),
(133, 409, '2014-02-24 12:03:46'),
(307, 409, '2014-02-24 12:06:17'),
(265, 338, '2014-02-24 15:46:56'),
(265, 405, '2014-02-24 15:46:56'),
(265, 282, '2014-02-24 15:46:56'),
(265, 335, '2014-02-24 15:46:56'),
(308, 403, '2014-02-25 06:10:49'),
(308, 404, '2014-02-25 06:10:49'),
(309, 282, '2014-02-25 06:20:48'),
(309, 405, '2014-02-25 06:20:48'),
(309, 406, '2014-02-25 06:20:48'),
(309, 407, '2014-02-25 06:20:48'),
(310, 282, '2014-02-25 06:23:58'),
(310, 407, '2014-02-25 06:23:58'),
(150, 234, '2014-02-25 06:30:44'),
(150, 235, '2014-02-25 06:30:44'),
(311, 282, '2014-02-25 06:41:26'),
(311, 322, '2014-02-25 06:41:26'),
(311, 405, '2014-02-25 06:41:26'),
(311, 406, '2014-02-25 06:41:26'),
(271, 282, '2014-02-25 06:45:34'),
(271, 322, '2014-02-25 06:45:34'),
(312, 282, '2014-02-25 06:51:54'),
(312, 407, '2014-02-25 06:51:54'),
(313, 282, '2014-02-25 06:57:01'),
(313, 405, '2014-02-25 06:57:01'),
(313, 406, '2014-02-25 06:57:01'),
(313, 407, '2014-02-25 06:57:01'),
(314, 282, '2014-02-25 06:59:10'),
(314, 407, '2014-02-25 06:59:10'),
(315, 282, '2014-02-25 06:59:17'),
(315, 405, '2014-02-25 06:59:17'),
(315, 406, '2014-02-25 06:59:17'),
(315, 407, '2014-02-25 06:59:17'),
(316, 284, '2014-02-25 07:11:31'),
(316, 405, '2014-02-25 07:11:31'),
(316, 406, '2014-02-25 07:11:31'),
(268, 302, '2014-02-25 07:18:26'),
(268, 304, '2014-02-25 07:18:26'),
(268, 303, '2014-02-25 07:18:26'),
(268, 305, '2014-02-25 07:18:26'),
(268, 306, '2014-02-25 07:18:26'),
(319, 282, '2014-02-25 08:36:57'),
(319, 405, '2014-02-25 08:36:57'),
(319, 406, '2014-02-25 08:36:57'),
(319, 407, '2014-02-25 08:36:57'),
(317, 411, '2014-02-25 09:21:07'),
(320, 282, '2014-02-25 09:32:55'),
(320, 322, '2014-02-25 09:32:55'),
(320, 362, '2014-02-25 09:32:55'),
(320, 406, '2014-02-25 09:32:55'),
(320, 405, '2014-02-25 09:47:39'),
(320, 361, '2014-02-25 09:47:39'),
(321, 197, '2014-02-25 09:57:26'),
(321, 407, '2014-02-25 09:57:26'),
(322, 350, '2014-02-25 13:08:22'),
(145, 222, '2014-02-27 06:35:24'),
(145, 223, '2014-02-27 06:35:24'),
(145, 224, '2014-02-27 06:35:24'),
(175, 251, '2014-02-27 06:39:37'),
(175, 403, '2014-02-27 06:39:37'),
(175, 248, '2014-02-27 06:39:37'),
(175, 253, '2014-02-27 06:39:37'),
(175, 252, '2014-02-27 06:39:37'),
(175, 249, '2014-02-27 06:39:37'),
(175, 412, '2014-02-27 06:40:09'),
(167, 241, '2014-02-27 06:45:28'),
(167, 246, '2014-02-27 06:45:28'),
(167, 242, '2014-02-27 06:45:28'),
(167, 245, '2014-02-27 06:45:28'),
(167, 240, '2014-02-27 06:45:28'),
(167, 244, '2014-02-27 06:45:28'),
(167, 243, '2014-02-27 06:45:28'),
(157, 413, '2014-02-27 06:58:28'),
(318, 358, '2014-02-27 06:59:46'),
(141, 408, '2014-03-04 15:12:00'),
(141, 409, '2014-03-04 15:12:00'),
(141, 214, '2014-03-04 15:12:00'),
(141, 412, '2014-03-04 15:12:00'),
(141, 218, '2014-03-04 15:12:00'),
(141, 216, '2014-03-04 15:12:00'),
(141, 212, '2014-03-04 15:12:00'),
(141, 219, '2014-03-04 15:12:00'),
(141, 414, '2014-03-04 15:13:40'),
(265, 406, '2014-03-05 07:51:31'),
(265, 407, '2014-03-05 07:51:31'),
(287, 338, '2014-03-06 07:45:35'),
(287, 405, '2014-03-06 07:45:35'),
(287, 403, '2014-03-06 07:45:35'),
(287, 282, '2014-03-06 07:45:35'),
(287, 335, '2014-03-06 07:45:35'),
(287, 252, '2014-03-06 07:45:35'),
(287, 406, '2014-03-06 07:45:35'),
(287, 407, '2014-03-06 07:45:35'),
(135, 415, '2014-03-07 09:51:32'),
(263, 338, '2014-03-08 08:10:21'),
(263, 282, '2014-03-08 08:10:21'),
(263, 335, '2014-03-08 08:10:21'),
(263, 407, '2014-03-08 08:10:21'),
(323, 284, '2014-03-08 08:17:52'),
(323, 405, '2014-03-08 08:17:52'),
(323, 406, '2014-03-08 08:17:52');

-- --------------------------------------------------------

--
-- Table structure for table `unit`
--

CREATE TABLE IF NOT EXISTS `unit` (
  `unit_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `unit` varchar(45) NOT NULL DEFAULT '',
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`unit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(45) NOT NULL DEFAULT '',
  `password` varchar(45) NOT NULL DEFAULT '',
  `actualname` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `created_by` int(11) unsigned DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `lab_config_id` int(10) unsigned NOT NULL,
  `level` int(10) unsigned DEFAULT NULL,
  `phone` varchar(45) DEFAULT NULL,
  `lang_id` varchar(45) NOT NULL DEFAULT 'default',
  PRIMARY KEY (`user_id`),
  KEY `user_id_index` (`lab_config_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Users are anybody that works in the lab.' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `user_feedback`
--

CREATE TABLE IF NOT EXISTS `user_feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `rating` int(3) DEFAULT NULL,
  `comments` varchar(500) DEFAULT NULL,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `user_props`
--

CREATE TABLE IF NOT EXISTS `user_props` (
  `User_Id` varchar(50) NOT NULL DEFAULT '',
  `AppCodeName` varchar(25) NOT NULL DEFAULT '',
  `AppName` varchar(25) NOT NULL DEFAULT '',
  `AppVersion` varchar(25) NOT NULL DEFAULT '',
  `CookieEnabled` tinyint(1) NOT NULL DEFAULT '0',
  `Platform` varchar(20) NOT NULL DEFAULT '',
  `UserAgent` varchar(200) NOT NULL DEFAULT '',
  `SystemLanguage` varchar(15) NOT NULL DEFAULT '',
  `UserLanguage` varchar(15) NOT NULL DEFAULT '',
  `Language` varchar(15) NOT NULL DEFAULT '',
  `ScreenAvailHeight` int(11) NOT NULL DEFAULT '0',
  `ScreenAvailWidth` int(11) NOT NULL DEFAULT '0',
  `ScreenColorDepth` int(11) NOT NULL DEFAULT '0',
  `ScreenHeight` int(11) NOT NULL DEFAULT '0',
  `ScreenWidth` int(11) NOT NULL DEFAULT '0',
  `Recorded_At` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_rating`
--

CREATE TABLE IF NOT EXISTS `user_rating` (
  `user_id` int(10) unsigned NOT NULL,
  `rating` int(10) unsigned NOT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`,`ts`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `worksheet_custom`
--

CREATE TABLE IF NOT EXISTS `worksheet_custom` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `header` varchar(500) NOT NULL,
  `footer` varchar(500) NOT NULL,
  `title` varchar(500) NOT NULL,
  `p_fields` varchar(100) NOT NULL,
  `s_fields` varchar(100) NOT NULL,
  `t_fields` varchar(100) NOT NULL,
  `p_custom` varchar(100) NOT NULL,
  `s_custom` varchar(100) NOT NULL,
  `margins` varchar(50) NOT NULL,
  `id_fields` varchar(45) NOT NULL DEFAULT '0,0,0',
  `landscape` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `worksheet_custom_test`
--

CREATE TABLE IF NOT EXISTS `worksheet_custom_test` (
  `worksheet_id` int(10) unsigned NOT NULL,
  `test_type_id` int(10) unsigned NOT NULL,
  `measure_id` int(10) unsigned NOT NULL,
  `width` varchar(45) NOT NULL,
  KEY `worksheet_id` (`worksheet_id`),
  KEY `test_type_id` (`test_type_id`),
  KEY `measure_id` (`measure_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `worksheet_custom_userfield`
--

CREATE TABLE IF NOT EXISTS `worksheet_custom_userfield` (
  `worksheet_id` int(10) unsigned NOT NULL,
  `name` varchar(70) NOT NULL DEFAULT '',
  `width` int(10) unsigned NOT NULL DEFAULT '10',
  `field_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  KEY `Primary Key` (`field_id`),
  KEY `worksheet_id` (`worksheet_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
