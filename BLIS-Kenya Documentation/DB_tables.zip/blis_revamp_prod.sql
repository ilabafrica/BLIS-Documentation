-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 31, 2014 at 11:53 AM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `blis_revamp_prod`
--

-- --------------------------------------------------------

--
-- Table structure for table `access_log`
--

CREATE TABLE IF NOT EXISTS `access_log` (
  `idaccess_log` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `access_log_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `access_type` int(11) DEFAULT NULL,
  `ip_address` varchar(50) DEFAULT NULL,
  `user_name` varchar(45) DEFAULT NULL,
  `access_sessionid` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`idaccess_log`),
  KEY `access_type_idx` (`access_type`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `access_log`
--

INSERT INTO `access_log` (`idaccess_log`, `user_id`, `access_log_ts`, `access_type`, `ip_address`, `user_name`, `access_sessionid`) VALUES
(1, 1, '2014-03-31 06:22:53', 1, '127.0.0.1', 'superadmin', 'pulbn9ci8uggv3haqakifj6ec6'),
(2, 1, '2014-03-31 07:22:11', 1, '127.0.0.1', 'superadmin', 'pulbn9ci8uggv3haqakifj6ec6'),
(3, 1, '2014-03-31 08:14:30', 1, '127.0.0.1', 'superadmin', 'dmp4ppq6no1gnsg8i58foatu90');

-- --------------------------------------------------------

--
-- Table structure for table `access_type`
--

CREATE TABLE IF NOT EXISTS `access_type` (
  `idaccess_type` int(11) NOT NULL AUTO_INCREMENT,
  `access_typename` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idaccess_type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `audit_trail`
--

CREATE TABLE IF NOT EXISTS `audit_trail` (
  `audit_trail_id` int(11) NOT NULL AUTO_INCREMENT,
  `at_userid` int(11) DEFAULT NULL,
  `at_operationtype` varchar(45) DEFAULT NULL,
  `at_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `at_dbname` varchar(45) DEFAULT NULL,
  `at_tablename` varchar(45) DEFAULT NULL,
  `at_objectid` int(11) DEFAULT NULL,
  `at_fieldname` varchar(45) DEFAULT NULL,
  `at_oldvalue` varchar(200) DEFAULT NULL,
  `at_newvalue` varchar(200) DEFAULT NULL,
  `at_sessionid` varchar(100) DEFAULT NULL,
  `at_descript` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`audit_trail_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13893 ;

-- --------------------------------------------------------

--
-- Table structure for table `external_lab_request`
--

CREATE TABLE IF NOT EXISTS `external_lab_request` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `labNo` varchar(100) DEFAULT NULL,
  `parentLabNo` varchar(100) DEFAULT NULL,
  `requestingClinician` varchar(100) DEFAULT NULL,
  `investigation` varchar(100) DEFAULT NULL,
  `requestDate` datetime DEFAULT NULL,
  `orderStage` varchar(45) DEFAULT NULL,
  `patientVisitNumber` varchar(45) DEFAULT NULL,
  `patient_id` varchar(100) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `dateOfBirth` datetime DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `gender` varchar(45) DEFAULT NULL,
  `address` varchar(45) DEFAULT NULL,
  `postalCode` varchar(45) DEFAULT NULL,
  `phoneNumber` varchar(45) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `test_status` int(11) DEFAULT '0',
  `result` varchar(45) DEFAULT NULL,
  `comments` varchar(100) DEFAULT NULL,
  `result_returned` tinyint(1) DEFAULT '0',
  `revisitNumber` int(11) DEFAULT NULL,
  `cost` int(11) DEFAULT NULL,
  `patientContact` varchar(45) DEFAULT NULL,
  `receiptNumber` varchar(45) DEFAULT NULL,
  `receiptType` varchar(45) DEFAULT NULL,
  `waiverNo` varchar(45) DEFAULT NULL,
  `provisionalDiagnosis` varchar(45) DEFAULT NULL,
  `system_id` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `labNo` (`labNo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `global_measures`
--

CREATE TABLE IF NOT EXISTS `global_measures` (
  `user_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(128) COLLATE latin1_general_ci DEFAULT NULL,
  `range` varchar(1024) COLLATE latin1_general_ci DEFAULT NULL,
  `test_id` int(10) NOT NULL DEFAULT '0',
  `measure_id` int(10) NOT NULL DEFAULT '0',
  `unit` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`user_id`,`test_id`,`measure_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `import_log`
--

CREATE TABLE IF NOT EXISTS `import_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lab_config_id` int(10) NOT NULL,
  `successful` int(1) DEFAULT NULL,
  `flag` int(1) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `country` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `lab_name` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `db_name` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `remarks` varchar(250) COLLATE latin1_general_ci DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `infection_report_settings`
--

CREATE TABLE IF NOT EXISTS `infection_report_settings` (
  `id` int(10) unsigned NOT NULL DEFAULT '0',
  `group_by_age` int(10) unsigned DEFAULT NULL,
  `group_by_gender` int(10) unsigned DEFAULT NULL,
  `age_groups` varchar(512) COLLATE latin1_general_ci DEFAULT NULL,
  `measure_groups` varchar(512) COLLATE latin1_general_ci DEFAULT NULL,
  `measure_id` int(10) DEFAULT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `test_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`user_id`,`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lab_config`
--

CREATE TABLE IF NOT EXISTS `lab_config` (
  `lab_config_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(45) NOT NULL DEFAULT '',
  `location` char(45) NOT NULL DEFAULT '',
  `admin_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `db_name` char(45) NOT NULL DEFAULT '',
  `id_mode` int(10) unsigned NOT NULL DEFAULT '2',
  `p_addl` int(10) unsigned NOT NULL DEFAULT '0',
  `s_addl` int(10) unsigned NOT NULL DEFAULT '0',
  `daily_num` int(10) unsigned NOT NULL DEFAULT '1',
  `pid` int(10) unsigned NOT NULL DEFAULT '2',
  `pname` int(10) unsigned NOT NULL DEFAULT '1',
  `sex` int(10) unsigned NOT NULL DEFAULT '2',
  `age` int(10) unsigned NOT NULL DEFAULT '1',
  `dob` int(10) unsigned NOT NULL DEFAULT '1',
  `sid` int(10) unsigned NOT NULL DEFAULT '2',
  `refout` int(10) unsigned NOT NULL DEFAULT '1',
  `rdate` int(10) unsigned NOT NULL DEFAULT '2',
  `comm` int(10) unsigned NOT NULL DEFAULT '1',
  `dformat` varchar(45) NOT NULL DEFAULT 'd-m-Y',
  `dnum_reset` int(10) unsigned NOT NULL DEFAULT '1',
  `doctor` int(10) unsigned NOT NULL DEFAULT '1',
  `country` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`lab_config_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT AUTO_INCREMENT=302 ;

--
-- Dumping data for table `lab_config`
--

INSERT INTO `lab_config` (`lab_config_id`, `name`, `location`, `admin_user_id`, `db_name`, `id_mode`, `p_addl`, `s_addl`, `daily_num`, `pid`, `pname`, `sex`, `age`, `dob`, `sid`, `refout`, `rdate`, `comm`, `dformat`, `dnum_reset`, `doctor`, `country`) VALUES
(301, 'Bungoma District Hospital', 'Bungoma', 1, 'blis_301', 1, 0, 0, 1, 2, 1, 2, 1, 1, 2, 1, 2, 0, 'd-m-Y', 1, 1, 'Kenya');

-- --------------------------------------------------------

--
-- Table structure for table `lab_config_access`
--

CREATE TABLE IF NOT EXISTS `lab_config_access` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `lab_config_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`,`lab_config_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `lab_config_specimen_type`
--

CREATE TABLE IF NOT EXISTS `lab_config_specimen_type` (
  `lab_config_id` int(10) unsigned NOT NULL DEFAULT '0',
  `specimen_type_id` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `lab_config_test_type`
--

CREATE TABLE IF NOT EXISTS `lab_config_test_type` (
  `lab_config_id` int(10) unsigned NOT NULL DEFAULT '0',
  `test_type_id` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `map_coordinates`
--

CREATE TABLE IF NOT EXISTS `map_coordinates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lab_id` int(11) NOT NULL,
  `coordinates` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `flag` int(11) DEFAULT '1',
  `country` varchar(110) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `measure_mapping`
--

CREATE TABLE IF NOT EXISTS `measure_mapping` (
  `user_id` int(11) NOT NULL DEFAULT '0',
  `measure_name` varchar(256) COLLATE latin1_general_ci DEFAULT NULL,
  `lab_id_measure_id` varchar(256) COLLATE latin1_general_ci DEFAULT NULL,
  `measure_id` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`,`measure_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE IF NOT EXISTS `patient` (
  `patient_id` int(11) unsigned NOT NULL DEFAULT '0',
  `addl_id` varchar(40) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `sex` char(1) NOT NULL DEFAULT '',
  `age` decimal(10,0) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `created_by` int(11) unsigned DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `partial_dob` varchar(45) DEFAULT NULL,
  `surr_id` varchar(45) DEFAULT NULL,
  `hash_value` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`patient_id`),
  KEY `created_by` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `reference_range_global`
--

CREATE TABLE IF NOT EXISTS `reference_range_global` (
  `measure_id` int(10) NOT NULL DEFAULT '0',
  `age_min` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `age_max` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `sex` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `range_lower` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `range_upper` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`,`measure_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `specimen_mapping`
--

CREATE TABLE IF NOT EXISTS `specimen_mapping` (
  `user_id` int(11) NOT NULL DEFAULT '0',
  `specimen_name` varchar(256) COLLATE latin1_general_ci DEFAULT NULL,
  `lab_id_specimen_id` varchar(256) COLLATE latin1_general_ci DEFAULT NULL,
  `specimen_id` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`,`specimen_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `test_category_mapping`
--

CREATE TABLE IF NOT EXISTS `test_category_mapping` (
  `user_id` int(11) NOT NULL DEFAULT '0',
  `test_category_name` varchar(256) COLLATE latin1_general_ci DEFAULT NULL,
  `lab_id_test_category_id` varchar(256) COLLATE latin1_general_ci DEFAULT NULL,
  `test_category_id` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`,`test_category_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `test_mapping`
--

CREATE TABLE IF NOT EXISTS `test_mapping` (
  `user_id` int(11) NOT NULL DEFAULT '0',
  `test_name` varchar(256) COLLATE latin1_general_ci DEFAULT NULL,
  `lab_id_test_id` varchar(256) COLLATE latin1_general_ci DEFAULT NULL,
  `test_id` int(10) unsigned NOT NULL DEFAULT '0',
  `test_category_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`user_id`,`test_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `actualname` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `created_by` int(11) unsigned DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lab_config_id` int(11) unsigned DEFAULT NULL,
  `level` int(11) unsigned DEFAULT NULL,
  `phone` varchar(45) DEFAULT NULL,
  `lang_id` varchar(45) NOT NULL,
  `emr_user_id` varchar(45) DEFAULT NULL,
  `verify` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `username`, `password`, `actualname`, `email`, `created_by`, `ts`, `lab_config_id`, `level`, `phone`, `lang_id`, `emr_user_id`, `verify`) VALUES
(1, 'superadmin', '18865bfdeed2fd380316ecde609d94d7285af83f', 'Testlab1 admin', '', 1, '2010-01-14 14:05:44', 0, 2, '', 'default', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `version_data`
--

CREATE TABLE IF NOT EXISTS `version_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `status` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `remarks` varchar(250) COLLATE latin1_general_ci DEFAULT NULL,
  `i_ts` timestamp NULL DEFAULT NULL,
  `u_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `version_data`
--

INSERT INTO `version_data` (`id`, `version`, `status`, `user_id`, `remarks`, `i_ts`, `u_ts`) VALUES
(1, '2.4', 1, 116, NULL, '2013-03-09 03:01:13', '2013-03-09 03:01:13'),
(2, '2.5', 1, 53, NULL, '2013-08-05 08:27:36', '2013-08-05 08:27:36'),
(3, '2.5', 1, 505, NULL, '2013-09-19 07:20:47', '2013-09-19 07:20:47');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
